<?php

function tfm_customize_register_breadcrumbs( $wp_customize ) {

	// Breabcrumb colour settings

	if ( function_exists( 'bcn_display') || function_exists('yoast_breadcrumb') ) {

		$wp_customize->add_setting( 'tfm_breadcrumbs_border_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_breadcrumbs_border_color', array(
	      'section' => tfm_get_theme_textdomain() . '_header_colors',
	      'label'   => esc_html__( 'Breadcrumbs Border Color', 'tfm-theme-boost' ),
	    ) ) );

	}

}

add_action( 'customize_register', 'tfm_customize_register_breadcrumbs', 100 );