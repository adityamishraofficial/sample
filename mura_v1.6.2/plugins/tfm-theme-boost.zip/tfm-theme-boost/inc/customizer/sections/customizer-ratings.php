<?php

function tfm_customize_register_ratings( $wp_customize ) {

	/**
	Separator
	**/
	$wp_customize->add_setting('tfm_ratings_separator_archive', array(
		'default'           => '',
		'sanitize_callback' => 'esc_html',
	));
	$wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, 'tfm_ratings_separator_archive', array(
		'settings'		=> 'tfm_ratings_separator_archive',
		'section'     => tfm_get_theme_textdomain() . '_archive_settings',
	)));

	/**
	Info
	**/
    $wp_customize->add_setting('tfm_ratings_info_archive', array(
        'default'           => '',
        'sanitize_callback' => 'tfm_sanitize_text',
     
    ));
    $wp_customize->add_control(new tfm_Info_Custom_Control($wp_customize, 'tfm_ratings_info_archive', array(
        'label'         => esc_html__('Ratings', 'tfm-theme-boost'),
        'description' => esc_html__( 'Add a rating to your posts to use this feature', 'tfm-theme-boost' ),
        'settings'      => 'tfm_ratings_info_archive',
        'section'     => tfm_get_theme_textdomain() . '_archive_settings',
    )));

	// Archive

	$wp_customize->add_setting( 'tfm_star_rating_archive', array(
		'default'           => false,
		'sanitize_callback' => 'tfm_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'tfm_star_rating_archive', array(
		'label'       => esc_html__( 'Star Rating', 'tfm-theme-boost' ),
		'section'     => tfm_get_theme_textdomain() . '_archive_settings',
		'type'        => 'checkbox',
		'priority'    => 100,
	) );

	$wp_customize->add_setting( 'tfm_scale_rating_archive', array(
		'default'           => false,
		'sanitize_callback' => 'tfm_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'tfm_scale_rating_archive', array(
		'label'       => esc_html__( 'Scale Rating', 'tfm-theme-boost' ),
		'section'     => tfm_get_theme_textdomain() . '_archive_settings',
		'type'        => 'checkbox',
		'priority'    => 100,
	) );

	$wp_customize->add_setting( 'tfm_points_rating_archive', array(
		'default'           => false,
		'sanitize_callback' => 'tfm_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'tfm_points_rating_archive', array(
		'label'       => esc_html__( 'Points Rating', 'tfm-theme-boost' ),
		'section'     => tfm_get_theme_textdomain() . '_archive_settings',
		'type'        => 'checkbox',
		'priority'    => 100,
	) );

	$wp_customize->add_setting( 'tfm_percent_rating_archive', array(
		'default'           => false,
		'sanitize_callback' => 'tfm_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'tfm_percent_rating_archive', array(
		'label'       => esc_html__( 'Percent Rating', 'tfm-theme-boost' ),
		'section'     => tfm_get_theme_textdomain() . '_archive_settings',
		'type'        => 'checkbox',
		'priority'    => 100,
	) );

	// Home


	/**
	Separator
	**/
	$wp_customize->add_setting('tfm_ratings_separator_homepage', array(
		'default'           => '',
		'sanitize_callback' => 'esc_html',
	));
	$wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, 'tfm_ratings_separator_homepage', array(
		'settings'		=> 'tfm_ratings_separator_homepage',
		'section'     => tfm_get_theme_textdomain() . '_homepage_settings',
	)));

	/**
	Info
	**/
    $wp_customize->add_setting('tfm_ratings_info_homepage', array(
        'default'           => '',
        'sanitize_callback' => 'tfm_sanitize_text',
     
    ));
    $wp_customize->add_control(new tfm_Info_Custom_Control($wp_customize, 'tfm_ratings_info_homepage', array(
        'label'         => esc_html__('Ratings', 'tfm-theme-boost'),
        'description' => esc_html__( 'Add a rating to your posts to use this feature', 'tfm-theme-boost' ),
        'settings'      => 'tfm_ratings_info_homepage',
        'section'     => tfm_get_theme_textdomain() . '_homepage_settings',
    )));

	$wp_customize->add_setting( 'tfm_star_rating_homepage', array(
		'default'           => false,
		'sanitize_callback' => 'tfm_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'tfm_star_rating_homepage', array(
		'label'       => esc_html__( 'Star Rating', 'tfm-theme-boost' ),
		'section'     => tfm_get_theme_textdomain() . '_homepage_settings',
		'type'        => 'checkbox',
		'priority'    => 100,
	) );

	$wp_customize->add_setting( 'tfm_scale_rating_homepage', array(
		'default'           => false,
		'sanitize_callback' => 'tfm_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'tfm_scale_rating_homepage', array(
		'label'       => esc_html__( 'Scale Rating', 'tfm-theme-boost' ),
		'section'     => tfm_get_theme_textdomain() . '_homepage_settings',
		'type'        => 'checkbox',
		'priority'    => 100,
	) );

	$wp_customize->add_setting( 'tfm_points_rating_homepage', array(
		'default'           => false,
		'sanitize_callback' => 'tfm_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'tfm_points_rating_homepage', array(
		'label'       => esc_html__( 'Points Rating', 'tfm-theme-boost' ),
		'section'     => tfm_get_theme_textdomain() . '_homepage_settings',
		'type'        => 'checkbox',
		'priority'    => 100,
	) );

	$wp_customize->add_setting( 'tfm_percent_rating_homepage', array(
		'default'           => false,
		'sanitize_callback' => 'tfm_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'tfm_percent_rating_homepage', array(
		'label'       => esc_html__( 'Percent Rating', 'tfm-theme-boost' ),
		'section'     => tfm_get_theme_textdomain() . '_homepage_settings',
		'type'        => 'checkbox',
		'priority'    => 100,
	) );


	// Ratings colors

	$wp_customize->add_setting( 'tfm_star_rating_color', array(
		'default'           => '',
		'transport' => 'refresh',
		'sanitize_callback' => 'sanitize_hex_color',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_star_rating_color', array(
      'section' => tfm_get_theme_textdomain() . '_misc_colors',
      'label'   => esc_html__( 'Stars Rating Color', 'tfm-theme-boost' ),
    ) ) );

    $wp_customize->add_setting( 'tfm_scale_rating_color', array(
		'default'           => '',
		'transport' => 'refresh',
		'sanitize_callback' => 'sanitize_hex_color',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_scale_rating_color', array(
      'section' => tfm_get_theme_textdomain() . '_misc_colors',
      'label'   => esc_html__( 'Scale Rating Color', 'tfm-theme-boost' ),
    ) ) );

    $wp_customize->add_setting( 'tfm_scale_rating_low_color', array(
		'default'           => '',
		'transport' => 'refresh',
		'sanitize_callback' => 'sanitize_hex_color',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_scale_rating_low_color', array(
      'section' => tfm_get_theme_textdomain() . '_misc_colors',
      'label'   => esc_html__( 'Scale Rating Low', 'tfm-theme-boost' ),
    ) ) );

    $wp_customize->add_setting( 'tfm_scale_rating_high_color', array(
		'default'           => '',
		'transport' => 'refresh',
		'sanitize_callback' => 'sanitize_hex_color',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_scale_rating_high_color', array(
      'section' => tfm_get_theme_textdomain() . '_misc_colors',
      'label'   => esc_html__( 'Scale Rating High', 'tfm-theme-boost' ),
    ) ) );

}

add_action( 'customize_register', 'tfm_customize_register_ratings', 100 );