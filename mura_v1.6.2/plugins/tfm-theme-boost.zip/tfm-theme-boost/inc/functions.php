<?php

/**
 * 3FortyMedia: Theme Boost Functions
 *
 * @since 1.0
 * @version 1.3
 */

$tfm_theme_boost_options = get_option( 'tfm_theme_boost_option_name' );

// ========================================================
// Get theme text domain
// ========================================================

if ( ! function_exists( 'tfm_get_theme_textdomain' ) ) {

	function tfm_get_theme_textdomain() {

		$theme = wp_get_theme();
		$theme_slug =  $theme->get( 'TextDomain' );

		// Themes released after Mura
		if ( $theme_slug !== 'mura' ) {
			$theme_slug = 'tfm';
		}

		return $theme_slug;
	}

}

// ========================================================
// Show read time true/false
// ========================================================

if ( ! function_exists( 'tfm_show_read_time' ) ) {

	function tfm_show_read_time() {

		$show_read_time = false;

		// Image format
		if ( ! is_single() && has_post_format( 'image') && ! get_theme_mod( '' . tfm_get_theme_textdomain() . '_image_format_use_global', true ) ) {

			if ( ( is_home() && get_theme_mod( 'tfm_image_format_entry_meta_read_time', true ) ) || (( is_archive() || is_search() ) &&  get_theme_mod( 'tfm_image_format_entry_meta_read_time', true ) ) ) {

				$show_read_time = true;
			}

		} else {

			if ( ( is_home() && get_theme_mod( 'tfm_homepage_entry_meta_read_time', true ) ) || 
		   ( ( is_archive() || is_search() ) && get_theme_mod( 'tfm_archive_entry_meta_read_time', true ) ) ||
			( is_single( ) && get_theme_mod( 'tfm_single_entry_meta_read_time', false ) ) ) {

				$show_read_time = true;

			}

		}

		return $show_read_time;

	}

}

// ========================================================
// Calculate reading time for each post
// ========================================================

if ( ! function_exists( 'tfm_read_time' ) ) {

	function tfm_read_time( $forced_request = false, $return = false ) {

	    $post_content = get_post_field( 'post_content' );
	    $word_count = str_word_count( strip_tags( $post_content ) );
	    $readingtime = ceil( $word_count / apply_filters( 'tfm_read_time_wpm', 300 ));
	    $read_time_before = '' !== apply_filters( 'tfm_read_time_text_before', '' ) ? apply_filters( 'tfm_read_time_text_before', '' ) . ' ' : '';

	    $readtime = $read_time_before . $readingtime . ' ' . esc_html__( 'min', 'tfm-theme-boost');

		if ( tfm_show_read_time() || $forced_request === true ) {

			if ( $return ) {

				return '<li class="entry-meta-read-time">' . esc_attr( $readtime ) . '</li>';
				
			} else {

		    	echo '<li class="entry-meta-read-time">' . esc_attr( $readtime ) . '</li>';

		    }

		}

	}

}

// ========================================================
// Add read time class to post_class()
// ========================================================

if ( ! function_exists( 'tfm_post_classes' ) ) {

	function tfm_post_classes( $classes ) {

		if ( tfm_show_read_time() ) :

			$classes[] = 'has-tfm-read-time';

		endif;

		if ( function_exists('tfm_custom_meta_box') && get_post_meta( get_the_ID(), 'tfm_featured_post', true ) && ! is_single() ) :

			$classes[] = 'tfm-featured-post';

			if ( '' !== get_theme_mod( 'tfm_featured_post_background', '' )) {
				$classes[] = 'has-tfm-background';
				$classes[] = 'has-background';
			}

		endif;

		return $classes;

	}

	add_filter( 'post_class', 'tfm_post_classes',  10, 3 );

	}

// ========================================================
// Generate human readable date
// ========================================================

if ( ! function_exists('tfm_human_entry_date') && isset($tfm_theme_boost_options['tfm_human_entry_date'])) {

	function tfm_human_entry_date() {

		$the_post_date =  human_time_diff( get_the_time('U'), current_time( 'timestamp' ) ) . ' ' . esc_html__('ago', 'tfm-theme-boost' );

		return $the_post_date;

	}

	add_filter( 'the_time', 'tfm_human_entry_date' ); // for posts and pages

}

// ========================================================
// Generate human readable updated date
// ========================================================

if ( ! function_exists('tfm_human_updated_date') && isset($tfm_theme_boost_options['tfm_human_entry_date']) ) {

	function tfm_human_updated_date() {

		$the_updated_date =  human_time_diff( get_the_modified_time('U'), current_time( 'timestamp' ) ) . ' ' . esc_html__('ago', 'tfm-theme-boost' );

		return $the_updated_date;

	}

	add_filter( 'get_the_modified_date', 'tfm_human_updated_date' ); // for posts and pages

}

// ========================================================
// Generate human readable comment date
// ========================================================

if ( ! function_exists('tfm_human_comment_date') && isset($tfm_theme_boost_options['tfm_human_comment_date']) ) {

	function tfm_human_comment_date() {

		if ( is_single() && have_comments() ) {

		$the_comment_date =  human_time_diff( get_comment_time('U'), current_time( 'timestamp' ) ) . ' ' . esc_html__('ago', 'tfm-theme-boost' );

		 return $the_comment_date;

		}

	}

	add_filter( 'get_comment_date', 'tfm_human_comment_date' );

}

// ========================================================
// Filter image compression/quality
// ========================================================

if ( ! function_exists('tfm_set_image_quality') ) {

	function tfm_set_image_quality() {

		$tfm_theme_boost_options = get_option( 'tfm_theme_boost_option_name' );
		$image_quality = isset($tfm_theme_boost_options['tfm_image_quality']) ? $tfm_theme_boost_options['tfm_image_quality'] : 82;

		return $image_quality;

	}

	add_filter( 'jpeg_quality', 'tfm_set_image_quality');

}

// ========================================================
// Add/remove sidebar class based on meta field selection
// ========================================================

if ( ! function_exists('tfm_sidebar_body_class') ) {

	function tfm_sidebar_body_class( $classes ) {

		$remove_class = array( 'has-sidebar' );

		// Remove sidebar class
		if ( ( is_single() && get_post_meta( get_the_ID(), 'tfm_single_post_sidebar', true ) && get_post_meta( get_the_ID(), 'tfm_single_post_sidebar', true ) === 'disabled-sidebar' ) || ( is_page() && get_post_meta( get_the_ID(), 'tfm_single_page_sidebar', true ) && get_post_meta( get_the_ID(), 'tfm_single_page_sidebar', true ) === 'disabled-sidebar' ) ) {
			$classes = array_diff( $classes, $remove_class);
		}

		// Add sidebar class
		if ( ( is_single() && get_post_meta( get_the_ID(), 'tfm_single_post_sidebar', true ) && get_post_meta( get_the_ID(), 'tfm_single_post_sidebar', true ) === 'has-sidebar' ) || ( is_page() && get_post_meta( get_the_ID(), 'tfm_single_page_sidebar', true ) && get_post_meta( get_the_ID(), 'tfm_single_page_sidebar', true ) === 'has-sidebar' ) ) {
			$classes[] = 'has-sidebar';
		}

		return $classes;
	}
	
	add_filter( 'body_class', 'tfm_sidebar_body_class', 20 );

}

// ========================================================
// Output category tags in post meta
// ========================================================

if ( ! function_exists( 'tfm_get_category' ) ) {

	function tfm_get_category( $num = 2, $in = true, $tfm_plugin = '' ) {

		$num = ( ''=== $num ? apply_filters( 'tfm_get_category_max_slugs', 2 ) : $num );

		$category = array_slice( get_the_category(), 0, $num );
		$count = 0;

		// Related posts cat slug color
		$plugin_slug_color = '';
		if ( $tfm_plugin === 'tfm_related_posts' && function_exists('tfm_related_posts') && '' !== get_theme_mod( 'tfm_related_posts_entry_meta_cat_link_color', '' ) && is_single() ) {
			$plugin_slug_color = get_theme_mod( 'tfm_related_posts_entry_meta_cat_link_color', '' );
		}
		if ( $tfm_plugin === 'tfm_hero' && function_exists('tfm_hero') && '' !== get_theme_mod( 'tfm_hero_entry_meta_link_color', '' )) {
			$plugin_slug_color = get_theme_mod( 'tfm_hero_entry_meta_link_color', '' );
		}
		$inline_style = $plugin_slug_color ? 'color:' . $plugin_slug_color . '' : '';
		// End

		echo '<span class="screen-reader-text">' . esc_html__( 'Categories', 'tfm-theme-boost' ) . '</span>';

		echo '<ul class="post-categories-meta">';

		foreach( $category as $the_category ) {

			$count++;

			echo '<li class="cat-slug-' . esc_attr( $the_category->slug ) . ' cat-id-' . esc_attr( $the_category->cat_ID ) . '">';
			// "In" text string
			if ( $count === 1 && $in ) {
				echo '<span class="screen-reader-text">' . esc_html__( 'Posted in', 'tfm-theme-boost' ) . '</span><i dir="ltr">' . esc_html__( 'in', 'tfm-theme-boost' ) . '</i> ';
			}
			echo '<a href="' . get_category_link( $the_category->cat_ID ) . '" class="cat-link-' . esc_attr( $the_category->cat_ID ) . '" style="' . esc_attr($inline_style) . '">' . esc_html( $the_category->cat_name ) . '</a></li>';

		}

		echo '</ul>';

	}

}

// ========================================================
// Ratings
// ========================================================

if ( ! function_exists( 'tfm_ratings' ) ) {

	function tfm_ratings( $star_rating = false, $points_rating = false, $percent_rating = false, $scale_rating = false, $forced_request = false ) {

		if ( ! function_exists('tfm_ratings_meta_box_callback') ) {
			return;
		}

		$show_star_rating = is_home() ? get_theme_mod( 'tfm_star_rating_homepage', false ) : get_theme_mod( 'tfm_star_rating_archive', false );
		if ( is_single() ) {
			$show_star_rating = get_post_meta( get_the_ID(), 'tfm_star_rating', true );
		}
		$show_points_rating = is_home() ? get_theme_mod( 'tfm_points_rating_homepage', false ) : get_theme_mod( 'tfm_points_rating_archive', false );
		if ( is_single() ) {
			$show_points_rating = get_post_meta( get_the_ID(), 'tfm_points_rating', true );
		}
		$show_percent_rating = is_home() ? get_theme_mod( 'tfm_percent_rating_homepage', false ) : get_theme_mod( 'tfm_percent_rating_archive', false );
		if ( is_single() ) {
			$show_percent_rating = get_post_meta( get_the_ID(), 'tfm_percent_rating', true );
		}
		$show_scale_rating = is_home() ? get_theme_mod( 'tfm_scale_rating_homepage', false ) : get_theme_mod( 'tfm_scale_rating_archive', false );
		if ( is_single() ) {
			$show_scale_rating = get_post_meta( get_the_ID(), 'tfm_scale_rating', true );
		}

		// Handle forced and plugin queries

		if ( true === $forced_request ) {
			$show_star_rating = $star_rating;
			$show_points_rating = $points_rating;
			$show_percent_rating = $percent_rating;
			$show_scale_rating = $scale_rating;
		}

		if ( ( ! $show_star_rating && ! $show_points_rating && ! $show_percent_rating && ! $show_scale_rating ) || '' === get_post_meta( get_the_ID(), 'tfm_simple_ratings_score', true )) {
			return;
		}

		// Request is good, lets go...

			$rating = (float)get_post_meta( get_the_ID(), 'tfm_simple_ratings_score', true );
			$maxrating = (float)get_post_meta( get_the_ID(), 'tfm_simple_ratings_range', true );
			if ( $rating > $maxrating ) {
				$rating = $maxrating;
			}
			$percent = ($rating && $maxrating ) ? $rating / $maxrating * 100 : false;
			$scale = $percent ? 100 - $percent : false;

			$schema_rating_value = $show_percent_rating ? $percent : $rating;
			$schema_best_rating = $show_percent_rating ? '100' : $maxrating;

			if ( $rating ) {

				// Schema
				$schema = is_single() && ! $forced_request ? '" itemprop="reviews" itemscope="" itemtype="http://schema.org/Review"' : '"';
				$schema_author = is_single() && ! $forced_request ? '<div class="schema hidden" itemprop="author" itemscope="" itemtype="http://schema.org/Person"><span itemprop="name">' . get_the_author() . '</span></div>' : '';
				$schema_item = is_single() && ! $forced_request ? '<div class="schema hidden" itemprop="itemReviewed" itemscope="" itemtype="http://schema.org/Product"><span class="schema hidden" itemprop="name">' . get_the_title() . '</span>' : '';
				$schema_aggregate = is_single() && ! $forced_request ? '<div class="schema hidden" itemprop="aggregateRating" itemscope="" itemtype="http://schema.org/AggregateRating"><span class="schema hidden" itemprop="ratingValue">' . esc_attr( $schema_rating_value ) . '</span><span class="schema hidden" itemprop="bestRating">' . esc_attr( $schema_best_rating ) . '</span><span class="schema hidden" itemprop="reviewCount">1</span></div></div>' : '';

				$html = '<div class="entry-meta tfm-ratings' . $schema . '>';
				$html .= $schema_author;
				$html .= $schema_item;
				$html .= $schema_aggregate;

					if ( $show_star_rating && $rating ) {

						$half_full = floor($rating) !== $rating ? true : false;
						$stars = $rating;

						// Max rating 10
						if ( (int)$maxrating === 10 ) {
							$stars = $rating / 2;
						}

						// Max rating 100
						if ( (int)$maxrating === 100 ) {
							$stars = $rating / 20;
							$half_star = floor($stars) !== $stars ? true : false;
							if ( $half_star) {
								$half_full = true;
							}
						}

						$html .= '<div class="tfm-rating-stars">';

						for ($i = 1; $i <= 5; $i++) {

							$last_star = (int)$stars;
							if ( $half_full ) {
								$last_star = (int)$stars + 1;
							}

							if ( (int)$stars < 1 ) {
								$last_star = 1;
								$half_full = true;
							}


							$last = $i === $last_star ? 'last' : '';
							$half = $half_full && $last ? ' half' : '';
							$empty = $i > $last_star ? ' none' : '';

						    $html .= '<span class="star' . $empty . $half . '"></span>';

						}

						$html .= '</div>';
					}

					if ( $show_scale_rating && $percent ) {
						$html .= '<div class="tfm-rating-scale">';
						if ( $scale ) {
							$html .= '<span class="scale" style="width:' . esc_attr( $scale ) . '%"></span>';
						}
						$html .= '</div>';
					}

					if ( $show_points_rating && $rating ) {
						$html .= '<span class="tfm-rating-points">' . esc_attr( $rating ) . '/' . esc_attr( $maxrating ) . '</span>';
					}
					if ( $show_percent_rating && $percent ) {
						$html .= '<span class="tfm-rating-percent">' . esc_attr( $percent ) . esc_html__( '%', 'tfm-theme-boost' ) . '</span>';
					}

					// Output schema
					if ( is_single() && ! $forced_request ) {

						$html .= '<div class="hidden schema" itemprop="reviewRating" itemscope="" itemtype="http://schema.org/Rating">';
						$html .= '<span class="hidden schema" itemprop="ratingValue" content="' . esc_attr( $schema_rating_value ) . '"></span>';
						$html .= '<span class="hidden schema" itemprop="bestRating" content="' . esc_attr( $schema_best_rating ) . '"></span>';
						$html .= '</div>';
					}

				$html .= '</div>';

				echo $html; // Already escaped

			}

	}

	add_action( 'tfm_after_after_title_meta', 'tfm_ratings', 10 );


}

// ========================================================
// Display MailChimp Widget before footer
// ========================================================
if ( ! function_exists( 'tfm_theme_boost_mc4wp_widget_display' ) ) {

	function tfm_theme_boost_mc4wp_widget_display() {

		if ( class_exists( 'MC4WP_Form_Widget' ) ) {

			if ( get_theme_mod( 'tfm_mc4wp_footer_widget', false )) {

				// Check for a background image upload
				$background_image = '' !== get_theme_mod( 'tfm_before_footer_background_image', '' ) ? get_theme_mod( 'tfm_before_footer_background_image', '' ) : '';

				$inline_style = $background_image ? ' style="background-image: url(' : '';
				$inline_style .= $background_image ? esc_url($background_image ) : '';
				$inline_style .= $background_image ? ');"' : '';

				echo '<div class="tfm-before-footer-section"' . $inline_style . '>';
				echo '<div class="site-footer-inner"' . $inline_style . '>';

				the_widget( 'MC4WP_Form_Widget', 'form_id=' . get_theme_mod( 'tfm_mc4wp_footer_widget_form_id', '' ) . '&title=' . get_theme_mod( 'tfm_mc4wp_footer_widget_title', '' ) . '' );

				echo '</div>';
				echo '</div>';

			}

		}


	}
	
	add_action( 'tfm_before_footer', 'tfm_theme_boost_mc4wp_widget_display', 100 );

}

// ========================================================
// Display Bread crumbs if plugin exists
// ========================================================

/**
 * Yoast SEO Breadcrumbs, Rankmath and NavXT supported
 */

if ( ! function_exists('tfm_breadcrumbs') ) {

	function tfm_breadcrumbs( $return_output = false ) {

		$html = '';

		// https://wordpress.org/plugins/breadcrumb-navxt/
		if ( function_exists( 'bcn_display') && ( ! function_exists('yoast_breadcrumb') || ( function_exists('yoast_breadcrumb') && empty(get_option('wpseo_titles')['breadcrumbs-enable']) ) ) && ! function_exists('rank_math_the_breadcrumbs') ) {
			$html .= '<div class="tfm-breadcrumbs navxt"><div class="tfm-breadcrumbs-inner">' . bcn_display( $return = true ) . '</div></div>';
			
			if ( $return_output ) {
				return $html;
			} else {
				echo $html;
			}
		}

		//https://en-gb.wordpress.org/plugins/wordpress-seo/
		if ( function_exists('yoast_breadcrumb') ) {
		  return yoast_breadcrumb( '<div id="yoast-breadcrumbs" class="tfm-breadcrumbs yoast">','</div>' );
		}

		// Rankmath
		if ( function_exists('rank_math_the_breadcrumbs')) {
			rank_math_the_breadcrumbs(array( 'wrap_before' => '<div class="tfm-breadcrumbs rankmath"><nav aria-label="breadcrumbs" class="rank-math-breadcrumb"><p>', 'wrap_after' => '</p></nav></div>' ));
		}

	}
	add_action( 'tfm_after_header', 'tfm_breadcrumbs', 10 );

}

// ========================================================
// Add breadcrumb class to body tag
// ========================================================

if ( ! function_exists('tfm_breadcrumbs_body_class') ) {

	function tfm_breadcrumbs_body_class( $classes ) {

		if ( ( function_exists( 'bcn_display') && ( ! function_exists('yoast_breadcrumb') || function_exists('yoast_breadcrumb') && empty(get_option('wpseo_titles')['breadcrumbs-enable']) ) ) || function_exists('yoast_breadcrumb') ) {
			$classes[]  = 'has-tfm-breadcrumbs';
		}

		return $classes;
	}
	
	add_filter( 'body_class', 'tfm_breadcrumbs_body_class', 20 );

}

// ========================================================
// Check ads are enabled in plugin settings
// ========================================================

if ( isset($tfm_theme_boost_options['tfm_ads'])) {

	// ========================================================
	// Register custom sidebars for advertising
	// ========================================================

	if ( ! function_exists('tfm_advert_sidebars') ) {

		function tfm_advert_sidebars() {

			register_sidebar( array(
				'name'          => esc_html__( 'TFM: Advertising (After Header)', 'tfm-theme-boost' ),
				'id'            => 'after-header-sidebar',
				'description'   => esc_html__( 'Add your Ad widget or custom advert HTML to appear after theme header', 'tfm-theme-boost' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h3 class="widget-title">',
				'after_title'   => '</h3>',
			) );

			register_sidebar( array(
				'name'          => esc_html__( 'TFM: Advertising (Site Header)', 'tfm-theme-boost' ),
				'id'            => 'site-header-sidebar',
				'description'   => esc_html__( 'Add your Ad widget or custom advert HTML to appear in the Site Header', 'tfm-theme-boost' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h3 class="widget-title">',
				'after_title'   => '</h3>',
			) );

		}

		add_action( 'widgets_init', 'tfm_advert_sidebars' );

	}

	// ========================================================
	// Display custom sidebars for advertising
	// ========================================================

	// Afer header

	if ( ! function_exists('tfm_after_header_widget')) {

		function tfm_after_header_widget() {

			$display_status = ( is_front_page() && get_theme_mod( 'tfm_ad_after_header_display_home', true ) ) || ( is_home() && 'page' === get_option( 'show_on_front') && get_theme_mod( 'tfm_ad_after_header_display_blog', true ) ) || ( ( is_archive() || is_search() ) && get_theme_mod( 'tfm_ad_after_header_display_archive', true ) ) || ( is_single() && get_theme_mod( 'tfm_ad_after_header_display_single', true ) ) || ( is_page() && ! is_front_page() && get_theme_mod( 'tfm_ad_after_header_display_page', true ) ) ? true : false;

			if ( class_exists('WooCommerce') ) {
				// Reset status from blog pages to false
				if ( is_shop() || is_product() || is_product_category() || is_product_tag() || is_cart() || is_checkout() || is_account_page() ) {
					$display_status = false;
					// Check Woo pages
					$display_status = ( is_shop() || is_product() || is_product_category() || is_product_tag() ) && get_theme_mod( 'tfm_ad_after_header_display_shop', true ) ? true : false;
				}
			}

			if ( false === $display_status ) {

				return false;
			}

			$hidden_mobile = get_theme_mod( 'tfm_ad_after_header_display_mobile', true ) ? '' : ' hidden-mobile';

		      if ( is_active_sidebar( 'after-header-sidebar' ) ) {
		      	echo '<div class="tfm-after-header-sidebar advert' . esc_attr($hidden_mobile) . '">';
		        	dynamic_sidebar( 'after-header-sidebar');
		        echo '</div>';
		        }

		    }

		add_action ('tfm_after_header', 'tfm_after_header_widget', 1 );

	}

	// Site header

	if ( ! function_exists('tfm_site_header_widget')) {

		function tfm_site_header_widget() {

			$display_status = ( is_front_page() && get_theme_mod( 'tfm_ad_site_header_display_home', true ) ) || ( is_home() && 'page' === get_option( 'show_on_front') && get_theme_mod( 'tfm_ad_site_header_display_blog', true ) ) || ( ( is_archive() || is_search() ) && get_theme_mod( 'tfm_ad_site_header_display_archive', true ) ) || ( is_single() && get_theme_mod( 'tfm_ad_site_header_display_single', true ) ) || ( is_page() && ! is_front_page() && get_theme_mod( 'tfm_ad_site_header_display_page', true ) ) ? true : false;

			if ( class_exists('WooCommerce') ) {
				// Reset status from blog pages to false
				if ( is_shop() || is_product() || is_product_category() || is_product_tag() || is_cart() || is_checkout() || is_account_page() ) {
					$display_status = false;
					// Check Woo pages
					$display_status = ( is_shop() || is_product() || is_product_category() || is_product_tag() ) && get_theme_mod( 'tfm_ad_site_header_display_shop', true ) ? true : false;
				}
			}

			if ( false === $display_status ) {

				return false;
			}

			if ( get_theme_mod( tfm_get_theme_textdomain() . '_header_layout') === 'default-advert') {

		      if (is_active_sidebar( 'site-header-sidebar' )) {
		      	echo '<div class="tfm-site-header-sidebar advert">';
		        	dynamic_sidebar( 'site-header-sidebar');
		        echo '</div>';
		        }

		    }

		    }

		add_action ('tfm_header_right', 'tfm_site_header_widget', 1 );

	}

	// ========================================================
	// Display any uploaded images and URLs from the customizer
	// ========================================================

	// After header

	function tfm_after_header_banner_upload() {

		$display_status = ( is_front_page() && get_theme_mod( 'tfm_ad_after_header_display_home', true ) ) || ( is_home() && 'page' === get_option( 'show_on_front') && get_theme_mod( 'tfm_ad_after_header_display_blog', true ) ) || ( ( is_archive() || is_search() ) && get_theme_mod( 'tfm_ad_after_header_display_archive', true ) ) || ( is_single() && get_theme_mod( 'tfm_ad_after_header_display_single', true ) ) || ( is_page() && ! is_front_page() && get_theme_mod( 'tfm_ad_after_header_display_page', true ) ) ? true : false;

		if ( class_exists('WooCommerce') ) {
			// Reset status from blog pages to false
			if ( is_shop() || is_product() || is_product_category() || is_product_tag() || is_cart() || is_checkout() || is_account_page() ) {
				$display_status = false;
				// Check Woo pages
				$display_status = ( is_shop() || is_product() || is_product_category() || is_product_tag() ) && get_theme_mod( 'tfm_ad_after_header_display_shop', true ) ? true : false;
			}
		}

		if ( false === $display_status ) {

			return false;
		}

		$hidden_mobile = get_theme_mod( 'tfm_ad_after_header_display_mobile', true ) ? '' : ' hidden-mobile';
		$image = '' !== get_theme_mod('tfm_ad_after_header_image', '') ? get_theme_mod( 'tfm_ad_after_header_image' ) : '';
		$image2x = '' !== get_theme_mod('tfm_ad_after_header_image_2x', '') ? get_theme_mod( 'tfm_ad_after_header_image_2x' ) : '';
		$url = '' !== get_theme_mod('tfm_ad_after_header_url', '' ) ? get_theme_mod('tfm_ad_after_header_url', '' ) : '';

		$html = ( $image || $image2x ) ? '<div class="tfm-after-header-sidebar advert image-upload' . esc_attr( $hidden_mobile) . '"><div>' : '';
		$html .= $url && ( $image || $image2x ) ? '<a href="' . esc_url($url) . '" target="_blank">' : '';
		$html .= ( $image || $image2x ) ? '<img src="' : '';

		// Image src
		$html .= $image ? esc_url( $image ) . '"' : '';
		$html .= '' === $image && $image2x ? esc_url( $image2x ) . '"' : ''; /* Only 2x image uploaded */
		$html .= $image && $image2x ? 'srcset="' . esc_url($image2x) . ' 2x"' : ''; /* 2x image srcset */

		// Close image and div
		$html .= ( $image || $image2x ) ? 'alt="after-header-banner">' : '';
		$html .= $url && ( $image || $image2x ) ? '</a>' : '';
		$html .= ( $image || $image2x ) ? '</div></div>' : '';

		echo $html; // Allready escaped

	}

	add_action ('tfm_after_header', 'tfm_after_header_banner_upload', 1 );

	// Site header

	function tfm_site_header_banner_upload() {

		$display_status = ( is_front_page() && get_theme_mod( 'tfm_ad_site_header_display_home', true ) ) || ( is_home() && 'page' === get_option( 'show_on_front') && get_theme_mod( 'tfm_ad_site_header_display_blog', true ) ) || ( ( is_archive() || is_search() ) && get_theme_mod( 'tfm_ad_site_header_display_archive', true ) ) || ( is_single() && get_theme_mod( 'tfm_ad_site_header_display_single', true ) ) || ( is_page() && ! is_front_page() && get_theme_mod( 'tfm_ad_site_header_display_page', true ) ) ? true : false;

			if ( class_exists('WooCommerce') ) {
				// Reset status from blog pages to false
				if ( is_shop() || is_product() || is_product_category() || is_product_tag() || is_cart() || is_checkout() || is_account_page() ) {
					$display_status = false;
					// Check Woo pages
					$display_status = ( is_shop() || is_product() || is_product_category() || is_product_tag() ) && get_theme_mod( 'tfm_ad_site_header_display_shop', true ) ? true : false;
				}
			}

			if ( false === $display_status ) {

				return false;
			}

		if ( get_theme_mod( tfm_get_theme_textdomain() . '_header_layout') === 'default-advert') {

			$image = '' !== get_theme_mod('tfm_ad_site_header_image', '') ? get_theme_mod( 'tfm_ad_site_header_image' ) : '';
			$image2x = '' !== get_theme_mod('tfm_ad_site_header_image_2x', '') ? get_theme_mod( 'tfm_ad_site_header_image_2x' ) : '';
			$url = '' !== get_theme_mod('tfm_ad_site_header_url', '' ) ? get_theme_mod('tfm_ad_site_header_url', '' ) : '';

			$html = ( $image || $image2x ) ? '<div class="tfm-site-header-sidebar advert image-upload">' : '';
			$html .= $url && ( $image || $image2x ) ? '<a href="' . esc_url($url) . '" target="_blank">' : '';
			$html .= ( $image || $image2x ) ? '<img src="' : '';

			// Image src
			$html .= $image ? esc_url( $image ) . '"' : '';
			$html .= '' === $image && $image2x ? esc_url( $image2x ) . '"' : ''; /* Only 2x image uploaded */
			$html .= $image && $image2x ? 'srcset="' . esc_url($image2x) . ' 2x"' : ''; /* 2x image srcset */

			// Close image and div
			$html .= ( $image || $image2x ) ? 'alt="site-header-banner">' : '';
			$html .= $url && ( $image || $image2x ) ? '</a>' : '';
			$html .= ( $image || $image2x ) ? '</div>' : '';

			echo $html; // Allready escaped

		}
	}

	add_action ('tfm_header_right', 'tfm_site_header_banner_upload', 1 );

	// Before Footer

	function tfm_before_footer_banner_upload() {

		$display_status = ( is_front_page() && get_theme_mod( 'tfm_ad_before_footer_display_home', true ) ) || ( is_home() && 'page' === get_option( 'show_on_front') && get_theme_mod( 'tfm_ad_before_footer_display_blog', true ) ) || ( ( is_archive() || is_search() ) && get_theme_mod( 'tfm_ad_before_footer_display_archive', true ) ) || ( is_single() && get_theme_mod( 'tfm_ad_before_footer_display_single', true ) ) || ( is_page() && ! is_front_page() && get_theme_mod( 'tfm_ad_before_footer_display_page', true ) ) ? true : false;

		if ( class_exists('WooCommerce') ) {
			// Reset status from blog pages to false
			if ( is_shop() || is_product() || is_product_category() || is_product_tag() || is_cart() || is_checkout() || is_account_page() ) {
				$display_status = false;
				// Check Woo pages
				$display_status = ( is_shop() || is_product() || is_product_category() || is_product_tag() ) && get_theme_mod( 'tfm_ad_before_footer_display_shop', true ) ? true : false;
			}
		}

		if ( false === $display_status ) {

			return false;
		}

		$hidden_mobile = get_theme_mod( 'tfm_ad_before_footer_display_mobile', true ) ? '' : ' hidden-mobile';
		$image = '' !== get_theme_mod('tfm_ad_before_footer_image', '') ? get_theme_mod( 'tfm_ad_before_footer_image' ) : '';
		$image2x = '' !== get_theme_mod('tfm_ad_before_footer_image_2x', '') ? get_theme_mod( 'tfm_ad_before_footer_image_2x' ) : '';
		$url = '' !== get_theme_mod('tfm_ad_before_footer_url', '' ) ? get_theme_mod('tfm_ad_before_footer_url', '' ) : '';

		$html = ( $image || $image2x ) ? '<div class="tfm-before-footer-advert advert image-upload' . esc_attr( $hidden_mobile) . '"><div>' : '';
		$html .= $url && ( $image || $image2x ) ? '<a href="' . esc_url($url) . '" target="_blank">' : '';
		$html .= ( $image || $image2x ) ? '<img src="' : '';

		// Image src
		$html .= $image ? esc_url( $image ) . '"' : '';
		$html .= '' === $image && $image2x ? esc_url( $image2x ) . '"' : ''; /* Only 2x image uploaded */
		$html .= $image && $image2x ? 'srcset="' . esc_url($image2x) . ' 2x"' : ''; /* 2x image srcset */

		// Close image and div
		$html .= ( $image || $image2x ) ? 'alt="before-footer-banner">' : '';
		$html .= $url && ( $image || $image2x ) ? '</a>' : '';
		$html .= ( $image || $image2x ) ? '</div></div>' : '';

		echo $html; // Allready escaped
	}

	add_action('tfm_before_footer', 'tfm_before_footer_banner_upload', 1 );

	// ========================================================
	// Output Ad Code
	// ========================================================

	// After header

	function tfm_after_header_ad_code() {

		$display_status = ( is_front_page() && get_theme_mod( 'tfm_ad_after_header_display_home', true ) ) || ( is_home() && 'page' === get_option( 'show_on_front') && get_theme_mod( 'tfm_ad_after_header_display_blog', true ) ) || ( ( is_archive() || is_search() ) && get_theme_mod( 'tfm_ad_after_header_display_archive', true ) ) || ( is_single() && get_theme_mod( 'tfm_ad_after_header_display_single', true ) ) || ( is_page() && ! is_front_page() && get_theme_mod( 'tfm_ad_after_header_display_page', true ) ) ? true : false;

		if ( class_exists('WooCommerce') ) {
			// Reset status from blog pages to false
			if ( is_shop() || is_product() || is_product_category() || is_product_tag() || is_cart() || is_checkout() || is_account_page() ) {
				$display_status = false;
				// Check Woo pages
				$display_status = ( is_shop() || is_product() || is_product_category() || is_product_tag() ) && get_theme_mod( 'tfm_ad_after_header_display_shop', true ) ? true : false;
			}
		}

		if ( false === $display_status ) {

			return false;
		}

		$hidden_mobile = get_theme_mod( 'tfm_ad_after_header_display_mobile', true ) ? '' : ' hidden-mobile';
		$code = '' !== get_theme_mod('tfm_ad_after_header_code', '') ? get_theme_mod( 'tfm_ad_after_header_code' ) : '';

		$html = $code ? '<div class="tfm-after-header-sidebar advert code' . esc_attr( $hidden_mobile) . '">' : '' ;
		$html .= $code ? $code : ''; // Do not escape
		$html .= $code ? '</div>' : '';

		echo $html;
	}

	add_action('tfm_after_header', 'tfm_after_header_ad_code', 1 );

	// Site header

	function tfm_site_header_ad_code() {

		$display_status = ( is_front_page() && get_theme_mod( 'tfm_ad_site_header_display_home', true ) ) || ( is_home() && 'page' === get_option( 'show_on_front') && get_theme_mod( 'tfm_ad_site_header_display_blog', true ) ) || ( ( is_archive() || is_search() ) && get_theme_mod( 'tfm_ad_site_header_display_archive', true ) ) || ( is_single() && get_theme_mod( 'tfm_ad_site_header_display_single', true ) ) || ( is_page() && ! is_front_page() && get_theme_mod( 'tfm_ad_site_header_display_page', true ) ) ? true : false;

			if ( class_exists('WooCommerce') ) {
				// Reset status from blog pages to false
				if ( is_shop() || is_product() || is_product_category() || is_product_tag() || is_cart() || is_checkout() || is_account_page() ) {
					$display_status = false;
					// Check Woo pages
					$display_status = ( is_shop() || is_product() || is_product_category() || is_product_tag() ) && get_theme_mod( 'tfm_ad_site_header_display_shop', true ) ? true : false;
				}
			}

			if ( false === $display_status ) {

				return false;
			}

		if ( get_theme_mod( tfm_get_theme_textdomain() . '_header_layout') === 'default-advert') {

			$code = '' !== get_theme_mod('tfm_ad_site_header_code', '') ? get_theme_mod( 'tfm_ad_site_header_code' ) : '';

			$html = $code ? '<div class="tfm-site-header-sidebar advert code">' : '' ;
			$html .= $code ? $code : ''; // Do not escape
			$html .= $code ? '</div>' : '';

			echo $html;

		}
	}

	add_action('tfm_header_right', 'tfm_site_header_ad_code', 1 );

	// Before Footer

	function tfm_before_footer_ad_code() {

		$display_status = ( is_front_page() && get_theme_mod( 'tfm_ad_before_footer_display_home', true ) ) || ( is_home() && 'page' === get_option( 'show_on_front') && get_theme_mod( 'tfm_ad_before_footer_display_blog', true ) ) || ( ( is_archive() || is_search() ) && get_theme_mod( 'tfm_ad_before_footer_display_archive', true ) ) || ( is_single() && get_theme_mod( 'tfm_ad_before_footer_display_single', true ) ) || ( is_page() && ! is_front_page() && get_theme_mod( 'tfm_ad_before_footer_display_page', true ) ) ? true : false;

		if ( class_exists('WooCommerce') ) {
			// Reset status from blog pages to false
			if ( is_shop() || is_product() || is_product_category() || is_product_tag() || is_cart() || is_checkout() || is_account_page() ) {
				$display_status = false;
				// Check Woo pages
				$display_status = ( is_shop() || is_product() || is_product_category() || is_product_tag() ) && get_theme_mod( 'tfm_ad_before_footer_display_shop', true ) ? true : false;
			}
		}

		if ( false === $display_status ) {

			return false;
		}

		$hidden_mobile = get_theme_mod( 'tfm_ad_before_footer_display_mobile', true ) ? '' : ' hidden-mobile';
		$code = '' !== get_theme_mod('tfm_ad_before_footer_code', '') ? get_theme_mod( 'tfm_ad_before_footer_code' ) : '';

		$html = $code ? '<div class="tfm-before-footer-advert advert code' . esc_attr( $hidden_mobile) . '">' : '' ;
		$html .= $code ? $code : ''; // Do not escape
		$html .= $code ? '</div>' : '';

		echo $html;
	}

	add_action('tfm_before_footer', 'tfm_before_footer_ad_code', 1 );


	// ========================================================
	// Add banner class to body tag
	// ========================================================

	if ( ! function_exists('tfm_adverts_body_class') ) {

		function tfm_adverts_body_class( $classes ) {

			// Return empty class array if no banner or widget
			if ( ! is_active_sidebar( 'after-header-sidebar' ) && ( '' === get_theme_mod('tfm_ad_after_header_image', '' ) || '' === get_theme_mod('tfm_ad_after_header_image_2x', '' ) ) && '' === get_theme_mod( 'tfm_ad_after_header_code', '' ) ) {
				return $classes;
			}

			// Add banner class
			if ( ( is_front_page() && get_theme_mod( 'tfm_ad_after_header_display_home', true ) ) || ( is_home() && 'page' === get_option( 'show_on_front') && get_theme_mod( 'tfm_ad_after_header_display_blog', true ) ) || ( ( is_archive() || is_search() ) && get_theme_mod( 'tfm_ad_after_header_display_archive', true ) ) || ( is_single() && get_theme_mod( 'tfm_ad_after_header_display_single', true ) ) || ( is_page() && ! is_front_page() && get_theme_mod( 'tfm_ad_after_header_display_page', true ) ) ) {
				$classes[] = 'has-tfm-ad-after-header';
			}

			return $classes;
		}
		
		add_filter( 'body_class', 'tfm_adverts_body_class', 20 );

	}

	// ========================================================
	// Autoads (insert code after head tag)
	// ========================================================

	if ( ! function_exists('tfm_wp_head_tag_code')) {

		function tfm_wp_head_tag_code() {

			$code = '' !== get_theme_mod('tfm_ad_head_tag_code', '') ? get_theme_mod( 'tfm_ad_head_tag_code' ) : '';
			echo $code . "\n";
		}

		add_action('wp_head', 'tfm_wp_head_tag_code');
	}

} // End if Ads enabled in plugin settings

// ========================================================
// Featured Posts
// ========================================================

if ( ! function_exists( 'tfm_featured_posts' ) ) {

	function tfm_featured_posts( $forced_request = false, $return = false ) {

		include( TFM_THEME_BOOST_PLUGIN_DIR . 'inc/featured-posts.php' );

		if ( $return ) {
			return $html;
		} else {
			echo $html;
		}

	}

}
add_action( 'tfm_after_header', 'tfm_featured_posts', 20 );

// ========================================================
// Add featured posts class to body tag
// ========================================================

if ( ! function_exists('tfm_featured_posts_body_class') ) {

	function tfm_featured_posts_body_class( $classes ) {

		if ( function_exists( 'tfm_featured_posts') && apply_filters( 'tfm_theme_supports_featured_posts', false ) && get_theme_mod( 'tfm_featured_posts', false ) && '' !== tfm_featured_posts( true, true )) {
			$classes[]  = 'has-tfm-featured-posts';
		}

		return $classes;
	}
	
	add_filter( 'body_class', 'tfm_featured_posts_body_class', 20 );

}

// ========================================================
// Add featured posts sash to featured posts
// ========================================================

if ( ! function_exists( 'tfm_featured_posts_sash' ) ) {

	function tfm_featured_posts_sash( ) {

		if ( function_exists('tfm_custom_meta_box') && get_post_meta( get_the_ID(), 'tfm_featured_post', true ) && get_theme_mod( 'tfm_featured_posts_sash', false ) ) :

			echo '<span class="format-sticky format-featured"><i class="icon-star"></i><span>' . esc_html__( 'featured', 'tfm-theme-boost' ) . '</span></span>';

		endif;


	}

	add_action( 'tfm_append_formats_key', 'tfm_featured_posts_sash', 10 );


}


?>