<?php

/**
 * 340 Media: Social Media Customizer Settings
 *
 * @package WordPress
 * @subpackage 3FortyMedia
 * @since 1.0
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Register customizer settings

function tfm_social_media_customize_register( $wp_customize ) {

    require_once 'custom_controls.php';

    $wp_customize->add_panel( 'tfm_social_media', array(
          'title'    => esc_html__( 'TFM: Social Media Settings', 'tfm-social-plugin' ),
          'priority' => 160,
          ) );

	$wp_customize->add_section( 'tfm_social_media_channels', array(
		'title'    => esc_html__( 'Social Media Channels', 'tfm-social-plugin' ),
		'description'    => esc_html__( 'Enter the full URLs of your social media channels. These URLs are used in Widgets and theme options', 'tfm-social-plugin' ),
		'priority' => 160,
        'panel' => 'tfm_social_media',
	) );

	 $social_sites = tfm_get_social_sites( );

	 foreach( $social_sites as $social_site ) {

	 	 // Add Setting
	     $wp_customize->add_setting( $social_site, array(
	         'type' => 'theme_mod',
	         'capability' => 'edit_theme_options',
	         'sanitize_callback' => 'esc_url_raw',
	     ));

	     // Control Options
	     $wp_customize->add_control( $social_site, array(
	         'label' => ucwords( str_replace('tfm_social_site_', '', $social_site ) ),
	         'section' => 'tfm_social_media_channels',
	         'type' => 'text',
	     ));
	 }

    // ========================================================
    // Header Social Icons
    // ========================================================

    // ========================================================
    // Seperator
    // ========================================================
    $wp_customize->add_setting('tfm_header_social_seperator', array(
        'default'           => '',
        'sanitize_callback' => 'esc_html',
    ));
    $wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, 'tfm_header_social_seperator', array(
        'settings'      => 'tfm_header_social_seperator',
        'section'       => 'tfm_social_media',
    )));

    $wp_customize->add_setting( 'tfm_header_social', array(
        'default'           => false,
        'sanitize_callback' => 'tfm_sanitize_checkbox',
    ) );

    $wp_customize->add_control( 'tfm_header_social', array(
        'label'       => esc_html__( 'Show Social Icons in Site Header', 'mura' ),
        'section'     => 'tfm_social_media_channels',
        'type'        => 'checkbox',
        'priority' => 10,
    ) );

      // Icon Style
    $wp_customize->add_setting( 'tfm_header_social_icon_style', array(
        'default'           => 'icon-background',
        'sanitize_callback' => 'tfm_sanitize_radio',
    ) );

    $wp_customize->add_control( 'tfm_header_social_icon_style', array(
        'label'       => esc_html__( 'Icon Style', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_channels',
        'type'        => 'radio',
        'priority' => 10,
        'choices'     => array(
            'icon-background' => esc_html__( 'With Background', 'tfm-social-plugin' ),
            'icon' => esc_html__( 'No Background', 'tfm-social-plugin' ),
            'icon-border' => esc_html__( 'With Border', 'tfm-social-plugin' ),
        ),
    ) );

     // Icon Branding
    $wp_customize->add_setting( 'tfm_header_social_icon_color_scheme', array(
        'default'           => 'brand',
        'sanitize_callback' => 'tfm_sanitize_radio',
    ) );

    $wp_customize->add_control( 'tfm_header_social_icon_color_scheme', array(
        'label'       => esc_html__( 'Icon Colour Scheme', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_channels',
        'type'        => 'radio',
        'priority' => 10,
        'choices'     => array(
            'theme' => esc_html__( 'Theme Colour Scheme', 'tfm-social-plugin' ),
            'brand' => esc_html__( 'Brand Colour Scheme', 'tfm-social-plugin' ),
        ),
    ) );

    // Round
    $wp_customize->add_setting( 'tfm_header_social_icon_round', array(
        'default'           => false,
        'sanitize_callback' => 'tfm_sanitize_checkbox',
    ) );

    $wp_customize->add_control( 'tfm_header_social_icon_round', array(
        'label'       => esc_html__( 'Round Icons', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_channels',
        'type'        => 'checkbox',
        'priority' => 10,
    ) );

    // ========================================================
    // Footer Social Icons
    // ========================================================

    // ========================================================
    // Seperator
    // ========================================================
    $wp_customize->add_setting('tfm_footer_social_seperator', array(
        'default'           => '',
        'sanitize_callback' => 'esc_html',
    ));
    $wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, 'tfm_footer_social_seperator', array(
        'settings'      => 'tfm_footer_social_seperator',
        'section'       => 'tfm_social_media_channels',
    )));

    $wp_customize->add_setting( 'tfm_footer_social', array(
        'default'           => false,
        'sanitize_callback' => 'tfm_sanitize_checkbox',
    ) );

    $wp_customize->add_control( 'tfm_footer_social', array(
        'label'       => esc_html__( 'Show Social Icons in Site Footer', 'mura' ),
        'section'     => 'tfm_social_media_channels',
        'type'        => 'checkbox',
        'priority' => 10,
    ) );

       // Icon Style
    $wp_customize->add_setting( 'tfm_footer_social_icon_style', array(
        'default'           => 'icon-background',
        'sanitize_callback' => 'tfm_sanitize_radio',
    ) );

    $wp_customize->add_control( 'tfm_footer_social_icon_style', array(
        'label'       => esc_html__( 'Icon Style', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_channels',
        'type'        => 'radio',
        'priority' => 10,
        'choices'     => array(
            'icon-background' => esc_html__( 'With Background', 'tfm-social-plugin' ),
            'icon' => esc_html__( 'No Background', 'tfm-social-plugin' ),
            'icon-border' => esc_html__( 'With Border', 'tfm-social-plugin' ),
        ),
    ) );

     // Icon Branding
    $wp_customize->add_setting( 'tfm_footer_social_icon_color_scheme', array(
        'default'           => 'brand',
        'sanitize_callback' => 'tfm_sanitize_radio',
    ) );

    $wp_customize->add_control( 'tfm_footer_social_icon_color_scheme', array(
        'label'       => esc_html__( 'Icon Colour Scheme', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_channels',
        'type'        => 'radio',
        'priority' => 10,
        'choices'     => array(
            'theme' => esc_html__( 'Theme Colour Scheme', 'tfm-social-plugin' ),
            'brand' => esc_html__( 'Brand Colour Scheme', 'tfm-social-plugin' ),
        ),
    ) );

    // Round
    $wp_customize->add_setting( 'tfm_footer_social_icon_round', array(
        'default'           => false,
        'sanitize_callback' => 'tfm_sanitize_checkbox',
    ) );

    $wp_customize->add_control( 'tfm_footer_social_icon_round', array(
        'label'       => esc_html__( 'Round Icons', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_channels',
        'type'        => 'checkbox',
        'priority' => 10,
    ) );

    // ========================================================
    // Seperator
    // ========================================================
    $wp_customize->add_setting('tfm_social_settings_customize_separator', array(
        'default'           => '',
        'sanitize_callback' => 'esc_html',
    ));
    $wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, 'tfm_social_settings_customize_separator', array(
        'settings'      => 'tfm_social_settings_customize_separator',
        'section'       => 'tfm_social_media',
        'priority' => 20,
    )));

    // ========================================================
    // Post share settings
    // ========================================================

    $wp_customize->add_section( 'tfm_social_media_share_settings', array(
        'title'    => esc_html__( 'Sharing', 'tfm-social-plugin' ),
        'priority' => 160,
        'panel' => 'tfm_social_media',
    ) );

    // ========================================================
    // Info Header
    // ========================================================
    $wp_customize->add_setting('tfm_share_post_header', array(
        'default'           => '',
        'sanitize_callback' => 'tfm_sanitize_text',
     
    ));
    $wp_customize->add_control(new tfm_Info_Custom_Control($wp_customize, 'tfm_share_post_header', array(
        'label'         => esc_html__('Single Post & Page Share Icons', 'tfm-social-plugin'),
        'settings'      => 'tfm_share_post_header',
        'section'       => 'tfm_social_media_share_settings',
        'priority' => 20,
    )));

     /**
      * Toggle channels
      * Styling Settings
      * Colour Settings
      */

     $share_sites = tfm_get_share_sites();

     foreach( $share_sites as $share_site ) {

        // Append mobile only
        $append_mobile_only = '';

        if ( $share_site === 'whatsapp' ) {
            $append_mobile_only = ' (' . esc_html__( 'Mobile Only', 'tfm-social-plugin' ) . ')';
        }

         // Add Setting
         $wp_customize->add_setting( 'tfm_share_post_' . $share_site, array(
             'default' => true,
             'sanitize_callback' => 'tfm_sanitize_checkbox',
         ));

         // Control Options
         $wp_customize->add_control( 'tfm_share_post_' . $share_site, array(
             'label' => ucwords( $share_site . $append_mobile_only ),
             'section' => 'tfm_social_media_share_settings',
             'type' => 'checkbox',
             'priority' => 20,
         ));
     }

     // Post Share Icon Style
    $wp_customize->add_setting( 'tfm_share_post_icon_style', array(
        'default'           => 'icon-background',
        'sanitize_callback' => 'tfm_sanitize_radio',
    ) );

    $wp_customize->add_control( 'tfm_share_post_icon_style', array(
        'label'       => esc_html__( 'Icon Style', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_share_settings',
        'type'        => 'radio',
        'priority' => 20,
        'choices'     => array(
            'icon-background' => esc_html__( 'With Background', 'tfm-social-plugin' ),
            'icon' => esc_html__( 'No Background', 'tfm-social-plugin' ),
            'icon-border' => esc_html__( 'With Border', 'tfm-social-plugin' ),
        ),
    ) );

     // Post Share Icon Branding
    $wp_customize->add_setting( 'tfm_share_post_icon_color_scheme', array(
        'default'           => 'theme',
        'sanitize_callback' => 'tfm_sanitize_radio',
    ) );

    $wp_customize->add_control( 'tfm_share_post_icon_color_scheme', array(
        'label'       => esc_html__( 'Icon Colour Scheme', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_share_settings',
        'type'        => 'radio',
        'priority' => 20,
        'choices'     => array(
            'theme' => esc_html__( 'Theme Colour Scheme', 'tfm-social-plugin' ),
            'brand' => esc_html__( 'Brand Colour Scheme', 'tfm-social-plugin' ),
        ),
    ) );

    // Post Share Text
    $wp_customize->add_setting( 'tfm_share_post_icon_round', array(
        'default'           => false,
        'sanitize_callback' => 'tfm_sanitize_checkbox',
    ) );

    $wp_customize->add_control( 'tfm_share_post_icon_round', array(
        'label'       => esc_html__( 'Round Icons', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_share_settings',
        'type'        => 'checkbox',
        'priority' => 20,
    ) );

    // Post Share Text
    $wp_customize->add_setting( 'tfm_share_post_icon_text', array(
        'default'           => false,
        'sanitize_callback' => 'tfm_sanitize_checkbox',
    ) );

    $wp_customize->add_control( 'tfm_share_post_icon_text', array(
        'label'       => esc_html__( 'Show Icon Text', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_share_settings',
        'type'        => 'checkbox',
        'priority' => 20,
    ) );

    // Post Share Text
    $wp_customize->add_setting( 'tfm_share_posts', array(
        'default'           => true,
        'sanitize_callback' => 'tfm_sanitize_checkbox',
    ) );

    $wp_customize->add_control( 'tfm_share_posts', array(
        'label'       => esc_html__( 'Share Posts', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_share_settings',
        'type'        => 'checkbox',
        'priority' => 20,
    ) );

    // Post Share Text
    $wp_customize->add_setting( 'tfm_share_pages', array(
        'default'           => false,
        'sanitize_callback' => 'tfm_sanitize_checkbox',
    ) );

    $wp_customize->add_control( 'tfm_share_pages', array(
        'label'       => esc_html__( 'Share Pages', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_share_settings',
        'type'        => 'checkbox',
        'priority' => 20,
    ) );

    if ( class_exists('WooCommerce') ) {

        // Product Share Text
        $wp_customize->add_setting( 'tfm_share_products', array(
            'default'           => false,
            'sanitize_callback' => 'tfm_sanitize_checkbox',
        ) );

        $wp_customize->add_control( 'tfm_share_products', array(
            'label'       => esc_html__( 'Share Products', 'tfm-social-plugin' ),
            'section'     => 'tfm_social_media_share_settings',
            'type'        => 'checkbox',
            'priority' => 20,
        ) );

    }

    // Post Share Position
    $wp_customize->add_setting( 'tfm_single_share_post_position', array(
        'default'           => 'bottom',
        'sanitize_callback' => 'tfm_sanitize_select',
    ) );

    $wp_customize->add_control( 'tfm_single_share_post_position', array(
        'label'       => esc_html__( 'Share Icons Position', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_share_settings',
        'type'        => 'select',
        'priority' => 20,
        'choices'     => array(
            'side-bottom' => esc_html__( 'Side and Bottom', 'tfm-social-plugin' ),
            'side' => esc_html__( 'Side', 'tfm-social-plugin' ),
            'bottom' => esc_html__( 'Bottom', 'tfm-social-plugin' ),
            'top' => esc_html__( 'Top', 'tfm-social-plugin' ),
            'top-bottom' => esc_html__( 'Top and Bottom', 'tfm-social-plugin' ),
        ),
    ) );


    if ( apply_filters( 'tfm_social_plugin_theme_supports_share_blog_list_posts', false ) ):

        // ========================================================
        // Archive Post share settings
        // ========================================================

        // ========================================================
        // Seperator
        // ========================================================
        $wp_customize->add_setting('tfm_archive_social_settings_customize_separator', array(
            'default'           => '',
            'sanitize_callback' => 'esc_html',
        ));
        $wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, 'tfm_archive_social_settings_customize_separator', array(
            'settings'      => 'tfm_archive_social_settings_customize_separator',
            'section'       => 'tfm_social_media_share_settings',
            'priority' => 25,
        )));

        // ========================================================
        // Info Header
        // ========================================================
        $wp_customize->add_setting('tfm_share_archive_post_header', array(
            'default'           => '',
            'sanitize_callback' => 'tfm_sanitize_text',
         
        ));
        $wp_customize->add_control(new tfm_Info_Custom_Control($wp_customize, 'tfm_share_archive_post_header', array(
            'label'         => esc_html__('Blog List Post Share Icons', 'tfm-social-plugin'),
            'settings'      => 'tfm_share_archive_post_header',
            'section'       => 'tfm_social_media_share_settings',
            'priority' => 25,
        )));

         /**
          * Toggle channels
          * Styling Settings
          * Colour Settings
          */

         $share_sites = tfm_get_share_sites();

         foreach( $share_sites as $share_site ) {

            // Append mobile only
            $append_mobile_only = '';

            if ( $share_site === 'whatsapp' ) {
                $append_mobile_only = ' (' . esc_html__( 'Mobile Only', 'tfm-social-plugin' ) . ')';
            }

             // Add Setting
             $wp_customize->add_setting( 'tfm_share_archive_post_' . $share_site, array(
                 'default' => false,
                 'sanitize_callback' => 'tfm_sanitize_checkbox',
             ));

             // Control Options
             $wp_customize->add_control( 'tfm_share_archive_post_' . $share_site, array(
                 'label' => ucwords( $share_site . $append_mobile_only ),
                 'section' => 'tfm_social_media_share_settings',
                 'type' => 'checkbox',
                 'priority' => 25,
             ));
         }

         // Post Share Icon Style
        $wp_customize->add_setting( 'tfm_share_archive_post_icon_style', array(
            'default'           => 'icon-background',
            'sanitize_callback' => 'tfm_sanitize_radio',
        ) );

        $wp_customize->add_control( 'tfm_share_archive_post_icon_style', array(
            'label'       => esc_html__( 'Icon Style', 'tfm-social-plugin' ),
            'section'     => 'tfm_social_media_share_settings',
            'type'        => 'radio',
            'priority' => 25,
            'choices'     => array(
                'icon-background' => esc_html__( 'With Background', 'tfm-social-plugin' ),
                'icon' => esc_html__( 'No Background', 'tfm-social-plugin' ),
                'icon-border' => esc_html__( 'With Border', 'tfm-social-plugin' ),
            ),
        ) );

         // Post Share Icon Branding
        $wp_customize->add_setting( 'tfm_share_archive_post_icon_color_scheme', array(
            'default'           => 'theme',
            'sanitize_callback' => 'tfm_sanitize_radio',
        ) );

        $wp_customize->add_control( 'tfm_share_archive_post_icon_color_scheme', array(
            'label'       => esc_html__( 'Icon Colour Scheme', 'tfm-social-plugin' ),
            'section'     => 'tfm_social_media_share_settings',
            'type'        => 'radio',
            'priority' => 25,
            'choices'     => array(
                'theme' => esc_html__( 'Theme Colour Scheme', 'tfm-social-plugin' ),
                'brand' => esc_html__( 'Brand Colour Scheme', 'tfm-social-plugin' ),
            ),
        ) );

        // Post Share Text
        $wp_customize->add_setting( 'tfm_share_archive_post_icon_round', array(
            'default'           => false,
            'sanitize_callback' => 'tfm_sanitize_checkbox',
        ) );

        $wp_customize->add_control( 'tfm_share_archive_post_icon_round', array(
            'label'       => esc_html__( 'Round Icons', 'tfm-social-plugin' ),
            'section'     => 'tfm_social_media_share_settings',
            'type'        => 'checkbox',
            'priority' => 25,
        ) );

        if ( class_exists('WooCommerce') && apply_filters( 'tfm_social_plugin_theme_supports_share_product_lists', false )) {

            // Product Share Text
            $wp_customize->add_setting( 'tfm_share_archive_products', array(
                'default'           => false,
                'sanitize_callback' => 'tfm_sanitize_checkbox',
            ) );

            $wp_customize->add_control( 'tfm_share_archive_products', array(
                'label'       => esc_html__( 'Share Products', 'tfm-social-plugin' ),
                'section'     => 'tfm_social_media_share_settings',
                'type'        => 'checkbox',
                'priority' => 25,
            ) );

        }

    endif; // Endif theme supports blog list share

    // ========================================================
    // Post share settings
    // ========================================================

    $wp_customize->add_section( 'tfm_social_media_author_bio', array(
        'title'    => esc_html__( 'Author Bio', 'tfm-social-plugin' ),
        'description'    => esc_html__( 'Set Author Social Media URLs in Users > Profile', 'tfm-social-plugin' ),
        'priority' => 160,
        'panel' => 'tfm_social_media',
    ) );

    // ========================================================
    // Seperator
    // ========================================================
    // $wp_customize->add_setting('tfm_author_social_settings_customize_separator', array(
    //     'default'           => '',
    //     'sanitize_callback' => 'esc_html',
    // ));
    // $wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, 'tfm_author_social_settings_customize_separator', array(
    //     'settings'      => 'tfm_author_social_settings_customize_separator',
    //     'section'       => 'tfm_social_media',
    //     'priority' => 30,
    // )));

    // ========================================================
    // Info Header
    // ========================================================
    // $wp_customize->add_setting('tfm_author_social_header', array(
    //     'default'           => '',
    //     'sanitize_callback' => 'tfm_sanitize_text',
     
    // ));
    // $wp_customize->add_control(new tfm_Info_Custom_Control($wp_customize, 'tfm_author_social_header', array(
    //     // 'label'         => esc_html__('Author Bio Social Icons', 'tfm-social-plugin'),
    //     'description'    => esc_html__( 'Set Author Social Media URLs in Users > Profile', 'tfm-social-plugin' ),
    //     'settings'      => 'tfm_author_social_header',
    //     'section'       => 'tfm_social_media',
    //     'priority' => 30,
    // )));

     // ========================================================
    // Author Social Icons
    // ========================================================

    $wp_customize->add_setting( 'tfm_archive_author_social', array(
        'default'           => false,
        'sanitize_callback' => 'tfm_sanitize_checkbox',
    ) );

    $wp_customize->add_control( 'tfm_archive_author_social', array(
        'label'       => esc_html__( 'Show Icons in Archive Author Bio', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_author_bio',
        'type'        => 'checkbox',
        'priority' => 30,
    ) );

    $wp_customize->add_setting( 'tfm_single_author_social', array(
        'default'           => true,
        'sanitize_callback' => 'tfm_sanitize_checkbox',
    ) );

    $wp_customize->add_control( 'tfm_single_author_social', array(
        'label'       => esc_html__( 'Show Icons in Single Author Bio', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_author_bio',
        'type'        => 'checkbox',
        'priority' => 30,
    ) );

    // Show Author Social Email
    $wp_customize->add_setting( 'tfm_single_author_social_email', array(
        'default'           => false,
        'sanitize_callback' => 'tfm_sanitize_checkbox',
    ) );

    // Control Options
    $wp_customize->add_control( 'tfm_single_author_social_email', array(
        'label'       => esc_html__( 'Author Bio Email Icon', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_author_bio',
        'type'        => 'checkbox',
        'priority' => 30,
    ) );

    // Post Share Icon Style
    $wp_customize->add_setting( 'tfm_author_social_icon_style', array(
        'default'           => 'icon-background',
        'sanitize_callback' => 'tfm_sanitize_radio',
    ) );

    $wp_customize->add_control( 'tfm_author_social_icon_style', array(
        'label'       => esc_html__( 'Icon Style', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_author_bio',
        'type'        => 'radio',
        'priority' => 30,
        'choices'     => array(
            'icon-background' => esc_html__( 'With Background', 'tfm-social-plugin' ),
            'icon' => esc_html__( 'No Background', 'tfm-social-plugin' ),
            'icon-border' => esc_html__( 'With Border', 'tfm-social-plugin' ),
        ),
    ) );

     // Post Share Icon Branding
    $wp_customize->add_setting( 'tfm_author_social_icon_color_scheme', array(
        'default'           => 'theme',
        'sanitize_callback' => 'tfm_sanitize_radio',
    ) );

    $wp_customize->add_control( 'tfm_author_social_icon_color_scheme', array(
        'label'       => esc_html__( 'Icon Colour Scheme', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_author_bio',
        'type'        => 'radio',
        'priority' => 30,
        'choices'     => array(
            'theme' => esc_html__( 'Theme Colour Scheme', 'tfm-social-plugin' ),
            'brand' => esc_html__( 'Brand Colour Scheme', 'tfm-social-plugin' ),
        ),
    ) );

    // Round
    $wp_customize->add_setting( 'tfm_author_social_icon_round', array(
        'default'           => false,
        'sanitize_callback' => 'tfm_sanitize_checkbox',
    ) );

    $wp_customize->add_control( 'tfm_author_social_icon_round', array(
        'label'       => esc_html__( 'Round Icons', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_author_bio',
        'type'        => 'checkbox',
        'priority' => 30,
    ) );

    // Post Share Text
    $wp_customize->add_setting( 'tfm_author_social_icon_text', array(
        'default'           => false,
        'sanitize_callback' => 'tfm_sanitize_checkbox',
    ) );

    $wp_customize->add_control( 'tfm_author_social_icon_text', array(
        'label'       => esc_html__( 'Show Icon Text', 'tfm-social-plugin' ),
        'section'     => 'tfm_social_media_author_bio',
        'type'        => 'checkbox',
        'priority' => 30,
    ) );

}

add_action( 'customize_register', 'tfm_social_media_customize_register' );


?>