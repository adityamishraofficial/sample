<?php
/**
 * 3FortyMedia Hero Plugin
 *
 * @since 1.0
 * @version 1.1
 */

?>

<?php 

include( TFM_HERO__PLUGIN_DIR . 'inc/vars.php' );

?>

<?php if ( $hero_active) : ?>

	<?php if ( 'true' === $hero_background ): ?>
	<div class="tfm-hero-background-wrapper"<?php echo wp_kses( $custom_color['hero_background'], $allowed_html ) ?>>
	<?php endif; ?>

<div id="tfm-hero" class="tfm-hero post-grid <?php echo esc_attr( $layout . $cols . $has_post_count . $slick . $has_post_thumbnails  ); ?>" data-slides="<?php echo esc_attr( $post_num ); ?>" data-posts="<?php echo esc_attr( $post_num ); ?>" data-slidestoshow="<?php echo esc_attr( $slides_to_show ); ?>" data-maxslides="<?php echo esc_attr( $max_slides_supported ); ?>" data-thumbnail="<?php echo esc_attr( $thumbnail ); ?>" data-aspectratio="<?php echo esc_attr( get_theme_mod( 'tfm_hero_thumbnail_aspect_ratio', 'wide' ) ); ?>" data-initial-status="<?php echo esc_attr( $active_status ); ?>" data-poststyle="<?php echo esc_attr( $post_style ); ?>" data-fullwidth="<?php echo esc_attr( $full_width ); ?>" data-arrows="<?php echo esc_attr( $arrows ); ?>" data-pagination="<?php echo esc_attr( $pagination ); ?>" data-centermode="<?php echo esc_attr( $centermode ); ?>" data-margins="<?php echo esc_attr( $margins ); ?>" data-autoplay-speed="<?php echo esc_attr( $autoplay_speed ); ?>" data-speed="<?php echo esc_attr( $speed ); ?>">
	
<?php 

	$posts_query = new WP_Query( tfm_hero_query_args() );

    if( $posts_query->have_posts( ) ):

    $count = 0;

    while ( $posts_query->have_posts( ) ) : $posts_query->the_post();

    	$count++;

		// ========================================================
		// Thumbnail class
		// ========================================================

    	$has_post_thumbnail = ( '' !== get_the_post_thumbnail() && false !== get_theme_mod( 'tfm_hero_thumbnail', true ) ? ' has-post-media has-post-thumbnail thumbnail-large thumbnail-' . get_theme_mod( 'tfm_hero_thumbnail_aspect_ratio', 'wide' ) : '' );

    	// Offset variable thumbnail size

    	if ( 'grid-offset' === get_theme_mod( 'tfm_hero_layout', 'grid' ) || 'grid-offset-half' === get_theme_mod( 'tfm_hero_layout', 'grid' ) || 'grid-offset-sides' === get_theme_mod( 'tfm_hero_layout', 'grid' ) ) {

    		if ( 'grid-offset' === get_theme_mod( 'tfm_hero_layout', 'grid' ) || 'grid-offset-half' === get_theme_mod( 'tfm_hero_layout', 'grid' ) ) {
    			$thumbnail = $count === 1 ? 'large' : 'medium_large';
    		} else {
    			$thumbnail = $count === 3 ? 'large' : 'medium_large';
    		}

    	}

    	// ========================================================
		// Open aside wrapper for offset layouts
		// ========================================================

    	if ( ( ( get_theme_mod( 'tfm_hero_layout', 'grid' ) === 'grid-offset' || get_theme_mod( 'tfm_hero_layout', 'grid' ) === 'grid-offset-half' ) && $post_num > apply_filters( 'tfm_hero_aside_wrapper_start', 2 ) && $count === apply_filters( 'tfm_hero_aside_wrapper_start', 2 ) ) || get_theme_mod( 'tfm_hero_layout', 'grid' ) === 'grid-offset-sides' && ( $count === 1 || $count === 4 ) ):

    	$wrapper_open = true; ?>

    	<div class="tfm-hero-offset-wrapper post-grid">

    	<?php endif; ?>

    	<?php 

		// ========================================================
		// Assign post class to cover/default mix styles
		// ========================================================

    	// Initially set to cover
		if ( $meta_var['style'] === 'cover-default') {
			$meta_vars = str_replace('cover-default', 'cover', $meta_vars);
		}

		// Remove cover style for offset
		if ( $meta_var['style'] === 'cover-default' && $wrapper_open ) {
			$meta_vars = str_replace('cover', 'cover-default', $meta_vars);
		} ?>

    	<article class="post article hero-entry<?php echo esc_attr( $has_post_thumbnail . $meta_vars ); ?>">

    		<?php if ( get_theme_mod( 'tfm_hero_post_count', false ) ): ?>

    			<div class="formats-key">

					<span class="format-count post-count"<?php echo wp_kses( $custom_color['count_color'], $allowed_html ) ?>><?php echo esc_html( $count ); ?></span>

				</div>

			<?php endif; ?>

    		<div class="post-inner"<?php echo wp_kses( $custom_color['post_background'], $allowed_html ) ?>>

    			<?php if ( $has_post_thumbnail ): ?>
    		<div class="thumbnail-wrapper">
        		<figure class="post-thumbnail">
					<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( $thumbnail ); ?></a>
				</figure>
			</div>

		<?php endif; ?>

			<div class="entry-wrapper">

				<header class="entry-header">

					<?php tfm_hero_entry_header_open(); ?>

					<?php if ( get_theme_mod( 'tfm_hero_entry_meta_category', true ) ): ?>

					<div class="entry-meta before-title"<?php echo wp_kses( $custom_color['entry_meta'], $allowed_html ) ?>>

							<?php if ( function_exists( 'tfm_get_category' ) ) {

						tfm_get_category( get_theme_mod( 'tfm_hero_entry_meta_category_slugs', 1 ), get_theme_mod( 'tfm_hero_entry_meta_in', true ), 'tfm_hero' ); 

					} else {

						the_category();

					} ?>

					</div><!-- .entry-meta -->

				<?php endif; ?>

				<?php if ( get_theme_mod( 'tfm_hero_entry_title', true ) ): ?>

					<?php the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark"' . wp_kses( $custom_color['entry_title'], $allowed_html ) . '>', '</a></h3>' ); ?>

				<?php endif; ?>

				<?php tfm_hero_after_entry_title(); ?>

				<?php if ( $has_meta_after_title ) : ?>

					<div class="entry-meta after-title"<?php echo wp_kses( $custom_color['entry_meta'], $allowed_html ) ?>>

						<ul class="after-title-meta">

							<?php tfm_hero_prepend_after_title_meta(); ?>

							<?php tfm_hero_get_entry_meta(); ?>

							<?php tfm_hero_append_after_title_meta(); ?>

						</ul>

					</div>

				<?php endif; ?>

				<?php

				if ( function_exists( 'tfm_ratings' ) && ( get_theme_mod( 'tfm_hero_tfm_star_rating', false ) || get_theme_mod( 'tfm_hero_tfm_points_rating', false ) || get_theme_mod( 'tfm_hero_tfm_percent_rating', false ) || get_theme_mod( 'tfm_hero_tfm_scale_rating', false ) ) ) {

					tfm_ratings( get_theme_mod( 'tfm_hero_tfm_star_rating', false ), get_theme_mod( 'tfm_hero_tfm_points_rating', false ), get_theme_mod( 'tfm_hero_tfm_percent_rating', false ), get_theme_mod( 'tfm_hero_tfm_scale_rating', false ), true ); // $star_rating, $points_rating, $percent_rating, $scale_rating $forced_request

				} ?>

				<?php tfm_hero_after_after_title_meta(); ?>

				<?php tfm_hero_entry_header_close(); ?>

				</header><!-- .entry-header -->

				<?php if ( get_theme_mod( 'tfm_hero_excerpt', false ) ) : ?>
				<div class="entry-content excerpt"<?php echo wp_kses( $custom_color['entry_content'], $allowed_html ) ?>>
					<?php echo get_the_excerpt( ); ?>
				</div>
				<?php endif; ?>

				<?php

				// Read more

				if ( get_theme_mod( 'tfm_hero_read_more', false ) )  : ?>

					<ul class="entry-read-more"<?php echo wp_kses( $custom_color['border_color'], $allowed_html ) ?>>

						<li class="read-more-button"<?php echo wp_kses( $custom_color['border_color'], $allowed_html ) ?>><a href="<?php echo esc_url( get_permalink() ); ?>" class="button read-more"<?php echo wp_kses( $custom_color['button_background'], $allowed_html ) ?>><span<?php echo wp_kses( $custom_color['button_color'], $allowed_html ) ?>><?php echo esc_html__( 'Continue Reading', 'tfm-theme-boost'); ?></span></a></li>

						<?php

						if ( function_exists( 'tfm_read_time' ) && get_theme_mod( 'tfm_hero_entry_meta_read_time', false ) ) {

							tfm_read_time( true );

						} ?>

						<?php tfm_hero_after_continue_reading_button(); ?>

					</ul>

				<?php endif; ?>

				</div><!-- .entry-wrapper -->
			</div><!-- .post-inner -->
			
		</article><!-- .hero-entry -->

		<?php 

		// Grid offset side close first offset wrapper

		if ( $wrapper_open && get_theme_mod( 'tfm_hero_layout', 'grid' ) === 'grid-offset-sides' && $count === 2 ) {
		echo '</div>';
		$wrapper_open = false;
		}

		?>


    <?php 

	endwhile;

	// Close aside wrapper if open

	if ( $wrapper_open ) {
		echo '</div>';
	}

    endif;

    wp_reset_postdata(); // Always reset

 	?>

 	<?php if ( 'true' === $hero_background ): ?>
	</div>
	<?php endif; ?>

</div>

<?php endif; ?>