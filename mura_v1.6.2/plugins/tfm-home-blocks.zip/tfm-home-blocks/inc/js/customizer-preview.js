/**
 * Customizer Live Preview
 *
 * Reloads changes on Theme Customizer Preview asynchronously
 *
 */
 
( function( $ ) {

     // Title
     wp.customize( 'tfm_home_block_1_title', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_1 .page-title' ).text( to );
            if ( '' !== to ) {
	            $( '.tfm_home_block_1' ).addClass( 'has-title' );
	        } else {
	        	$( '.tfm_home_block_1' ).removeClass( 'has-title' );
	        }
        } );
    } );

     // Subtitle
     wp.customize( 'tfm_home_block_1_subtitle', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_1 .sub-title' ).text( to );
            if ( '' !== to ) {
	            $( '.tfm_home_block_1' ).addClass( 'has-subtitle' );
	        } else {
	        	$( '.tfm_home_block_1' ).removeClass( 'has-subtitle' );
	        }
        } );
    } );

     // Link More Text
     wp.customize( 'tfm_home_block_1_link_more_text', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_1 .tfm-link-more a' ).text( to );
            if ( '' !== to ) {
	            $( '.tfm_home_block_1' ).addClass( 'has-link-more' );
	        } else {
	        	$( '.tfm_home_block_1' ).removeClass( 'has-link-more' );
	        }
        } );
    } );

     // Thumbnail aspect ratio
    wp.customize( 'tfm_home_block_1_image_size', function( value ) {
        value.bind( function( newval ) {
            if ( 'wide' === newval ) {
                $( '.tfm_home_block_1 .post-grid .article' ).addClass( 'thumbnail-wide' );
                $( '.tfm_home_block_1 .post-grid .article' ).removeClass( 'thumbnail-landscape thumbnail-square thumbnail-portrait thumbnail-uncropped thumbnail-hero' );
            } else if ( 'landscape' === newval ) {
                $( '.tfm_home_block_1 .post-grid .article' ).addClass( 'thumbnail-landscape' );
                $( '.tfm_home_block_1 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-square thumbnail-portrait thumbnail-uncropped thumbnail-hero' );
            } else if ( 'portrait' === newval ) {
                $( '.tfm_home_block_1 .post-grid .article' ).addClass( 'thumbnail-portrait' );
                $( '.tfm_home_block_1 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-square thumbnail-landscape thumbnail-uncropped thumbnail-hero' );
            } else if ( 'square' === newval ) {
                $( '.tfm_home_block_1 .post-grid .article' ).addClass( 'thumbnail-square' );
                $( '.tfm_home_block_1 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-uncropped thumbnail-hero' );
            } else if ( 'uncropped' === newval ) {
                $( '.tfm_home_block_1 .post-grid .article' ).addClass( 'thumbnail-uncropped' );
                $( '.tfm_home_block_1 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-square thumbnail-hero' );
            } else if ( 'hero' === newval ) {
                $( '.tfm_home_block_1 .post-grid .article' ).addClass( 'thumbnail-hero' );
                $( '.tfm_home_block_1 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-square thumbnail-uncropped' );
            }
        } );
    } );

    /*---------------------------------------*/
	/* Colours                               */
	/*---------------------------------------*/

	// Title
    wp.customize( 'tfm_home_block_1_title_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_1 .tfm-post-block-title, .tfm_home_block_1 .tfm-post-block-title a' ).css( 'color', newval );
        } );
    } );

    // SubTitle
    wp.customize( 'tfm_home_block_1_subtitle_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_1 .sub-title, .tfm_home_block_1 .sub-title a' ).css( 'color', newval );
        } );
    } );

    // More Link
    wp.customize( 'tfm_home_block_1_link_more_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_1 .tfm-link-more a, .tfm_home_block_1 .tfm-link-more a::after' ).css( 'color', newval );
        } );
    } );

    // Post Background
    wp.customize( 'tfm_home_block_1_post_background', function( value ) {
        value.bind( function( newval ) {
            if ( '' !== newval ) {
                $( '.tfm_home_block_1 .post-grid .article' ).addClass( 'has-background' );
                $( '.tfm_home_block_1 .post-grid .article.has-background:not(.cover) .entry-wrapper, .tfm_home_block_1 .post-grid .article.has-background.cover:not(.has-post-thumbnail) .entry-wrapper' ).css( 'background-color', newval );
            } else {
                $( '.tfm_home_block_1 .post-grid .article.has-background:not(.cover) .entry-wrapper, .tfm_home_block_1 .post-grid .article.has-background.cover:not(.has-post-thumbnail) .entry-wrapper' ).css( 'background-color', 'transparent' );
                $( '.tfm_home_block_1 .post-grid .article.has-background' ).removeClass( 'has-background' );
            }
        } );
    } );

    // Block 2

    // Title
     wp.customize( 'tfm_home_block_2_title', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_2 .page-title' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_2' ).addClass( 'has-title' );
            } else {
                $( '.tfm_home_block_2' ).removeClass( 'has-title' );
            }
        } );
    } );

     // Subtitle
     wp.customize( 'tfm_home_block_2_subtitle', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_2 .sub-title' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_2' ).addClass( 'has-subtitle' );
            } else {
                $( '.tfm_home_block_2' ).removeClass( 'has-subtitle' );
            }
        } );
    } );

     // Link More Text
     wp.customize( 'tfm_home_block_2_link_more_text', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_2 .tfm-link-more a' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_2' ).addClass( 'has-link-more' );
            } else {
                $( '.tfm_home_block_2' ).removeClass( 'has-link-more' );
            }
        } );
    } );

     // Thumbnail aspect ratio
    wp.customize( 'tfm_home_block_2_image_size', function( value ) {
        value.bind( function( newval ) {
            if ( 'wide' === newval ) {
                $( '.tfm_home_block_2 .post-grid .article' ).addClass( 'thumbnail-wide' );
                $( '.tfm_home_block_2 .post-grid .article' ).removeClass( 'thumbnail-landscape thumbnail-square thumbnail-portrait thumbnail-uncropped thumbnail-hero' );
            } else if ( 'landscape' === newval ) {
                $( '.tfm_home_block_2 .post-grid .article' ).addClass( 'thumbnail-landscape' );
                $( '.tfm_home_block_2 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-square thumbnail-portrait thumbnail-uncropped thumbnail-hero' );
            } else if ( 'portrait' === newval ) {
                $( '.tfm_home_block_2 .post-grid .article' ).addClass( 'thumbnail-portrait' );
                $( '.tfm_home_block_2 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-square thumbnail-landscape thumbnail-uncropped thumbnail-hero' );
            } else if ( 'square' === newval ) {
                $( '.tfm_home_block_2 .post-grid .article' ).addClass( 'thumbnail-square' );
                $( '.tfm_home_block_2 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-uncropped thumbnail-hero' );
            } else if ( 'uncropped' === newval ) {
                $( '.tfm_home_block_2 .post-grid .article' ).addClass( 'thumbnail-uncropped' );
                $( '.tfm_home_block_2 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-square thumbnail-hero' );
            } else if ( 'hero' === newval ) {
                $( '.tfm_home_block_2 .post-grid .article' ).addClass( 'thumbnail-hero' );
                $( '.tfm_home_block_2 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-square thumbnail-uncropped' );
            }
        } );
    } );

    /*---------------------------------------*/
    /* Colours                               */
    /*---------------------------------------*/

    // Title
    wp.customize( 'tfm_home_block_2_title_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_2 .tfm-post-block-title, .tfm_home_block_2 .tfm-post-block-title a' ).css( 'color', newval );
        } );
    } );

    // SubTitle
    wp.customize( 'tfm_home_block_2_subtitle_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_2 .sub-title, .tfm_home_block_2 .sub-title a' ).css( 'color', newval );
        } );
    } );

    // More Link
    wp.customize( 'tfm_home_block_2_link_more_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_2 .tfm-link-more a, .tfm_home_block_2 .tfm-link-more a::after' ).css( 'color', newval );
        } );
    } );

    // Post Background
    wp.customize( 'tfm_home_block_2_post_background', function( value ) {
        value.bind( function( newval ) {
            if ( '' !== newval ) {
                $( '.tfm_home_block_2 .post-grid .article' ).addClass( 'has-background' );
                $( '.tfm_home_block_2 .post-grid .article.has-background:not(.cover) .entry-wrapper, .tfm_home_block_2 .post-grid .article.has-background.cover:not(.has-post-thumbnail) .entry-wrapper' ).css( 'background-color', newval );
            } else {
                $( '.tfm_home_block_2 .post-grid .article.has-background:not(.cover) .entry-wrapper, .tfm_home_block_2 .post-grid .article.has-background.cover:not(.has-post-thumbnail) .entry-wrapper' ).css( 'background-color', 'transparent' );
                $( '.tfm_home_block_2 .post-grid .article.has-background' ).removeClass( 'has-background' );
            }
        } );
    } );

    // Block 3

    // Title
     wp.customize( 'tfm_home_block_3_title', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_3 .page-title' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_3' ).addClass( 'has-title' );
            } else {
                $( '.tfm_home_block_3' ).removeClass( 'has-title' );
            }
        } );
    } );

     // Subtitle
     wp.customize( 'tfm_home_block_3_subtitle', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_3 .sub-title' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_3' ).addClass( 'has-subtitle' );
            } else {
                $( '.tfm_home_block_3' ).removeClass( 'has-subtitle' );
            }
        } );
    } );

     // Link More Text
     wp.customize( 'tfm_home_block_3_link_more_text', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_3 .tfm-link-more a' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_3' ).addClass( 'has-link-more' );
            } else {
                $( '.tfm_home_block_3' ).removeClass( 'has-link-more' );
            }
        } );
    } );

     // Thumbnail aspect ratio
    wp.customize( 'tfm_home_block_3_image_size', function( value ) {
        value.bind( function( newval ) {
            if ( 'wide' === newval ) {
                $( '.tfm_home_block_3 .post-grid .article' ).addClass( 'thumbnail-wide' );
                $( '.tfm_home_block_3 .post-grid .article' ).removeClass( 'thumbnail-landscape thumbnail-square thumbnail-portrait thumbnail-uncropped thumbnail-hero' );
            } else if ( 'landscape' === newval ) {
                $( '.tfm_home_block_3 .post-grid .article' ).addClass( 'thumbnail-landscape' );
                $( '.tfm_home_block_3 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-square thumbnail-portrait thumbnail-uncropped thumbnail-hero' );
            } else if ( 'portrait' === newval ) {
                $( '.tfm_home_block_3 .post-grid .article' ).addClass( 'thumbnail-portrait' );
                $( '.tfm_home_block_3 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-square thumbnail-landscape thumbnail-uncropped thumbnail-hero' );
            } else if ( 'square' === newval ) {
                $( '.tfm_home_block_3 .post-grid .article' ).addClass( 'thumbnail-square' );
                $( '.tfm_home_block_3 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-uncropped thumbnail-hero' );
            } else if ( 'uncropped' === newval ) {
                $( '.tfm_home_block_3 .post-grid .article' ).addClass( 'thumbnail-uncropped' );
                $( '.tfm_home_block_3 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-square thumbnail-hero' );
            } else if ( 'hero' === newval ) {
                $( '.tfm_home_block_3 .post-grid .article' ).addClass( 'thumbnail-hero' );
                $( '.tfm_home_block_3 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-square thumbnail-uncropped' );
            }
        } );
    } );

    /*---------------------------------------*/
    /* Colours                               */
    /*---------------------------------------*/

    // Title
    wp.customize( 'tfm_home_block_3_title_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_3 .tfm-post-block-title, .tfm_home_block_3 .tfm-post-block-title a' ).css( 'color', newval );
        } );
    } );

    // SubTitle
    wp.customize( 'tfm_home_block_3_subtitle_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_3 .sub-title, .tfm_home_block_3 .sub-title a' ).css( 'color', newval );
        } );
    } );

    // More Link
    wp.customize( 'tfm_home_block_3_link_more_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_3 .tfm-link-more a, .tfm_home_block_3 .tfm-link-more a::after' ).css( 'color', newval );
        } );
    } );

    // Post Background
    wp.customize( 'tfm_home_block_3_post_background', function( value ) {
        value.bind( function( newval ) {
            if ( '' !== newval ) {
                $( '.tfm_home_block_3 .post-grid .article' ).addClass( 'has-background' );
                $( '.tfm_home_block_3 .post-grid .article.has-background:not(.cover) .entry-wrapper, .tfm_home_block_3 .post-grid .article.has-background.cover:not(.has-post-thumbnail) .entry-wrapper' ).css( 'background-color', newval );
            } else {
                $( '.tfm_home_block_3 .post-grid .article.has-background:not(.cover) .entry-wrapper, .tfm_home_block_3 .post-grid .article.has-background.cover:not(.has-post-thumbnail) .entry-wrapper' ).css( 'background-color', 'transparent' );
                $( '.tfm_home_block_3 .post-grid .article.has-background' ).removeClass( 'has-background' );
            }
        } );
    } );

    // Block 4

    // Title
     wp.customize( 'tfm_home_block_4_title', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_4 .page-title' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_4' ).addClass( 'has-title' );
            } else {
                $( '.tfm_home_block_4' ).removeClass( 'has-title' );
            }
        } );
    } );

     // Subtitle
     wp.customize( 'tfm_home_block_4_subtitle', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_4 .sub-title' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_4' ).addClass( 'has-subtitle' );
            } else {
                $( '.tfm_home_block_4' ).removeClass( 'has-subtitle' );
            }
        } );
    } );

     // Link More Text
     wp.customize( 'tfm_home_block_4_link_more_text', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_4 .tfm-link-more a' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_4' ).addClass( 'has-link-more' );
            } else {
                $( '.tfm_home_block_4' ).removeClass( 'has-link-more' );
            }
        } );
    } );

     // Thumbnail aspect ratio
    wp.customize( 'tfm_home_block_4_image_size', function( value ) {
        value.bind( function( newval ) {
            if ( 'wide' === newval ) {
                $( '.tfm_home_block_4 .post-grid .article' ).addClass( 'thumbnail-wide' );
                $( '.tfm_home_block_4 .post-grid .article' ).removeClass( 'thumbnail-landscape thumbnail-square thumbnail-portrait thumbnail-uncropped thumbnail-hero' );
            } else if ( 'landscape' === newval ) {
                $( '.tfm_home_block_4 .post-grid .article' ).addClass( 'thumbnail-landscape' );
                $( '.tfm_home_block_4 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-square thumbnail-portrait thumbnail-uncropped thumbnail-hero' );
            } else if ( 'portrait' === newval ) {
                $( '.tfm_home_block_4 .post-grid .article' ).addClass( 'thumbnail-portrait' );
                $( '.tfm_home_block_4 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-square thumbnail-landscape thumbnail-uncropped thumbnail-hero' );
            } else if ( 'square' === newval ) {
                $( '.tfm_home_block_4 .post-grid .article' ).addClass( 'thumbnail-square' );
                $( '.tfm_home_block_4 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-uncropped thumbnail-hero' );
            } else if ( 'uncropped' === newval ) {
                $( '.tfm_home_block_4 .post-grid .article' ).addClass( 'thumbnail-uncropped' );
                $( '.tfm_home_block_4 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-square thumbnail-hero' );
            } else if ( 'hero' === newval ) {
                $( '.tfm_home_block_4 .post-grid .article' ).addClass( 'thumbnail-hero' );
                $( '.tfm_home_block_4 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-square thumbnail-uncropped' );
            }
        } );
    } );

    /*---------------------------------------*/
    /* Colours                               */
    /*---------------------------------------*/

    // Title
    wp.customize( 'tfm_home_block_4_title_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_4 .tfm-post-block-title, .tfm_home_block_4 .tfm-post-block-title a' ).css( 'color', newval );
        } );
    } );

    // SubTitle
    wp.customize( 'tfm_home_block_4_subtitle_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_4 .sub-title, .tfm_home_block_4 .sub-title a' ).css( 'color', newval );
        } );
    } );

    // More Link
    wp.customize( 'tfm_home_block_4_link_more_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_4 .tfm-link-more a, .tfm_home_block_4 .tfm-link-more a::after' ).css( 'color', newval );
        } );
    } );

    // Post Background
    wp.customize( 'tfm_home_block_4_post_background', function( value ) {
        value.bind( function( newval ) {
            if ( '' !== newval ) {
                $( '.tfm_home_block_4 .post-grid .article' ).addClass( 'has-background' );
                $( '.tfm_home_block_4 .post-grid .article.has-background:not(.cover) .entry-wrapper, .tfm_home_block_4 .post-grid .article.has-background.cover:not(.has-post-thumbnail) .entry-wrapper' ).css( 'background-color', newval );
            } else {
                $( '.tfm_home_block_4 .post-grid .article.has-background:not(.cover) .entry-wrapper, .tfm_home_block_4 .post-grid .article.has-background.cover:not(.has-post-thumbnail) .entry-wrapper' ).css( 'background-color', 'transparent' );
                $( '.tfm_home_block_4 .post-grid .article.has-background' ).removeClass( 'has-background' );
            }
        } );
    } );

    //  Block 5

    // Title
     wp.customize( 'tfm_home_block_5_title', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_5 .page-title' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_5' ).addClass( 'has-title' );
            } else {
                $( '.tfm_home_block_5' ).removeClass( 'has-title' );
            }
        } );
    } );

     // Subtitle
     wp.customize( 'tfm_home_block_5_subtitle', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_5 .sub-title' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_5' ).addClass( 'has-subtitle' );
            } else {
                $( '.tfm_home_block_5' ).removeClass( 'has-subtitle' );
            }
        } );
    } );

     // Link More Text
     wp.customize( 'tfm_home_block_5_link_more_text', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_5 .tfm-link-more a' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_5' ).addClass( 'has-link-more' );
            } else {
                $( '.tfm_home_block_5' ).removeClass( 'has-link-more' );
            }
        } );
    } );

     // Thumbnail aspect ratio
    wp.customize( 'tfm_home_block_5_image_size', function( value ) {
        value.bind( function( newval ) {
            if ( 'wide' === newval ) {
                $( '.tfm_home_block_5 .post-grid .article' ).addClass( 'thumbnail-wide' );
                $( '.tfm_home_block_5 .post-grid .article' ).removeClass( 'thumbnail-landscape thumbnail-square thumbnail-portrait thumbnail-uncropped thumbnail-hero' );
            } else if ( 'landscape' === newval ) {
                $( '.tfm_home_block_5 .post-grid .article' ).addClass( 'thumbnail-landscape' );
                $( '.tfm_home_block_5 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-square thumbnail-portrait thumbnail-uncropped thumbnail-hero' );
            } else if ( 'portrait' === newval ) {
                $( '.tfm_home_block_5 .post-grid .article' ).addClass( 'thumbnail-portrait' );
                $( '.tfm_home_block_5 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-square thumbnail-landscape thumbnail-uncropped thumbnail-hero' );
            } else if ( 'square' === newval ) {
                $( '.tfm_home_block_5 .post-grid .article' ).addClass( 'thumbnail-square' );
                $( '.tfm_home_block_5 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-uncropped thumbnail-hero' );
            } else if ( 'uncropped' === newval ) {
                $( '.tfm_home_block_5 .post-grid .article' ).addClass( 'thumbnail-uncropped' );
                $( '.tfm_home_block_5 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-square thumbnail-hero' );
            } else if ( 'hero' === newval ) {
                $( '.tfm_home_block_5 .post-grid .article' ).addClass( 'thumbnail-hero' );
                $( '.tfm_home_block_5 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-square thumbnail-uncropped' );
            }
        } );
    } );

    /*---------------------------------------*/
    /* Colours                               */
    /*---------------------------------------*/

    // Title
    wp.customize( 'tfm_home_block_5_title_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_5 .tfm-post-block-title, .tfm_home_block_5 .tfm-post-block-title a' ).css( 'color', newval );
        } );
    } );

    // SubTitle
    wp.customize( 'tfm_home_block_5_subtitle_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_5 .sub-title, .tfm_home_block_5 .sub-title a' ).css( 'color', newval );
        } );
    } );

    // More Link
    wp.customize( 'tfm_home_block_5_link_more_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_5 .tfm-link-more a, .tfm_home_block_5 .tfm-link-more a::after' ).css( 'color', newval );
        } );
    } );

    // Post Background
    wp.customize( 'tfm_home_block_5_post_background', function( value ) {
        value.bind( function( newval ) {
            if ( '' !== newval ) {
                $( '.tfm_home_block_5 .post-grid .article' ).addClass( 'has-background' );
                $( '.tfm_home_block_5 .post-grid .article.has-background:not(.cover) .entry-wrapper, .tfm_home_block_5 .post-grid .article.has-background.cover:not(.has-post-thumbnail) .entry-wrapper' ).css( 'background-color', newval );
            } else {
                $( '.tfm_home_block_5 .post-grid .article.has-background:not(.cover) .entry-wrapper, .tfm_home_block_5 .post-grid .article.has-background.cover:not(.has-post-thumbnail) .entry-wrapper' ).css( 'background-color', 'transparent' );
                $( '.tfm_home_block_5 .post-grid .article.has-background' ).removeClass( 'has-background' );
            }
        } );
    } );

    //  Block 6

    // Title
     wp.customize( 'tfm_home_block_6_title', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_6 .page-title' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_6' ).addClass( 'has-title' );
            } else {
                $( '.tfm_home_block_6' ).removeClass( 'has-title' );
            }
        } );
    } );

     // Subtitle
     wp.customize( 'tfm_home_block_6_subtitle', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_6 .sub-title' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_6' ).addClass( 'has-subtitle' );
            } else {
                $( '.tfm_home_block_6' ).removeClass( 'has-subtitle' );
            }
        } );
    } );

     // Link More Text
     wp.customize( 'tfm_home_block_6_link_more_text', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_6 .tfm-link-more a' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_6' ).addClass( 'has-link-more' );
            } else {
                $( '.tfm_home_block_6' ).removeClass( 'has-link-more' );
            }
        } );
    } );

     // Thumbnail aspect ratio
    wp.customize( 'tfm_home_block_6_image_size', function( value ) {
        value.bind( function( newval ) {
            if ( 'wide' === newval ) {
                $( '.tfm_home_block_6 .post-grid .article' ).addClass( 'thumbnail-wide' );
                $( '.tfm_home_block_6 .post-grid .article' ).removeClass( 'thumbnail-landscape thumbnail-square thumbnail-portrait thumbnail-uncropped thumbnail-hero' );
            } else if ( 'landscape' === newval ) {
                $( '.tfm_home_block_6 .post-grid .article' ).addClass( 'thumbnail-landscape' );
                $( '.tfm_home_block_6 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-square thumbnail-portrait thumbnail-uncropped thumbnail-hero' );
            } else if ( 'portrait' === newval ) {
                $( '.tfm_home_block_6 .post-grid .article' ).addClass( 'thumbnail-portrait' );
                $( '.tfm_home_block_6 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-square thumbnail-landscape thumbnail-uncropped thumbnail-hero' );
            } else if ( 'square' === newval ) {
                $( '.tfm_home_block_6 .post-grid .article' ).addClass( 'thumbnail-square' );
                $( '.tfm_home_block_6 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-uncropped thumbnail-hero' );
            } else if ( 'uncropped' === newval ) {
                $( '.tfm_home_block_6 .post-grid .article' ).addClass( 'thumbnail-uncropped' );
                $( '.tfm_home_block_6 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-square thumbnail-hero' );
            } else if ( 'hero' === newval ) {
                $( '.tfm_home_block_6 .post-grid .article' ).addClass( 'thumbnail-hero' );
                $( '.tfm_home_block_6 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-square thumbnail-uncropped' );
            }
        } );
    } );

    /*---------------------------------------*/
    /* Colours                               */
    /*---------------------------------------*/

    // Title
    wp.customize( 'tfm_home_block_6_title_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_6 .tfm-post-block-title, .tfm_home_block_6 .tfm-post-block-title a' ).css( 'color', newval );
        } );
    } );

    // SubTitle
    wp.customize( 'tfm_home_block_6_subtitle_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_6 .sub-title, .tfm_home_block_6 .sub-title a' ).css( 'color', newval );
        } );
    } );

    // More Link
    wp.customize( 'tfm_home_block_6_link_more_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_6 .tfm-link-more a, .tfm_home_block_6 .tfm-link-more a::after' ).css( 'color', newval );
        } );
    } );

    // Post Background
    wp.customize( 'tfm_home_block_6_post_background', function( value ) {
        value.bind( function( newval ) {
            if ( '' !== newval ) {
                $( '.tfm_home_block_6 .post-grid .article' ).addClass( 'has-background' );
                $( '.tfm_home_block_6 .post-grid .article.has-background:not(.cover) .entry-wrapper, .tfm_home_block_6 .post-grid .article.has-background.cover:not(.has-post-thumbnail) .entry-wrapper' ).css( 'background-color', newval );
            } else {
                $( '.tfm_home_block_6 .post-grid .article.has-background:not(.cover) .entry-wrapper, .tfm_home_block_6 .post-grid .article.has-background.cover:not(.has-post-thumbnail) .entry-wrapper' ).css( 'background-color', 'transparent' );
                $( '.tfm_home_block_6 .post-grid .article.has-background' ).removeClass( 'has-background' );
            }
        } );
    } );

    // Block 7

    // Title
     wp.customize( 'tfm_home_block_7_title', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_7 .page-title' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_7' ).addClass( 'has-title' );
            } else {
                $( '.tfm_home_block_7' ).removeClass( 'has-title' );
            }
        } );
    } );

     // Subtitle
     wp.customize( 'tfm_home_block_7_subtitle', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_7 .sub-title' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_7' ).addClass( 'has-subtitle' );
            } else {
                $( '.tfm_home_block_7' ).removeClass( 'has-subtitle' );
            }
        } );
    } );

     // Link More Text
     wp.customize( 'tfm_home_block_7_link_more_text', function( value ) {
        value.bind( function( to ) {
            $( '.tfm_home_block_7 .tfm-link-more a' ).text( to );
            if ( '' !== to ) {
                $( '.tfm_home_block_7' ).addClass( 'has-link-more' );
            } else {
                $( '.tfm_home_block_7' ).removeClass( 'has-link-more' );
            }
        } );
    } );

     // Thumbnail aspect ratio
    wp.customize( 'tfm_home_block_7_image_size', function( value ) {
        value.bind( function( newval ) {
            if ( 'wide' === newval ) {
                $( '.tfm_home_block_7 .post-grid .article' ).addClass( 'thumbnail-wide' );
                $( '.tfm_home_block_7 .post-grid .article' ).removeClass( 'thumbnail-landscape thumbnail-square thumbnail-portrait thumbnail-uncropped thumbnail-hero' );
            } else if ( 'landscape' === newval ) {
                $( '.tfm_home_block_7 .post-grid .article' ).addClass( 'thumbnail-landscape' );
                $( '.tfm_home_block_7 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-square thumbnail-portrait thumbnail-uncropped thumbnail-hero' );
            } else if ( 'portrait' === newval ) {
                $( '.tfm_home_block_7 .post-grid .article' ).addClass( 'thumbnail-portrait' );
                $( '.tfm_home_block_7 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-square thumbnail-landscape thumbnail-uncropped thumbnail-hero' );
            } else if ( 'square' === newval ) {
                $( '.tfm_home_block_7 .post-grid .article' ).addClass( 'thumbnail-square' );
                $( '.tfm_home_block_7 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-uncropped thumbnail-hero' );
            } else if ( 'uncropped' === newval ) {
                $( '.tfm_home_block_7 .post-grid .article' ).addClass( 'thumbnail-uncropped' );
                $( '.tfm_home_block_7 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-square thumbnail-hero' );
            } else if ( 'hero' === newval ) {
                $( '.tfm_home_block_7 .post-grid .article' ).addClass( 'thumbnail-hero' );
                $( '.tfm_home_block_7 .post-grid .article' ).removeClass( 'thumbnail-wide thumbnail-portrait thumbnail-landscape thumbnail-square thumbnail-uncropped' );
            }
        } );
    } );

    /*---------------------------------------*/
    /* Colours                               */
    /*---------------------------------------*/

    // Title
    wp.customize( 'tfm_home_block_7_title_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_7 .tfm-post-block-title, .tfm_home_block_7 .tfm-post-block-title a' ).css( 'color', newval );
        } );
    } );

    // SubTitle
    wp.customize( 'tfm_home_block_7_subtitle_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_7 .sub-title, .tfm_home_block_7 .sub-title a' ).css( 'color', newval );
        } );
    } );

    // More Link
    wp.customize( 'tfm_home_block_7_link_more_color', function( value ) {
        value.bind( function( newval ) {
                $( '.tfm_home_block_7 .tfm-link-more a, .tfm_home_block_7 .tfm-link-more a::after' ).css( 'color', newval );
        } );
    } );

    // Post Background
    wp.customize( 'tfm_home_block_7_post_background', function( value ) {
        value.bind( function( newval ) {
            if ( '' !== newval ) {
                $( '.tfm_home_block_7 .post-grid .article' ).addClass( 'has-background' );
                $( '.tfm_home_block_7 .post-grid .article.has-background:not(.cover) .entry-wrapper, .tfm_home_block_7 .post-grid .article.has-background.cover:not(.has-post-thumbnail) .entry-wrapper' ).css( 'background-color', newval );
            } else {
                $( '.tfm_home_block_7 .post-grid .article.has-background:not(.cover) .entry-wrapper, .tfm_home_block_7 .post-grid .article.has-background.cover:not(.has-post-thumbnail) .entry-wrapper' ).css( 'background-color', 'transparent' );
                $( '.tfm_home_block_7 .post-grid .article.has-background' ).removeClass( 'has-background' );
            }
        } );
    } );


} )( jQuery );