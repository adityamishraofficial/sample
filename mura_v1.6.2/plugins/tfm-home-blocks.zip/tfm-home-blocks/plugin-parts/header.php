<?php
/**
 * 3FortyMedia Home Blocks Block Header
 *
 * @since 1.0
 * @version 1.0
 */

?>

<div class="section-header tfm-post-block-header">
	<?php if ( $has_title || $has_subtitle || is_customize_preview() ): ?>
		<div class="section-header-section title">
	<?php endif; ?>
	<?php if ( $has_title || is_customize_preview() ): ?>
		<h2 id="<?php echo esc_attr( $block ); ?>_title" class="page-title tfm-post-block-title"<?php echo wp_kses( $custom_color['title'], $allowed_html ) ?>>
		<?php if ( $link_more && '' === $link_more_text ) : ?>
			<a href="<?php echo esc_attr( $the_link ); ?>"<?php echo wp_kses( $custom_color['title'], $allowed_html ) ?>>
			<?php endif;
			echo esc_html( get_theme_mod( '' . $block . '_title', '' ) );
			if ( $link_more && '' === $link_more_text ) : ?>
			</a>
		<?php endif; ?>
		</h2>
<?php
endif; // Endif has title

/* Subtitle */
if ( $has_subtitle || is_customize_preview() ) : ?>
		<p class="sub-title"<?php echo wp_kses( $custom_color['subtitle'], $allowed_html ); ?>>
			<?php if ( $link_more && '' === $link_more_text && ! $has_title ) : ?>
				<a href="<?php echo esc_attr( $the_link ); ?>"<?php echo wp_kses( $custom_color['subtitle'], $allowed_html ) ?>>
			<?php endif;
			echo esc_html( get_theme_mod( '' . $block . '_subtitle', '' ) );
			if ( $link_more && '' === $link_more_text && ! $has_title ) : ?>
			</a>
		<?php endif; ?>
		</p>

	<?php endif;

	if ( $has_title || $has_subtitle || is_customize_preview()): ?>
	</div>
<?php endif;

//Link More string (no subtitle)
if ( $link_more && $link_more_text || is_customize_preview() ) : ?>
	<div class="section-header-section link-more-section">
	<span class="tfm-link-more"><a href="<?php echo esc_attr( $the_link ); ?>"<?php echo wp_kses( $custom_color['link_more'], $allowed_html ) ?>><?php echo esc_html( $link_more_text  ); ?></a></span></div>
<?php endif; ?>
</div>