=== Mura ===

Contributors: 3FortyMedia
Tags: three-columns, left-sidebar, grid-layout, custom-logo, custom-menu, featured-image-header, featured-images, footer-widgets, full-width-template, post-formats, theme-options, blog, portfolio, photography

Requires at least: 5.9
Tested up to: 6.0
Stable tag: 1.0.0
License: GPL2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Mura is an exciting blog theme optimised for Gutenberg & WordPress 5.x

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme.

== Online Documentation ==

http://www.3forty.media/docs/mura

=== CSS Supported plugins & widgets ==
* MailChimp for Wordpress
* Contact Form 7


== Changelog ==

https://3forty.media/docs/mura/#changelog

= 1.0 - May 04, 2022 =
* Initial release

