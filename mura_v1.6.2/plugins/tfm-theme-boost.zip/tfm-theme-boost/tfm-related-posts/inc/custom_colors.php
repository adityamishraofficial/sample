<?php 

/**
 * Customizer Colour Options
 *
 * @package WordPress
 * @subpackage 3FortyMedia
 * @since 1.0
 * @version 1.0
 */

function tfm_related_posts_pseudo_colors() {

	// ========================================================
	// Pseudo elements
	// ========================================================

	$custom_colors[] = ( '' !== get_theme_mod( 'tfm_related_posts_continue_reading_button_color', '' ) ? '.tfm-related-posts .read-more::after { color: ' . get_theme_mod( 'tfm_related_posts_continue_reading_button_color', '' ) . ';}' : '' );
    $custom_colors[] = ( '' !== get_theme_mod( 'tfm_related_posts_entry_meta_icon_color', '' ) ? '.tfm-related-posts .entry-read-more .entry-meta-read-time::after { color: ' . get_theme_mod( 'tfm_related_posts_entry_meta_icon_color', '' ) . ' !important;}' : '' );
    $custom_colors[] = ( '' !== get_theme_mod( 'tfm_related_posts_entry_meta_border_color', '' ) ? '.tfm-related-posts .entry-read-more .entry-meta-read-time { border-color: ' . get_theme_mod( 'tfm_related_posts_entry_meta_border_color', '' ) . ';}' : '' );

    // Button hover
    $custom_colors[] = ( '' !== get_theme_mod( 'tfm_related_posts_continue_reading_button_hover_background', '' ) ? '.tfm-related-posts .read-more:hover { background: ' . get_theme_mod( 'tfm_related_posts_continue_reading_button_hover_background', '' ) . ' !important;}' : '' );
    $custom_colors[] = ( '' !== get_theme_mod( 'tfm_related_posts_continue_reading_button_hover_color', '' ) ? '.tfm-related-posts .read-more:hover { color: ' . get_theme_mod( 'tfm_related_posts_continue_reading_button_hover_color', '' ) . ' !important;}' : '' );
    $custom_colors[] = ( '' !== get_theme_mod( 'tfm_related_posts_continue_reading_button_hover_color', '' ) ? '.tfm-related-posts .read-more:hover::after { color: ' . get_theme_mod( 'tfm_related_posts_continue_reading_button_hover_color', '' ) . ';}' : '' );

    // Stars
    $custom_colors[] = ( '' !== get_theme_mod( 'tfm_related_posts_tfm_stars_color', '' ) ? '.tfm-related-posts .tfm-rating-stars .star::before, .tfm-related-posts .tfm-rating-stars .star:not(.none)::after { color: ' . get_theme_mod( 'tfm_related_posts_tfm_stars_color', '' ) . ';}' : '' );


	$block_css = array_filter($custom_colors);

if ( count($block_css) !== 0 ) : ?>
<style type="text/css" id="tfm-related-posts-custom-css">
<?php foreach ($block_css as $css ) {
	echo wp_strip_all_tags( $css ) . "\n";
} ?>
</style>

<?php endif;

} // End function

add_action( 'wp_head', 'tfm_related_posts_pseudo_colors' ); // Enqueue the CSS Inline Style after the main stylesheet

 ?>