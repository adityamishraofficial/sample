<?php


/**
 * 3FortyMedia: Home Blocks Settings
 *
 * @package WordPress
 * @subpackage 3FortyMedia
 * @since 1.0
 * @version 1.3
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Register customizer settings

function tfm_home_blocks_customize_register( $wp_customize ) {

// Custom controls
require_once 'custom_controls.php';

	$wp_customize->add_panel( 'tfm_home_blocks', array(
	  'title' => esc_html__( 'TFM: Homepage Post Blocks', 'tfm-home-blocks' ),
	  'description' => esc_html__( 'Customize theme settings', 'tfm-home-blocks'),
	  'priority' => 150,
	  ) );

	$home_blocks = tfm_get_home_blocks( );

	foreach( $home_blocks as $home_block => $value ) {

		$block_num = substr($home_block, 15); // Extract the number from the array string

		$title = ( get_theme_mod( '' . $home_block . '_title' ) ? substr(get_theme_mod( '' . $home_block . '_title' ), 0, 25) . '...' : esc_html__( ' Post Block', 'tfm-home-blocks') . ' ' . esc_html($block_num) );

		$wp_customize->add_section( 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '', array(
			'title' => esc_attr( $title ),
			'panel' => 'tfm_home_blocks',
			'priority' => 130,
		) );

		// Add Setting
		$wp_customize->add_setting( $home_block, array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control( $home_block, array(
			'label'       => esc_html__( 'Enable Block', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_title', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_text',
			'transport' => 'postMessage',
		) );

		// Control Options
		$wp_customize->add_control( '' . $home_block . '_title', array(
			'label'       => esc_html__( 'Title', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'text',
		) );

		// Added in v1.1

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_subtitle', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_text',
			'transport' => 'postMessage',
		) );

		// Control Options
		$wp_customize->add_control( '' . $home_block . '_subtitle', array(
			'label'       => esc_html__( 'Subtitle', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'text',
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_post_type', array(
			'default'           => 'recent',
			'sanitize_callback' => 'tfm_sanitize_select',
		) );

		if ( class_exists('WooCommerce')) {
			// Control Options
			$wp_customize->add_control( '' . $home_block . '_post_type', array(
				'label'       => esc_html__( 'Post Type', 'tfm-home-blocks' ),
				'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
				'type'        => 'select',
				'choices'     => array(
					'recent' => esc_html__( 'Recent Posts', 'tfm-home-blocks' ),
					'popular' => esc_html__( 'Popular Posts', 'tfm-home-blocks' ),
					'post_ids' => esc_html__( 'Specific Posts (Enter post IDs below)', 'tfm-home-blocks' ),
					'random' => esc_html__( 'Random Posts', 'tfm-home-blocks' ),
					'recent_products' => esc_html__( 'Recent Products', 'tfm-home-blocks' ),
					'product_ids' => esc_html__( 'Specific Products (Enter product IDs below)', 'tfm-home-blocks' ),
				),
			) );
		} else {
			// Control Options
			$wp_customize->add_control( '' . $home_block . '_post_type', array(
				'label'       => esc_html__( 'Post Type', 'tfm-home-blocks' ),
				'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
				'type'        => 'select',
				'choices'     => array(
					'recent' => esc_html__( 'Recent Posts', 'tfm-home-blocks' ),
					'popular' => esc_html__( 'Popular Posts', 'tfm-home-blocks' ),
					'post_ids' => esc_html__( 'Specific Posts (Enter post IDs below)', 'tfm-home-blocks' ),
					'random' => esc_html__( 'Random Posts', 'tfm-home-blocks' ),
				),
			) );
		}

		// Post Ids
		$wp_customize->add_setting( '' . $home_block . '_post_ids', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_text',
		) );

		// Post IDs
		$wp_customize->add_control( '' . $home_block . '_post_ids', array(
			'label'       => esc_html__( 'Post/Product IDs', 'tfm-home-blocks' ),
			'description' => esc_html__( 'Enter a comma separated List of post/product IDs', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'text',
		) );

		// Tag Ids
		$wp_customize->add_setting( '' . $home_block . '_tag_ids', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_text',
		) );

		// Tag IDs
		$wp_customize->add_control( '' . $home_block . '_tag_ids', array(
			'label'       => esc_html__( 'Tag Slugs', 'tfm-home-blocks' ),
			'description' => esc_html__( 'Enter a comma separated List of Tag Slugs', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'text',
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_post_cat', array(
			'default'           => '',
			'sanitize_callback' => 'absint',
		) );

		// Control Options
		$wp_customize->add_control( '' . $home_block . '_post_cat', array(
			'label'       => esc_html__( 'Category', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'description' => esc_html__( 'Can be used in combination with post type', 'tfm-home-blocks' ),
			'type'        => 'select',
			'choices'     => tfm_home_blocks_get_blog_categories( '', 'pages' ), // Exclude pages
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_post_format', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_select',
		) );

		// Control Options
		$wp_customize->add_control( '' . $home_block . '_post_format', array(
			'label'       => esc_html__( 'Post Format', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'select',
			'choices'     => array(
				'' => esc_html__( 'Any', 'tfm-home-blocks' ),
				'post-format-standard' => esc_html__( 'Standard', 'tfm-home-blocks' ),
				'post-format-video' => esc_html__( 'Video', 'tfm-home-blocks' ),
				'post-format-audio' => esc_html__( 'Audio', 'tfm-home-blocks' ),
				'post-format-image' => esc_html__( 'Image', 'tfm-home-blocks' ),
				'post-format-gallery' => esc_html__( 'Gallery', 'tfm-home-blocks' ),
			),
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_sort_order', array(
			'default'           => 'desc',
			'sanitize_callback' => 'tfm_sanitize_select',
		) );

		// Control Options
		$wp_customize->add_control( '' . $home_block . '_sort_order', array(
			'label'       => esc_html__( 'Sort Order', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'select',
			'choices'     => array(
				'desc' => esc_html__( 'Newest to Oldest', 'tfm-home-blocks' ),
				'asc' => esc_html__( 'Oldest to Newest', 'tfm-home-blocks' ),
			),
		) );

		// Number of Posts
		$wp_customize->add_setting( '' . $home_block . '_post_num', array(
			'default'           => '3',
			'sanitize_callback' => 'absint',
		) );

		$wp_customize->add_control( '' . $home_block . '_post_num', array(
			'label'       => esc_html__( 'Number of posts', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'number',
			'input_attrs' => array(
		        'min'   => 0,
		    ),
		) );

		// Number of columns
		$wp_customize->add_setting( '' . $home_block . '_cols', array(
			'default'           => '3',
			'sanitize_callback' => 'absint',
		) );

		$wp_customize->add_control( '' . $home_block . '_cols', array(
			'label'       => esc_html__( 'Number of Columns', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'number',
			'input_attrs' => array(
		        'min'   => 1,
		        'max'   => apply_filters( 'tfm_home_blocks_max_cols', 4 ),
		    ),
		) );

		// Offset
		$wp_customize->add_setting( '' . $home_block . '_post_offset', array(
			'default'           => '0',
			'sanitize_callback' => 'absint',
		) );

		$wp_customize->add_control( '' . $home_block . '_post_offset', array(
			'label'       => esc_html__( 'Offset (number of posts to skip)', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'number',
			'input_attrs' => array(
		        'min'   => 0,
		    ),
		) );

		// Exclude Post Ids
		$wp_customize->add_setting( '' . $home_block . '_exclude_post_ids', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_text',
		) );

		// Post IDs
		$wp_customize->add_control( '' . $home_block . '_exclude_post_ids', array(
			'label'       => esc_html__( 'Exclude Post/Product IDs', 'tfm-home-blocks' ),
			'description' => esc_html__( 'Enter a comma separated List of post/product IDs to Exclude', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'text',
		) );

		// Exclude Duplicate
		$wp_customize->add_setting( '' . $home_block . '_exclude_duplicate', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_exclude_duplicate', array(
			'label'       => esc_html__( 'Exclude Duplicate Posts', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_link_more_destination', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_select',
		) );

		// Control Options
		$wp_customize->add_control( '' . $home_block . '_link_more_destination', array(
			'label'       => esc_html__( 'Link to a page or category', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'description' => esc_html__( 'This will add a link or button to the selected page or category for this block.', 'tfm-home-blocks' ),
			'type'        => 'select',
			'choices'     => tfm_home_blocks_get_blog_categories( ),
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_link_more_text', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_text',
			'transport' => 'postMessage',
		) );

		// Control Options
		$wp_customize->add_control( '' . $home_block . '_link_more_text', array(
			'label'       => esc_html__( 'Link more text (optional)', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'description' => esc_html__( 'If you leave this blank the title will be hyperlinked', 'tfm-home-blocks' ),
			'type'        => 'text',
		) );

		// Layout
		$wp_customize->add_setting( '' . $home_block . '_layout', array(
			'default'           => 'grid',
			'sanitize_callback' => 'tfm_sanitize_select',
		) );

		$wp_customize->add_control('' . $home_block . '_layout', array(
			'label'       => esc_html__( 'Post Layout', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'select',
			'choices'     => array(
				'grid' => esc_html__( 'Grid', 'tfm-home-blocks' ),
				'list' => esc_html__( 'List', 'tfm-home-blocks' ),
				'grid-offset' => esc_html__( 'Grid Offset', 'tfm-home-blocks' ),
				'grid-offset-half' => esc_html__( 'Grid Offset Half', 'tfm-home-blocks' ),
				'grid-offset-sides' => esc_html__( 'Grid Offset Sides', 'tfm-home-blocks' ),
				'grid-list-half' => esc_html__( 'Grid/List', 'tfm-home-blocks' ),
			),
		) );

		// Post style
		$wp_customize->add_setting( '' . $home_block . '_post_style', array(
			'default'           => 'default',
			'sanitize_callback' => 'tfm_sanitize_select',
		) );

		$wp_customize->add_control('' . $home_block . '_post_style', array(
			'label'       => esc_html__( 'Post Style', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'select',
			'choices'     => array(
				'default' => esc_html__( 'Default', 'tfm-home-blocks' ),
				'cover' => esc_html__( 'Cover', 'tfm-home-blocks' ),
				'cover-default' => esc_html__( 'Cover/Default', 'tfm-home-blocks' ),
			),
		) );

		if ( apply_filters( 'tfm_home_blocks_theme_supports_full_width', false ) ) :

			// Add Setting
			$wp_customize->add_setting( '' . $home_block . '_full_width', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			// Control Options
			$wp_customize->add_control('' . $home_block . '_full_width', array(
				'label'       => esc_html__( 'Full Width', 'tfm-home-blocks' ),
				'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
				'type'        => 'checkbox',
			) );


		endif;

		if ( apply_filters( 'tfm_home_blocks_theme_supports_margins', false ) ) :

			// Add Setting
			$wp_customize->add_setting( '' . $home_block . '_margins', array(
				'default'           => true,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			// Control Options
			$wp_customize->add_control('' . $home_block . '_margins', array(
				'label'       => esc_html__( 'Post Margins', 'tfm-home-blocks' ),
				'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
				'type'        => 'checkbox',
			) );


		endif;

		// Thumbnail aspect ratio
		$wp_customize->add_setting( '' . $home_block . '_image_size', array(
			'default'           => 'landscape',
			'sanitize_callback' => 'tfm_sanitize_select',
			'transport' => 'postMessage',
		) );

		$wp_customize->add_control( '' . $home_block . '_image_size', array(
			'label'       => esc_html__( 'Thumbnail Size', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'select',
			'choices'     => array(
				'wide' => esc_html__( 'Wide', 'tfm-home-blocks' ),
				'landscape' => esc_html__( 'Landscape', 'tfm-home-blocks' ),
				'portrait' => esc_html__( 'Portrait', 'tfm-home-blocks' ),
				'square' => esc_html__( 'Square', 'tfm-home-blocks' ),
				'hero' => esc_html__( 'Hero', 'tfm-home-blocks' ),
				'uncropped' => esc_html__( 'Uncropped', 'tfm-home-blocks' ),
			),
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_thumbnail', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_thumbnail', array(
			'label'       => esc_html__( 'Thumbnail', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_media', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_media', array(
			'label'       => esc_html__( 'Video', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		// Toggle entry meta

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_excerpt', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_excerpt', array(
			'label'       => esc_html__( 'Excerpt', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_excerpt_length', array(
			'default'           => '',
			'sanitize_callback' => 'absint',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_excerpt_length', array(
			'label'       => esc_html__( 'Excerpt Length', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'number',
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_read_more', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_read_more', array(
			'label'       => esc_html__( 'Read More', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_entry_title', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_entry_title', array(
			'label'       => esc_html__( 'Entry Title', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_entry_meta_by', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_entry_meta_by', array(
			'label'       => esc_html__( '"by"', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_entry_meta_in', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_entry_meta_in', array(
			'label'       => esc_html__( '"in"', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_entry_meta_author', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_entry_meta_author', array(
			'label'       => esc_html__( 'Author', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_entry_meta_author_avatar', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_entry_meta_author_avatar', array(
			'label'       => esc_html__( 'Author Avatar', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_entry_meta_category', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_entry_meta_category', array(
			'label'       => esc_html__( 'Category', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_entry_meta_date', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_entry_meta_date', array(
			'label'       => esc_html__( 'Date', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		if ( function_exists('tfm_read_time') ):

			// Add Setting
			$wp_customize->add_setting( '' . $home_block . '_entry_meta_read_time', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			// Control Options
			$wp_customize->add_control('' . $home_block . '_entry_meta_read_time', array(
				'label'       => esc_html__( 'Read Time', 'tfm-home-blocks' ),
				'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
				'type'        => 'checkbox',
			) );

		endif;

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_entry_meta_comment_count', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_entry_meta_comment_count', array(
			'label'       => esc_html__( 'Comment Count', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_post_format_icons', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_post_format_icons', array(
			'label'       => esc_html__( 'Show Post Format Icons', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_post_count', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_post_count', array(
			'label'       => esc_html__( 'Show Post Count', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		// ========================================================
		// widgets
		// ========================================================

		if ( apply_filters( 'tfm_home_blocks_theme_supports_widgets', true )) :

		/**
		Separator
		**/
		$wp_customize->add_setting('' . $home_block . '_tfm_home_blocks_sidebar_separator', array(
			'default'           => '',
			'sanitize_callback' => 'esc_html',
		));
		$wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, '' .$home_block . '_tfm_home_blocks_sidebar_separator', array(
			'settings'		=> '' .$home_block . '_tfm_home_blocks_sidebar_separator',
			'section'  		=> 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
		)));

		// Add Setting
		$wp_customize->add_setting( '' . $home_block . '_sidebar', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		// Control Options
		$wp_customize->add_control('' . $home_block . '_sidebar', array(
			'label'       => esc_html__( 'Display Sidebar', 'tfm-home-blocks' ),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'checkbox',
		) );

		// Number of Posts
		$wp_customize->add_setting( '' . $home_block . '_sidebar_position', array(
			'default'           => 'right',
			'sanitize_callback' => 'tfm_sanitize_select',
		) );

		$wp_customize->add_control( '' . $home_block . '_sidebar_position', array(
			'label'       => esc_html__( 'Sidebar Position', 'tfm-home-blocks' ),
			'description' => esc_html__( 'Manage widgets for this sidebar in Appearance > Widgets > TFM: Homepage Post Block', 'tfm-home-blocks' ) . ' ' . esc_html($block_num),
			'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			'type'        => 'select',
			'choices'     => array(
				'left' => esc_html__( 'Left', 'tfm-home-blocks' ),
				'right' => esc_html__( 'Right', 'tfm-home-blocks' ),
				'bottom' => esc_html__( 'Bottom', 'tfm-home-blocks' ),
				'top' => esc_html__( 'Top', 'tfm-home-blocks' ),
			),
		) );

		endif; // Endif theme supports block widgets

		// ========================================================
		// Ratings checkboxes (TFM Theme Boost) function
		// ========================================================

		if ( function_exists('tfm_ratings') ):

			/**
			Separator
			**/
			$wp_customize->add_setting('' . $home_block . '_tfm_home_blocks_ratings_separator', array(
			'default'           => '',
			'sanitize_callback' => 'esc_html',
			));
			$wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, '' .$home_block . '_tfm_home_blocks_ratings_separator', array(
				'settings'		=> '' .$home_block . '_tfm_home_blocks_ratings_separator',
				'section'  		=> 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
			)));

			/**
			Info
			**/
		    $wp_customize->add_setting('' . $home_block . '_tfm_home_blocks_ratings_info', array(
		        'default'           => '',
		        'sanitize_callback' => 'tfm_sanitize_text',
		     
		    ));
		    $wp_customize->add_control(new tfm_Info_Custom_Control($wp_customize, '' . $home_block . '_tfm_home_blocks_ratings_info', array(
		        'label'         => esc_html__('Ratings', 'tfm-home-blocks'),
		        'description' => esc_html__( 'Add a rating to your posts to use this feature', 'tfm-home-blocks' ),
		        'settings'		=> '' .$home_block . '_tfm_home_blocks_ratings_info',
		        'section'  		=> 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
		    )));

			// Add Setting
			$wp_customize->add_setting( '' . $home_block . '_tfm_star_rating', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			// Control Options
			$wp_customize->add_control('' . $home_block . '_tfm_star_rating', array(
				'label'       => esc_html__( 'Star Rating', 'tfm-home-blocks' ),
				'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
				'type'        => 'checkbox',
			) );

			// Add Setting
			$wp_customize->add_setting( '' . $home_block . '_tfm_scale_rating', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			// Control Options
			$wp_customize->add_control('' . $home_block . '_tfm_scale_rating', array(
				'label'       => esc_html__( 'Scale Rating', 'tfm-home-blocks' ),
				'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
				'type'        => 'checkbox',
			) );

			// Add Setting
			$wp_customize->add_setting( '' . $home_block . '_tfm_points_rating', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			// Control Options
			$wp_customize->add_control('' . $home_block . '_tfm_points_rating', array(
				'label'       => esc_html__( 'Points Rating', 'tfm-home-blocks' ),
				'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
				'type'        => 'checkbox',
			) );

			// Add Setting
			$wp_customize->add_setting( '' . $home_block . '_tfm_percent_rating', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			// Control Options
			$wp_customize->add_control('' . $home_block . '_tfm_percent_rating', array(
				'label'       => esc_html__( 'Percent Rating', 'tfm-home-blocks' ),
				'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
				'type'        => 'checkbox',
			) );

			// Colors
			$wp_customize->add_setting( '' . $home_block . '_tfm_stars_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_tfm_stars_color', array(
		      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
		      'label'   => esc_html__( 'Stars Color', 'tfm-home-blocks' ),
		    ) ) );

		endif;

		// ========================================================
		// Block Colors
		// ========================================================

		if ( apply_filters( 'tfm_home_blocks_theme_supports_color_options', true )) :

		/**
		Separator
		**/
		$wp_customize->add_setting('' . $home_block . '_tfm_home_blocks_colors_separator', array(
			'default'           => '',
			'sanitize_callback' => 'esc_html',
		));
		$wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, '' .$home_block . '_tfm_home_blocks_colors_separator', array(
			'settings'		=> '' .$home_block . '_tfm_home_blocks_colors_separator',
			'section'  		=> 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
		)));

		// Colors
		$wp_customize->add_setting( '' . $home_block . '_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_background', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Background Color', 'tfm-home-blocks' ),
	    ) ) );

	    $wp_customize->add_setting( '' . $home_block . '_title_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_title_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Title Color', 'tfm-home-blocks' ),
	    ) ) );

	     $wp_customize->add_setting( '' . $home_block . '_subtitle_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_subtitle_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'SubTitle Color', 'tfm-home-blocks' ),
	    ) ) );

	    $wp_customize->add_setting( '' . $home_block . '_link_more_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_link_more_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'More Link Color', 'tfm-home-blocks' ),
	    ) ) );

	    /**
		Separator
		**/
		$wp_customize->add_setting('' . $home_block . '_tfm_home_blocks_entry_colors_separator', array(
			'default'           => '',
			'sanitize_callback' => 'esc_html',
		));
		$wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, '' .$home_block . '_tfm_home_blocks_entry_colors_separator', array(
			'settings'		=> '' .$home_block . '_tfm_home_blocks_entry_colors_separator',
			'section'  		=> 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
		)));


		$wp_customize->add_setting( '' . $home_block . '_post_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_post_background', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Post Background Color', 'tfm-home-blocks' ),
	    ) ) );

	    $wp_customize->add_setting( '' . $home_block . '_border_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_border_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Post Border Color', 'tfm-home-blocks' ),
	    ) ) );


		$wp_customize->add_setting( '' . $home_block . '_entry_title_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_entry_title_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Entry Title Color', 'tfm-home-blocks' ),
	    ) ) );

	    $wp_customize->add_setting( '' . $home_block . '_entry_meta_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_entry_meta_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Entry Meta Color', 'tfm-home-blocks' ),
	    ) ) );

	    $wp_customize->add_setting( '' . $home_block . '_entry_meta_link_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_entry_meta_link_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Entry Meta Link Color', 'tfm-home-blocks' ),
	    ) ) );

	    $wp_customize->add_setting( '' . $home_block . '_entry_meta_cat_link_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_entry_meta_cat_link_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Category Slug Color', 'tfm-home-blocks' ),
	    ) ) );

	     $wp_customize->add_setting( '' . $home_block . '_entry_meta_icon_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_entry_meta_icon_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Entry Meta Icon Color', 'tfm-home-blocks' ),
	    ) ) );

	    $wp_customize->add_setting( '' . $home_block . '_entry_content_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_entry_content_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Excerpt Color', 'tfm-home-blocks' ),
	    ) ) );

	    $wp_customize->add_setting( '' . $home_block . '_entry_meta_border_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_entry_meta_border_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Entry Meta Border Color', 'tfm-home-blocks' ),
	    ) ) );

	    $wp_customize->add_setting( '' . $home_block . '_continue_reading_button_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

	   // Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_continue_reading_button_background', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Button Color', 'tfm-home-blocks' ),
	    ) ) );

	     $wp_customize->add_setting( '' . $home_block . '_continue_reading_button_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_continue_reading_button_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Button Text Color', 'tfm-home-blocks' ),
	    ) ) );

	    $wp_customize->add_setting( '' . $home_block . '_continue_reading_button_hover_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_continue_reading_button_hover_background', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Button Hover Color', 'tfm-home-blocks' ),
	    ) ) );

	     $wp_customize->add_setting( '' . $home_block . '_continue_reading_button_hover_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_continue_reading_button_hover_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Button Hover Text Color', 'tfm-home-blocks' ),
	    ) ) );

	    $wp_customize->add_setting( '' . $home_block . '_count_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_count_background', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Count Background', 'tfm-home-blocks' ),
	    ) ) );

	     $wp_customize->add_setting( '' . $home_block . '_count_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_count_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Count Text Color', 'tfm-home-blocks' ),
	    ) ) );

	    // ========================================================
		// Block widget colors
		// ========================================================

		if ( apply_filters( 'tfm_home_blocks_theme_supports_widgets', true )) :

	    /**
		Separator
		**/
		$wp_customize->add_setting('' . $home_block . '_tfm_home_blocks_widget_colors_separator', array(
			'default'           => '',
			'sanitize_callback' => 'esc_html',
		));
		$wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, '' .$home_block . '_tfm_home_blocks_widget_colors_separator', array(
			'settings'		=> '' .$home_block . '_tfm_home_blocks_widget_colors_separator',
			'section'  		=> 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
		)));

		// Widget Background
		 $wp_customize->add_setting( '' . $home_block . '_widget_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_widget_background', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Widget Background Color', 'tfm-home-blocks' ),
	    ) ) );

		// Widget Text Color
	     $wp_customize->add_setting( '' . $home_block . '_widget_text_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_widget_text_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Widget Text Color', 'tfm-home-blocks' ),
	    ) ) );

		// Widget Title
	    $wp_customize->add_setting( '' . $home_block . '_widget_title_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_widget_title_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Widget Title Color', 'tfm-home-blocks' ),
	    ) ) );

	    // Widget SubTitle
	    $wp_customize->add_setting( '' . $home_block . '_widget_subtitle_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_widget_subtitle_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Widget SubTitle Color', 'tfm-home-blocks' ),
	    ) ) );

	    // Widget Link
	    $wp_customize->add_setting( '' . $home_block . '_widget_link_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_widget_link_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Widget Link Color', 'tfm-home-blocks' ),
	    ) ) );

	    // Widget Child Link
	    $wp_customize->add_setting( '' . $home_block . '_widget_child_link_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_widget_child_link_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Widget Child Link Color', 'tfm-home-blocks' ),
	    ) ) );

	    // Widget Meta Color
	    $wp_customize->add_setting( '' . $home_block . '_widget_meta_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_widget_meta_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Widget Meta Color', 'tfm-home-blocks' ),
	    ) ) );

	    // Widget Meta Link Color
	    $wp_customize->add_setting( '' . $home_block . '_widget_meta_link_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_widget_meta_link_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Widget Meta Link Color', 'tfm-home-blocks' ),
	    ) ) );

	    // Widget Button Background
	    $wp_customize->add_setting( '' . $home_block . '_widget_button_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_widget_button_background', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Widget Button Background', 'tfm-home-blocks' ),
	    ) ) );

	    // Widget Button Color
	    $wp_customize->add_setting( '' . $home_block . '_widget_button_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_widget_button_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Widget Button Text Color', 'tfm-home-blocks' ),
	    ) ) );

	     // Widget Line Color
	    $wp_customize->add_setting( '' . $home_block . '_widget_line_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, '' . $home_block . '_widget_line_color', array(
	      'section'     => 'tfm_home_custom_blocks_' . esc_attr( $home_block ) . '',
	      'label'   => esc_html__( 'Widget Line Color', 'tfm-home-blocks' ),
	    ) ) );

		endif; // endif theme supports widgets (output widget colors)

		endif; // Endif colour support

	}


}

add_action( 'customize_register', 'tfm_home_blocks_customize_register' );


// ========================================================
// Create an Array of categories
// ========================================================

if ( ! function_exists( 'tfm_home_blocks_get_blog_categories' ) ) {

	function tfm_home_blocks_get_blog_categories( $type = '', $exclude = '' ) {

		$categories = get_categories('type=post');
		$product_categories = get_categories( array( 'taxonomy' => 'product_cat') );
		$all_pages = get_all_page_ids();

		$cats = array('' => '');
		$prod_cats = array('' => '');
		$pages = array('' => '');

		if ( ($type === 'categories' || '' === $type) && 'categories' !== $exclude ) {
			foreach( $categories as $category ) {
			    $cats[$category->term_id] = $category->name;
			}
		}
		if ( ($type === 'product_categories' || '' === $type ) && 'product_categories' !== $exclude ) {
			foreach( $product_categories as $product_cat ) {
			    $prod_cats[$product_cat->term_id] = $product_cat->name;
			}
		}
		if ( ($type === 'pages' || '' === $type) && 'pages' !== $exclude ) {
			foreach( $all_pages as $page_id ) {
				$page = 'page_' . $page_id;
			    $pages[$page] = get_the_title( $page_id );
			}
		}

		return array_replace_recursive( $cats, $prod_cats, $pages );
	}

}

// ========================================================
// Create an Array of HOME Blocks
// ========================================================

if ( ! function_exists( 'tfm_get_home_blocks' ) ) {

function tfm_get_home_blocks( ) {
     $home_blocks = apply_filters( 'tfm_home_blocks_list', array(
     	 'tfm_home_block_1' => 'tfm_home_custom_blocks_tfm_home_block_1',
     	 'tfm_home_block_2' => 'tfm_home_custom_blocks_tfm_home_block_2',
         'tfm_home_block_3' => 'tfm_home_custom_blocks_tfm_home_block_3',
         'tfm_home_block_4' => 'tfm_home_custom_blocks_tfm_home_block_4',
         'tfm_home_block_5' => 'tfm_home_custom_blocks_tfm_home_block_5',
         'tfm_home_block_6' => 'tfm_home_custom_blocks_tfm_home_block_6',
         'tfm_home_block_7' => 'tfm_home_custom_blocks_tfm_home_block_7',
     ));

 return $home_blocks;
}

}

// Preview.js
function tfm_home_blocks_customize_preview_js() {
    wp_enqueue_script( 'tfm-home-blocks-customizer-preview', plugin_dir_url( __FILE__ ) . 'js/customizer-preview.js', array( 'customize-preview' ), null, true );
}
add_action( 'customize_preview_init', 'tfm_home_blocks_customize_preview_js' );

?>