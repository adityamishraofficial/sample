<?php

/**
 * 3FortyMedia: HERO Customizer Settings
 *
 * @package WordPress
 * @subpackage 3FortyMedia
 * @since 1.0
 * @version 1.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Register customizer settings

function tfm_hero_customize_register( $wp_customize ) {

	// Custom controls
	require_once 'custom_controls.php';

		$wp_customize->add_section( 'tfm_hero_settings', array(
			'title'    => esc_html__( 'TFM: Hero', 'tfm-theme-boost' ),
			'priority' => 160,
			) );

		/**
		 * Display Hero
		 */
		$wp_customize->add_setting( 'tfm_hero', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero', array(
			'label'       => esc_html__( 'Display Hero on Homepage', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

			$wp_customize->add_setting( 'tfm_hero_blog', array(
				'default'           => true,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			$wp_customize->add_control( 'tfm_hero_blog', array(
				'label'       => esc_html__( 'Display Hero on Posts Page', 'tfm-theme-boost' ),
				'section'     => 'tfm_hero_settings',
				'description' => esc_html__( '* If your Posts Page is set to a page', 'tfm-theme-boost' ),
				'type'        => 'checkbox',
			) );

			/**
			 * Layout
			 */
			$wp_customize->add_setting( 'tfm_hero_layout', array(
				'default'           => 'grid',
				'sanitize_callback' => 'tfm_sanitize_select',
			) );

			$wp_customize->add_control( 'tfm_hero_layout', array(
				'label'       => esc_html__( 'Layout', 'tfm-theme-boost' ),
				'section'     => 'tfm_hero_settings',
				'type'        => 'select',
				'choices'     => array(
					'slider' => esc_html__( 'Slider', 'tfm-theme-boost' ),
					'grid' => esc_html__( 'Grid', 'tfm-theme-boost' ),
					'grid-offset' => esc_html__( 'Grid Offset', 'tfm-theme-boost'),
					'grid-offset-half' => esc_html__( 'Grid Offset Half', 'tfm-theme-boost'),
					'grid-offset-sides' => esc_html__( 'Grid Offset Sides', 'tfm-theme-boost'),
				),
			) );

		/**
		 * Style (this can be filtered on a per theme basis)
		 */

		$wp_customize->add_setting( 'tfm_hero_style', array(
			'default'           => 'default',
			'sanitize_callback' => 'tfm_sanitize_select',
		) );

		$wp_customize->add_control( 'tfm_hero_style', array(
			'label'       => esc_html__( 'Style', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'select',
			'choices'     => array(
				'default' => esc_html__( 'Default', 'tfm-theme-boost' ),
				'cover' => esc_html__( 'Cover', 'tfm-theme-boost' ),
				'cover-default' => esc_html__( 'Cover/Default', 'tfm-theme-boost' ),
			),
		) );

		/**
		 * Post Type
		 */
		$wp_customize->add_setting( 'tfm_hero_post_type', array(
			'default'           => 'recent',
			'sanitize_callback' => 'tfm_sanitize_select',
		) );

		$wp_customize->add_control( 'tfm_hero_post_type', array(
			'label'       => esc_html__( 'Post Type', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'select',
			'choices'     => array(
				'recent' => esc_html__( 'Recent Posts', 'tfm-theme-boost' ),
				'popular' => esc_html__( 'Popular Posts', 'tfm-theme-boost' ),
				'random' => esc_html__( 'Random Posts', 'tfm-theme-boost' ),
				'post_ids' => esc_html__( 'Specific Posts (Enter post IDs below)', 'tfm-theme-boost' ),
			),
		) );

		/**
		 * Post ID's
		 */
		$wp_customize->add_setting( 'tfm_hero_post_ids', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_text',
		) );

		// Control Options
		$wp_customize->add_control( 'tfm_hero_post_ids', array(
			'label'       => esc_html__( 'Post IDs', 'tfm-theme-boost' ),
			'description' => esc_html__( 'Enter a comma separated List of post IDs', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'text',
		) );

		/**
		 * Tag ID's
		 */
		$wp_customize->add_setting( 'tfm_hero_tag_ids', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_text',
		) );

		// Control Options
		$wp_customize->add_control( 'tfm_hero_tag_ids', array(
			'label'       => esc_html__( 'Tag IDs', 'tfm-theme-boost' ),
			'description' => esc_html__( 'Enter a comma separated List of Tag IDs', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'text',
		) );

		/**
		 * Post Category
		 */
		$wp_customize->add_setting( 'tfm_hero_post_cat', array(
			'default'           => '',
			'sanitize_callback' => 'absint',
		) );

		$wp_customize->add_control( 'tfm_hero_post_cat', array(
			'label'       => esc_html__( 'Category', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'description' => esc_html__( 'Can be used in combination with post type', 'tfm-theme-boost' ),
			'type'        => 'select',
			'choices'     => tfm_get_blog_categories(),
		) );

		/**
		 * Number of Posts
		 */
		$wp_customize->add_setting( 'tfm_hero_sort_order', array(
			'default'           => 'desc',
			'sanitize_callback' => 'tfm_sanitize_select',
		) );

		$wp_customize->add_control( 'tfm_hero_sort_order', array(
			'label'       => esc_html__( 'Sort Order', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'select',
			'choices'     => array(
				'desc' => esc_html__( 'Newest to Oldest', 'tfm-theme-boost' ),
				'asc' => esc_html__( 'Oldest to Newest', 'tfm-theme-boost' ),
			),
		) );

		/**
		 * Number of Posts
		 */
		$wp_customize->add_setting( 'tfm_hero_post_num', array(
			'default'           => '1',
			'sanitize_callback' => 'absint',
		) );

		$wp_customize->add_control( 'tfm_hero_post_num', array(
			'label'       => esc_html__( 'Number of posts', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'number',
			'input_attrs' => array(
		        'min'   => 1,
		        'max'   => apply_filters( 'tfm_hero_max_post_num', 999 ),
		    ),
		) );

		/**
		 * Number of Slides to Show
		 */

			$wp_customize->add_setting( 'tfm_hero_slidestoshow', array(
				'default'           => '1',
				'sanitize_callback' => 'absint',
			) );

			$wp_customize->add_control( 'tfm_hero_slidestoshow', array(
				'label'       => esc_html__( 'Number of Slides To Show', 'tfm-theme-boost' ),
				'section'     => 'tfm_hero_settings',
				'type'        => 'number',
				'input_attrs' => array(
			        'min'   => 1,
			        'max'   => apply_filters( 'tfm_hero_max_slidestoshow', 4 ),
			    ),
			) );

		/**
		 * Offset
		 */
		$wp_customize->add_setting( 'tfm_hero_post_offset', array(
			'default'           => '0',
			'sanitize_callback' => 'absint',
		) );

		$wp_customize->add_control( 'tfm_hero_post_offset', array(
			'label'       => esc_html__( 'Offset (Number of posts to skip)', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'number',
			'input_attrs' => array(
		        'min'   => 0,
		    ),
		) );

		/**
		 * Post ID's
		 */
		$wp_customize->add_setting( 'tfm_hero_exclude_post_ids', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_text',
		) );

		// Control Options
		$wp_customize->add_control( 'tfm_hero_exclude_post_ids', array(
			'label'       => esc_html__( 'Exclude Post IDs', 'tfm-theme-boost' ),
			'description' => esc_html__( 'Enter a comma separated List of post IDs to Exclude', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'text',
		) );

		$wp_customize->add_setting( 'tfm_hero_autoplay_speed', array(
				'default'           => '3000',
				'sanitize_callback' => 'absint',
			) );

			$wp_customize->add_control( 'tfm_hero_autoplay_speed', array(
				'label'       => esc_html__( 'Slider AutoPlay Speed (in Milliseconds)', 'tfm-theme-boost' ),
				'section'     => 'tfm_hero_settings',
				'type'        => 'number',
			) );

			$wp_customize->add_setting( 'tfm_hero_slide_speed', array(
				'default'           => '500',
				'sanitize_callback' => 'absint',
			) );

			$wp_customize->add_control( 'tfm_hero_slide_speed', array(
				'label'       => esc_html__( 'Slide Animation Speed (in Milliseconds)', 'tfm-theme-boost' ),
				'section'     => 'tfm_hero_settings',
				'type'        => 'number',
			) );

		// Full width
		$wp_customize->add_setting( 'tfm_hero_full_width', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero_full_width', array(
			'label'       => esc_html__( 'Full Width', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

		// CenterMode
		$wp_customize->add_setting( 'tfm_hero_centermode', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero_centermode', array(
			'label'       => esc_html__( 'Center Mode', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

		// CenterMode
		$wp_customize->add_setting( 'tfm_hero_margins', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero_margins', array(
			'label'       => esc_html__( 'Space Around Posts', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

		// Arrows
		$wp_customize->add_setting( 'tfm_hero_arrows', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero_arrows', array(
			'label'       => esc_html__( 'Show Prev/Next Arrows', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

		// Arrows
		// $wp_customize->add_setting( 'tfm_hero_pagination', array(
		// 	'default'           => false,
		// 	'sanitize_callback' => 'tfm_sanitize_checkbox',
		// ) );

		// $wp_customize->add_control( 'tfm_hero_pagination', array(
		// 	'label'       => esc_html__( 'Show Pagination', 'tfm-theme-boost' ),
		// 	'section'     => 'tfm_hero_settings',
		// 	'type'        => 'checkbox',
		// ) );

		/**
		 * Entry title/meta
		 */


		// Entry Title
		$wp_customize->add_setting( 'tfm_hero_entry_title', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero_entry_title', array(
			'label'       => esc_html__( 'Entry Title', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

		// Entry Title
		$wp_customize->add_setting( 'tfm_hero_thumbnail', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero_thumbnail', array(
			'label'       => esc_html__( 'Thumbnail', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

		// Thumbnail aspect ratio
		$wp_customize->add_setting( 'tfm_hero_thumbnail_aspect_ratio', array(
			'default'           => 'wide',
			'sanitize_callback' => 'tfm_sanitize_select',
		) );

		$wp_customize->add_control( 'tfm_hero_thumbnail_aspect_ratio', array(
			'label'       => esc_html__( 'Thumbnail Aspect Ratio', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'select',
			'choices'     => array(
				'wide' => esc_html__( 'Wide', 'tfm-theme-boost' ),
				'landscape' => esc_html__( 'Landscape', 'tfm-theme-boost' ),
				'portrait' => esc_html__( 'Portrait', 'tfm-theme-boost' ),
				'square' => esc_html__( 'Square', 'tfm-theme-boost' ),
				'hero' => esc_html__( 'Hero', 'tfm-theme-boost' ),
			),
		) );

		$wp_customize->add_setting( 'tfm_hero_excerpt', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero_excerpt', array(
			'label'       => esc_html__( 'Excerpt', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_hero_read_more', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero_read_more', array(
			'label'       => esc_html__( 'Read More', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

		// By
		$wp_customize->add_setting( 'tfm_hero_entry_meta_by', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero_entry_meta_by', array(
			'label'       => esc_html__( '"by"', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

		// In
		$wp_customize->add_setting( 'tfm_hero_entry_meta_in', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero_entry_meta_in', array(
			'label'       => esc_html__( '"in"', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

		// Author Meta
		$wp_customize->add_setting( 'tfm_hero_entry_meta_author', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero_entry_meta_author', array(
			'label'       => esc_html__( 'Author', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

		// Author Avatar
		$wp_customize->add_setting( 'tfm_hero_entry_meta_author_avatar', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero_entry_meta_author_avatar', array(
			'label'       => esc_html__( 'Author Avatar', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

		// Category Meta
		$wp_customize->add_setting( 'tfm_hero_entry_meta_category', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero_entry_meta_category', array(
			'label'       => esc_html__( 'Category', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

		// Number of category slugs
		$wp_customize->add_setting( 'tfm_hero_entry_meta_category_slugs', array(
			'default'           => '1',
			'sanitize_callback' => 'absint',
		) );

		$wp_customize->add_control( 'tfm_hero_entry_meta_category_slugs', array(
			'label'       => esc_html__( 'Number of category tags', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'number',
			'input_attrs' => array(
		        'min'   => 1,
		    ),
		) );

		// Date Meta
		$wp_customize->add_setting( 'tfm_hero_entry_meta_date', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero_entry_meta_date', array(
			'label'       => esc_html__( 'Date', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

		// Date Meta
		if ( function_exists( 'tfm_read_time' ) ) :
			$wp_customize->add_setting( 'tfm_hero_entry_meta_read_time', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			$wp_customize->add_control( 'tfm_hero_entry_meta_read_time', array(
				'label'       => esc_html__( 'Read Time', 'tfm-theme-boost' ),
				'section'     => 'tfm_hero_settings',
				'type'        => 'checkbox',
			) );
		endif;

		// Comments Meta
		$wp_customize->add_setting( 'tfm_hero_entry_meta_comment_count', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero_entry_meta_comment_count', array(
			'label'       => esc_html__( 'Comment Count', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

		// Comments Meta
		$wp_customize->add_setting( 'tfm_hero_post_count', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_hero_post_count', array(
			'label'       => esc_html__( 'Post Count', 'tfm-theme-boost' ),
			'section'     => 'tfm_hero_settings',
			'type'        => 'checkbox',
		) );

		// ========================================================
		// Ratings checkboxes (TFM Theme Boost) function
		// ========================================================

		if ( function_exists('tfm_ratings') ):

			/**
			Separator
			**/
			$wp_customize->add_setting('tfm_hero_ratings_separator', array(
				'default'           => '',
				'sanitize_callback' => 'esc_html',
			));
			$wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, 'tfm_hero_ratings_separator', array(
				'settings'		=> 'tfm_hero_ratings_separator',
				'section'  		=> 'tfm_hero_settings',
			)));

			/**
			Info
			**/
		    $wp_customize->add_setting('tfm_hero_ratings_info', array(
		        'default'           => '',
		        'sanitize_callback' => 'tfm_sanitize_text',
		     
		    ));
		    $wp_customize->add_control(new Tfm_Info_Custom_Control($wp_customize, 'tfm_hero_ratings_info', array(
		        'label'         => esc_html__('Ratings', 'tfm-theme-boost'),
		        'description' => esc_html__( 'Add a rating to your posts to use this feature', 'tfm-theme-boost' ),
		        'settings'		=> 'tfm_hero_ratings_info',
		        'section'  		=> 'tfm_hero_settings',
		    )));

			// Add Setting
			$wp_customize->add_setting( 'tfm_hero_tfm_star_rating', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			// Control Options
			$wp_customize->add_control('tfm_hero_tfm_star_rating', array(
				'label'       => esc_html__( 'Star Rating', 'tfm-theme-boost' ),
				'section'     => 'tfm_hero_settings',
				'type'        => 'checkbox',
			) );

			// Add Setting
			$wp_customize->add_setting( 'tfm_hero_tfm_scale_rating', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			// Control Options
			$wp_customize->add_control('tfm_hero_tfm_scale_rating', array(
				'label'       => esc_html__( 'Scale Rating', 'tfm-theme-boost' ),
				'section'     => 'tfm_hero_settings',
				'type'        => 'checkbox',
			) );

			// Add Setting
			$wp_customize->add_setting( 'tfm_hero_tfm_points_rating', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			// Control Options
			$wp_customize->add_control('tfm_hero_tfm_points_rating', array(
				'label'       => esc_html__( 'Points Rating', 'tfm-theme-boost' ),
				'section'     => 'tfm_hero_settings',
				'type'        => 'checkbox',
			) );

			// Add Setting
			$wp_customize->add_setting( 'tfm_hero_tfm_percent_rating', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			// Control Options
			$wp_customize->add_control('tfm_hero_tfm_percent_rating', array(
				'label'       => esc_html__( 'Percent Rating', 'tfm-theme-boost' ),
				'section'     => 'tfm_hero_settings',
				'type'        => 'checkbox',
			) );

			// Colors
			$wp_customize->add_setting( 'tfm_hero_tfm_stars_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_hero_tfm_stars_color', array(
		      'section'     => 'tfm_hero_settings',
		      'label'   => esc_html__( 'Stars Color', 'tfm-theme-boost' ),
		    ) ) );

		endif;

		// Color settings

		if ( apply_filters( 'tfm_hero_theme_supports_color_options', true )):

		/**
		Separator
		**/
		$wp_customize->add_setting('tfm_hero_colors_separator', array(
			'default'           => '',
			'sanitize_callback' => 'esc_html',
		));
		$wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, 'tfm_hero_colors_separator', array(
			'settings'		=> 'tfm_hero_colors_separator',
			'section'  		=> 'tfm_hero_settings',
		)));

		$wp_customize->add_setting('tfm_hero_background_image', array(
				'default'           => '',
				'sanitize_callback' => 'tfm_sanitize_image',
			));

			$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'tfm_hero_background_image', array(
		               'label'      => esc_html__( 'Background Image', 'tfm-theme-boost' ),
		               'section'    => 'tfm_hero_settings',
		           )
		       )
		   );

		$wp_customize->add_setting( 'tfm_hero_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_hero_background', array(
	      'section' => 'tfm_hero_settings',
	      'label'   => esc_html__( 'Hero Background Color', 'tfm-theme-boost' ),
	    ) ) );

		$wp_customize->add_setting( 'tfm_hero_post_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_hero_post_background', array(
	      'section' => 'tfm_hero_settings',
	      'label'   => esc_html__( 'Post Background Color', 'tfm-theme-boost' ),
	    ) ) );

	    $wp_customize->add_setting( 'tfm_hero_entry_title_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_hero_entry_title_color', array(
	      'section' => 'tfm_hero_settings',
	      'label'   => esc_html__( 'Entry Title Color', 'tfm-theme-boost' ),
	    ) ) );

	     $wp_customize->add_setting( 'tfm_hero_entry_meta_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_hero_entry_meta_color', array(
	      'section' => 'tfm_hero_settings',
	      'label'   => esc_html__( 'Entry Meta Color', 'tfm-theme-boost' ),
	    ) ) );

	    $wp_customize->add_setting( 'tfm_hero_entry_meta_link_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_hero_entry_meta_link_color', array(
	      'section' => 'tfm_hero_settings',
	      'label'   => esc_html__( 'Entry Meta Link Color', 'tfm-theme-boost' ),
	    ) ) );

	    $wp_customize->add_setting( 'tfm_hero_entry_meta_icon_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_hero_entry_meta_icon_color', array(
	      'section' => 'tfm_hero_settings',
	      'label'   => esc_html__( 'Entry Meta Icon Color', 'tfm-theme-boost' ),
	    ) ) );

	    $wp_customize->add_setting( 'tfm_hero_avatar_border_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_hero_avatar_border_color', array(
	      'section' => 'tfm_hero_settings',
	      'label'   => esc_html__( 'Avatar Border Color', 'tfm-theme-boost' ),
	    ) ) );

	    $wp_customize->add_setting( 'tfm_hero_entry_content_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_hero_entry_content_color', array(
	      'section' => 'tfm_hero_settings',
	      'label'   => esc_html__( 'Excerpt Color', 'tfm-theme-boost' ),
	    ) ) );

	    $wp_customize->add_setting( 'tfm_hero_button_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_hero_button_background', array(
	      'section' => 'tfm_hero_settings',
	      'label'   => esc_html__( 'Button Background', 'tfm-theme-boost' ),
	    ) ) );

	    $wp_customize->add_setting( 'tfm_hero_button_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_hero_button_color', array(
	      'section' => 'tfm_hero_settings',
	      'label'   => esc_html__( 'Button Color', 'tfm-theme-boost' ),
	    ) ) );

	    $wp_customize->add_setting( 'tfm_hero_border_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_hero_border_color', array(
	      'section' => 'tfm_hero_settings',
	      'label'   => esc_html__( 'Border Color', 'tfm-theme-boost' ),
	    ) ) );

	    $wp_customize->add_setting( 'tfm_hero_count_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_hero_count_background', array(
	      'section' => 'tfm_hero_settings',
	      'label'   => esc_html__( 'Count Background', 'tfm-theme-boost' ),
	    ) ) );

	     $wp_customize->add_setting( 'tfm_hero_count_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_hero_count_color', array(
	      'section' => 'tfm_hero_settings',
	      'label'   => esc_html__( 'Count Text Color', 'tfm-theme-boost' ),
	    ) ) );

	    $wp_customize->add_setting( 'tfm_hero_arrow_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_hero_arrow_background', array(
	      'section' => 'tfm_hero_settings',
	      'label'   => esc_html__( 'Arrow Background Color', 'tfm-theme-boost' ),
	    ) ) );

	     $wp_customize->add_setting( 'tfm_hero_arrow_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_hero_arrow_color', array(
	      'section' => 'tfm_hero_settings',
	      'label'   => esc_html__( 'Arrow Color', 'tfm-theme-boost' ),
	    ) ) );

	endif; // endif theme supports Hero colors

}

add_action( 'customize_register', 'tfm_hero_customize_register' );


?>