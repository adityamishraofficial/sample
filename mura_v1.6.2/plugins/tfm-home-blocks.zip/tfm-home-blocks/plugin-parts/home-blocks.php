<?php

/**
 * 340 Media: Homepage Blocks
 *
 * @since 1.0
 * @version 1.1.2
 */

?>

<?php 

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! is_front_page() || is_paged() ) {
	return; // Return if not home
}

// ========================================================
// Check if we're running the custom post loop
// ========================================================
$prev_has_background = null;
$prev_background_color = null;
$home_blocks = tfm_home_blocks_active( true );

if ( count($home_blocks) !== 0 ) {

	foreach ( $home_blocks as $block => $value ) {

		include( TFM_POST_BLOCKS__PLUGIN_DIR . 'inc/vars.php' );

		$background_match = get_theme_mod( $block . '_background', '' ) === $prev_background_color ? ' tfm-prev-background-match' : '';


// ========================================================
// Posts
// ========================================================

	$posts_query = new WP_Query( $query_args  );

	// ========================================================
	// Set a temp transient if we don't already have one
	// ========================================================

	if ( false === get_transient( $block )) {

		$transient_post_ids = wp_list_pluck( $posts_query->posts, 'ID' );

		set_transient( $block, $transient_post_ids, 24 * HOUR_IN_SECONDS );

	}

    if( $posts_query->have_posts( ) || $has_block_sidebar ) :

    $count = 0;
    $faux_count = 0;

     ?>

    <?php if ( $custom_color['background'] ): ?>
    <div class="tfm-post-block-background-wrapper alignfull <?php echo esc_attr( $prev_has_background . $background_match ); ?>"<?php echo wp_kses( $custom_color['background'], $allowed_html ) ?>>
    <?php endif; ?>

    <div id="<?php echo esc_attr( $block ); ?>" class="content-area tfm-post-block-wrap <?php echo esc_attr( $block . $has_title . $has_subtitle . $has_link_more . $has_block_sidebar . $block_sidebar_position . $prev_has_background . $alignfull . $woocommerce ); ?>" data-fullwidth="<?php echo esc_attr( $full_width ); ?>">

    	<?php if ( ($has_title || $has_subtitle || is_customize_preview() ) && apply_filters( 'tfm_home_blocks_header_position', 'after_wrap' ) === 'after_wrap' ):

    	// ========================================================
		// Header Title & Subtitle
		// ========================================================

		include( TFM_POST_BLOCKS__PLUGIN_DIR . 'plugin-parts/header.php' );

		endif; ?>

		<?php 

		// If we have posts open the grid container
		if ( $posts_query->have_posts( ) ): ?>

	<div class="content-area post-grid tfm-posts-block <?php echo esc_attr( $cols_class . $layout . $has_post_count . $alignfull ); ?>" data-posts="<?php echo esc_attr( $post_num ); ?>" data-poststyle="<?php echo esc_attr( $post_style ); ?>" data-thumbnail="<?php echo esc_attr( $thumbnail_aspect_ratio ); ?>" data-fullwidth="<?php echo esc_attr( $full_width ); ?>" data-margins="<?php echo esc_attr( $margins ); ?>">

		<?php if ( ($has_title || $has_subtitle) && apply_filters( 'tfm_home_blocks_header_position', 'after_wrap' ) === 'after_content_wrap' ):

    	// ========================================================
		// Header Title & Subtitle
		// ========================================================

		include( TFM_POST_BLOCKS__PLUGIN_DIR . 'plugin-parts/header.php' );

		endif; ?>

    <?php 

    	while ( $posts_query->have_posts( ) ) : $posts_query->the_post();  ?>

    	<?php

    	$count++;
    	$faux_count++;

    	// ========================================================
		// Reset faux counter for offset displays
		// ========================================================

		if ( get_theme_mod( $block . '_layout', 'grid' ) === 'grid-offset-half' && $faux_count === 6 ) {
			$faux_count = 1;
		}

		if ( get_theme_mod( $block . '_layout', 'grid' ) === 'grid-list-half' && $faux_count === 6 ) {
			$faux_count = 1;
		}

		if ( get_theme_mod( $block . '_layout', 'grid' ) === 'grid-offset' && $faux_count === 4 ) {
			$faux_count = 1;
		}

		if ( get_theme_mod( $block . '_layout', 'grid' ) === 'grid-offset-sides' && $faux_count === 6 ) {
			$faux_count = 1;
		}

		// ========================================================
		// Additional In loop vars
		// ========================================================

    	$thumbnail_class = ( '' !== get_the_post_thumbnail() && $show_thumbnail ? ' has-post-media has-post-thumbnail' . $thumbnail_aspect_ratio . '' : '' );
    	$grid_style = get_theme_mod( $block . '_layout', 'grid' ) === 'grid-list-half' && $faux_count === 1 ? ' grid-style' : '';

    	// ========================================================
		// Open side wrapper for offset layouts
		// ========================================================

    	if ( ( ( get_theme_mod( $block . '_layout', 'grid' ) === 'grid-offset' || get_theme_mod( $block . '_layout', 'grid' ) === 'grid-offset-half' || get_theme_mod( $block . '_layout', 'grid' ) === 'grid-list-half' ) && $post_num > 1 && $faux_count === 2 ) || get_theme_mod( $block . '_layout', 'grid' ) === 'grid-offset-sides' && ( $faux_count === 1 || $faux_count === 4 ) ) :

    	$wrapper_open = true; ?>

    	<div class="tfm-post-block-offset-wrapper post-grid<?php echo esc_attr( $offset_list ); ?>">

    	<?php endif;

    	// ========================================================
		// Assign post style class to cover/default mix styles
		// ========================================================

		// Force default post style for video format
		if ( $show_media && ( $post_style === 'cover' || $post_style === 'cover-default' ) && tfm_home_blocks_featured_video( true ) ) {
		    $meta_vars = str_replace('cover-default', 'default', $meta_vars);
		}

    	// Initially set to cover
		if ( $meta_var['style'] === 'cover-default') {
			$meta_vars = str_replace('cover-default', 'cover', $meta_vars);
		}

		// Remove cover style for offset
		if ( $meta_var['style'] === 'cover-default' && $wrapper_open ) {
			$meta_vars = str_replace('cover', 'cover-default', $meta_vars);
		}


		// ========================================================
		// Include content
		// ========================================================

		if ( $post_type !== 'recent_products' && $post_type !== 'product_ids' ) :

			// Posts

    		include( TFM_POST_BLOCKS__PLUGIN_DIR . 'plugin-parts/content.php' );

	    else:

	    	// Products

	    	include( TFM_POST_BLOCKS__PLUGIN_DIR . 'plugin-parts/content-product.php' );

	    endif;

		// ========================================================
		// Close first side wrapper .grid-offset-sides
		// ========================================================

		if ( $wrapper_open ) {

			if ( get_theme_mod( $block . '_layout', 'grid' ) === 'grid-offset-half' && $post_num > 5 && $faux_count === 5 ) {
				echo '</div>';
				$wrapper_open = false;
			}
			if ( get_theme_mod( $block . '_layout', 'grid' ) === 'grid-list-half' && $post_num > 5 && $faux_count === 5 ) {
				echo '</div>';
				$wrapper_open = false;
			}

			if ( get_theme_mod( $block . '_layout', 'grid' ) === 'grid-offset' && $post_num > 3 && $faux_count === 3 ) {
				echo '</div>';
				$wrapper_open = false;
			}

			if ( get_theme_mod( $block . '_layout', 'grid' ) === 'grid-offset-sides' && ( $faux_count === 2 || $faux_count === 5 ) ) {
				echo '</div>';
				$wrapper_open = false;
			}

		}

	endwhile;

	// ========================================================
	// Close side wrapper if active
	// ========================================================

	if ( $wrapper_open ) {
		echo '</div><!-- .side-wrapper -->';
	} ?>

	</div><!-- .post-grid -->

	<?php endif; // endif have posts ?>

	<?php if ( $has_block_sidebar ): ?>

    <aside class="tfm-post-block-sidebar sidebar<?php echo esc_attr( $widget_background ); ?>">
    	<?php dynamic_sidebar( 'sidebar-' . $block ); ?>
    </aside>

    <?php endif; // End sidebar ?>

	</div><!-- .block wrap -->
	
	<?php if ( $custom_color['background'] ): ?>
	</div><!-- .backround wrapper -->
	<?php endif;

    endif; // Endif have posts

if( $prev_has_background ) {
	    $prev_has_background = $prev_has_background;
	  }
	  if( $prev_background_color ) {
	    $prev_background_color = $prev_background_color;
	  }
$prev_has_background = ( get_theme_mod( $block . '_background', '' ) ? ' tfm-prev-has-background' : '' );
$prev_background_color = get_theme_mod( $block . '_background', '' );


    wp_reset_postdata(); // Always reset

} // End foreach block
} // End if blocks

 	?>

<?php //endif; ?>