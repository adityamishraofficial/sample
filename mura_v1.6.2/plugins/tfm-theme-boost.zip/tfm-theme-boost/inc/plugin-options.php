<?php

class TFMThemeBoost {
	private $tfm_theme_boost_options;

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'tfm_theme_boost_add_plugin_page' ) );
		add_action( 'admin_init', array( $this, 'tfm_theme_boost_page_init' ) );
	}

	public function tfm_theme_boost_add_plugin_page() {
		add_menu_page(
			'TFM Theme Boost', // page_title
			'TFM Theme Boost', // menu_title
			'manage_options', // capability
			'tfm-theme-boost', // menu_slug
			array( $this, 'tfm_theme_boost_create_admin_page' ), // function
			'dashicons-admin-settings', // icon_url
			2 // position
		);
	}

	public function tfm_theme_boost_create_admin_page() {
		$this->tfm_theme_boost_options = get_option( 'tfm_theme_boost_option_name' ); ?>

		<div class="wrap">
			<h2><?php echo esc_html__( 'TFM Theme Boost', 'tfm-theme-boost' ); ?></h2>
			<!-- <p>Choose the plugin features you want</p> -->
			<?php settings_errors(); ?>

			<form method="post" action="options.php">
				<?php
					settings_fields( 'tfm_theme_boost_option_group' );
					do_settings_sections( 'tfm-theme-boost-admin' );
					submit_button();
				?>
			</form>
		</div>
	<?php }

	public function tfm_theme_boost_page_init() {
		register_setting(
			'tfm_theme_boost_option_group', // option_group
			'tfm_theme_boost_option_name', // option_name
			array( $this, 'tfm_theme_boost_sanitize' ) // sanitize_callback
		);

		add_settings_section(
			'tfm_theme_boost_setting_section', // id
			esc_html__( 'Settings', 'tfm-theme-boost' ), // title
			array( $this, 'tfm_theme_boost_section_info' ), // callback
			'tfm-theme-boost-admin' // page
		);

		// Hero

		add_settings_field(
			'tfm_hero', // id
			esc_html__( 'Hero', 'tfm-theme-boost' ), // title
			array( $this, 'tfm_hero_callback' ), // callback
			'tfm-theme-boost-admin', // page
			'tfm_theme_boost_setting_section' // section
		);

		// Related posts

		add_settings_field(
			'tfm_related_posts', // id
			esc_html__( 'Related Posts', 'tfm-theme-boost' ), // title
			array( $this, 'tfm_related_posts_callback' ), // callback
			'tfm-theme-boost-admin', // page
			'tfm_theme_boost_setting_section' // section
		);

		// Featured posts (if supported)

		if ( apply_filters( 'tfm_theme_supports_featured_posts', false ) ) {

			add_settings_field(
				'tfm_featured_posts', // id
				esc_html__( 'Featured Posts', 'tfm-theme-boost' ), // title
				array( $this, 'tfm_featured_posts_callback' ), // callback
				'tfm-theme-boost-admin', // page
				'tfm_theme_boost_setting_section' // section
			);

		}

		// Social media

		add_settings_field(
			'tfm_social', // id
			esc_html__( 'Social Media', 'tfm-theme-boost' ), // title
			array( $this, 'tfm_social_callback' ), // callback
			'tfm-theme-boost-admin', // page
			'tfm_theme_boost_setting_section' // section
		);

		// Ads

		add_settings_field(
			'tfm_ads', // id
			esc_html__( 'Advertising', 'tfm-theme-boost' ), // title
			array( $this, 'tfm_ads_callback' ), // callback
			'tfm-theme-boost-admin', // page
			'tfm_theme_boost_setting_section' // section
		);

		// Image quality

		add_settings_field(
			'tfm_image_quality', // id
			esc_html__( 'Image Quality', 'tfm-theme-boost' ), // title
			array( $this, 'tfm_image_quality_callback' ), // callback
			'tfm-theme-boost-admin', // page
			'tfm_theme_boost_setting_section' // section
		);

		if ( apply_filters( 'tfm_theme_supports_human_dates', true ) ) {

			// Entry dates

			add_settings_field(
				'tfm_human_entry_date', // id
				esc_html__( 'Entry Dates', 'tfm-theme-boost' ), // title
				array( $this, 'tfm_human_entry_date_callback' ), // callback
				'tfm-theme-boost-admin', // page
				'tfm_theme_boost_setting_section' // section
			);

			// Comment dates

			add_settings_field(
				'tfm_human_comment_date', // id
				esc_html__( 'Comment Dates', 'tfm-theme-boost' ), // title
				array( $this, 'tfm_human_comment_date_callback' ), // callback
				'tfm-theme-boost-admin', // page
				'tfm_theme_boost_setting_section' // section
			);

		}
		
	}

	public function tfm_theme_boost_sanitize($input) {
		$sanitary_values = array();
		if ( isset( $input['tfm_hero'] ) ) {
			$sanitary_values['tfm_hero'] = $input['tfm_hero'];
		}

		if ( isset( $input['tfm_related_posts'] ) ) {
			$sanitary_values['tfm_related_posts'] = $input['tfm_related_posts'];
		}

		if ( isset( $input['tfm_featured_posts'] ) ) {
			$sanitary_values['tfm_featured_posts'] = $input['tfm_featured_posts'];
		}

		if ( isset( $input['tfm_social'] ) ) {
			$sanitary_values['tfm_social'] = $input['tfm_social'];
		}

		if ( isset( $input['tfm_ads'] ) ) {
			$sanitary_values['tfm_ads'] = $input['tfm_ads'];
		}
		if ( isset( $input['tfm_image_quality'] ) ) {
			$sanitary_values['tfm_image_quality'] = sanitize_text_field( $input['tfm_image_quality'] );
		}

		if ( isset( $input['tfm_human_entry_date'] ) ) {
			$sanitary_values['tfm_human_entry_date'] = $input['tfm_human_entry_date'];
		}

		if ( isset( $input['tfm_human_comment_date'] ) ) {
			$sanitary_values['tfm_human_comment_date'] = $input['tfm_human_comment_date'];
		}

		return $sanitary_values;
	}

	public function tfm_theme_boost_section_info() {
		
	}

	public function tfm_hero_callback() {
		printf(
			'<fieldset><input type="checkbox" name="tfm_theme_boost_option_name[tfm_hero]" id="tfm_hero" value="tfm_hero" %s> <label for="tfm_hero">' . esc_html__( 'Enable Hero', 'tfm-theme-boost' ) . '</label><p class="description">' . esc_html__( 'Appearance > Customize > TFM: Hero', 'tfm-theme-boost' ) . '</p></fieldset>',
			( isset( $this->tfm_theme_boost_options['tfm_hero'] ) && $this->tfm_theme_boost_options['tfm_hero'] === 'tfm_hero' ) ? 'checked' : ''
		);
	}

	public function tfm_related_posts_callback() {
		printf(
			'<fieldset><input type="checkbox" name="tfm_theme_boost_option_name[tfm_related_posts]" id="tfm_related_posts" value="tfm_related_posts" %s> <label for="tfm_related_posts">' . esc_html__( 'Enable Related Posts', 'tfm-theme-boost' ) . '</label><p class="description">' . esc_html__( 'Appearance > Customize > TFM: Related Posts', 'tfm-theme-boost' ) . '</p></fieldset>',
			( isset( $this->tfm_theme_boost_options['tfm_related_posts'] ) && $this->tfm_theme_boost_options['tfm_related_posts'] === 'tfm_related_posts' ) ? 'checked' : ''
		);
	}

	public function tfm_featured_posts_callback() {

		if ( apply_filters( 'tfm_theme_supports_featured_posts', false ) ) {

			printf(
				'<fieldset><input type="checkbox" name="tfm_theme_boost_option_name[tfm_featured_posts]" id="tfm_featured_posts" value="tfm_featured_posts" %s> <label for="tfm_featured_posts">' . esc_html__( 'Enable Featured Posts', 'tfm-theme-boost' ) . '</label><p class="description">' . esc_html__( 'Appearance > Customize > TFM: Featured Posts', 'tfm-theme-boost' ) . '</p></fieldset>',
				( isset( $this->tfm_theme_boost_options['tfm_featured_posts'] ) && $this->tfm_theme_boost_options['tfm_featured_posts'] === 'tfm_featured_posts' ) ? 'checked' : ''
			);

		}
		
	}

	public function tfm_social_callback() {
		printf(
			'<fieldset><input type="checkbox" name="tfm_theme_boost_option_name[tfm_social]" id="tfm_social" value="tfm_social" %s> <label for="tfm_social">' . esc_html__( 'Enable Social Media Settings', 'tfm-theme-boost' ) . '</label><p class="description">' . esc_html__( 'Appearance > Customize > TFM: Social Media', 'tfm-theme-boost' ) . '</p></fieldset>',
			( isset( $this->tfm_theme_boost_options['tfm_social'] ) && $this->tfm_theme_boost_options['tfm_social'] === 'tfm_social' ) ? 'checked' : ''
		);
	}

	public function tfm_ads_callback() {
		printf(
			'<fieldset><input type="checkbox" name="tfm_theme_boost_option_name[tfm_ads]" id="tfm_ads" value="tfm_ads" %s> <label for="tfm_ads">' . esc_html__( 'Enable Advertising', 'tfm-theme-boost' ) . '</label><p class="description">' . esc_html__( 'Appearance > Customize > TFM: Advertising', 'tfm-theme-boost' ) . '</p></fieldset>',
			( isset( $this->tfm_theme_boost_options['tfm_ads'] ) && $this->tfm_theme_boost_options['tfm_ads'] === 'tfm_ads' ) ? 'checked' : ''
		);
	}

	public function tfm_image_quality_callback() {
		printf(
			'<fieldset><input class="small-text" type="number" name="tfm_theme_boost_option_name[tfm_image_quality]" id="tfm_image_quality" value="%s"><p class="description">' . esc_html__( 'Lower quality provides a smaller file size and faster loading pages. Remember to regenerate your thumbnails after changing this setting. WordPress default setting is "82"', 'tfm-theme-boost' ) . '</p></fieldset>',
			isset( $this->tfm_theme_boost_options['tfm_image_quality'] ) ? esc_attr( $this->tfm_theme_boost_options['tfm_image_quality']) : '82'
		);
	}

	public function tfm_human_entry_date_callback() {

		if ( apply_filters( 'tfm_theme_supports_human_dates', true ) ) {

			printf(
				'<fieldset><input type="checkbox" name="tfm_theme_boost_option_name[tfm_human_entry_date]" id="tfm_human_entry_date" value="tfm_human_entry_date" %s> <label for="tfm_human_entry_date">' . esc_html__( 'Display entry dates in human readable format', 'tfm-theme-boost' ) . '</label></fieldset>',
				( isset( $this->tfm_theme_boost_options['tfm_human_entry_date'] ) && $this->tfm_theme_boost_options['tfm_human_entry_date'] === 'tfm_human_entry_date' ) ? 'checked' : ''
			);

		}

	}

	public function tfm_human_comment_date_callback() {

		if ( apply_filters( 'tfm_theme_supports_human_dates', true ) ) {

			printf(
				'<fieldset><input type="checkbox" name="tfm_theme_boost_option_name[tfm_human_comment_date]" id="tfm_human_comment_date" value="tfm_human_comment_date" %s> <label for="tfm_human_comment_date">' . esc_html__( 'Display comment dates in human readable format', 'tfm-theme-boost' ) . '</label></fieldset>',
				( isset( $this->tfm_theme_boost_options['tfm_human_comment_date'] ) && $this->tfm_theme_boost_options['tfm_human_comment_date'] === 'tfm_human_comment_date' ) ? 'checked' : ''
			);

		}

	}

}
if ( is_admin() )
	$tfm_theme_boost = new TFMThemeBoost();

/* 
 * Retrieve this value with:
 * $tfm_theme_boost_options = get_option( 'tfm_theme_boost_option_name' ); // Array of All Options
 * $tfm_hero = $tfm_theme_boost_options['tfm_hero']; // tfm_hero
 * $tfm_related_posts = $tfm_theme_boost_options['tfm_related_posts']; // tfm_related_posts
 * $tfm_featured_posts = $tfm_theme_boost_options['tfm_featured_posts']; // tfm_related_posts
 * $tfm_social = $tfm_theme_boost_options['tfm_social']; // tfm_social
 * $tfm_ads = $tfm_theme_boost_options['tfm_ads']; // tfm_ads
 * $tfm_image_quality = $tfm_theme_boost_options['tfm_image_quality']; // tfm_image_quality
 * $tfm_human_entry_date = $tfm_theme_boost_options['tfm_human_entry_date']; // tfm_human_entry_date
 * $tfm_human_comment_date = $tfm_theme_boost_options['tfm_human_comment_date']; // tfm_human_comment_date
 */
