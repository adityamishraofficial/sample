/**
 * Customizer Controls JS
 *
 * Adds Javascript for Customizer Controls.
 *
 */

(function( $ ) {
    wp.customize.bind( 'ready', function() {
        var customize = this;
        // Codes here
    } );
})( jQuery );
