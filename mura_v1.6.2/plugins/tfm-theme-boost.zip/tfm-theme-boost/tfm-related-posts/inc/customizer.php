<?php

/**
 * 3Fortymedia: Related Post Settings
 *
 * @package WordPress
 * @subpackage 3FortyMedia
 * @since 1.0
 * @version 1.2
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


function tfm_related_posts_customize_register( $wp_customize ) {

	// Custom controls
	require_once 'custom_controls.php';

		// ========================================================
		// Related Posts
		// ========================================================

		$wp_customize->add_section( 'tfm_related_posts_settings', array(
			'title'    => esc_html__( 'TFM: Related Posts', 'tfm-theme-boost' ),
			'priority' => 160,
		) );

		/**
		 * Display Posts
		 */
		$wp_customize->add_setting( 'tfm_related_posts', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_related_posts', array(
			'label'       => esc_html__( 'Display Related Posts', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'checkbox',
		) );

		// Add Setting
		$wp_customize->add_setting( 'tfm_related_posts_title', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_text',
		) );

		// Control Options
		$wp_customize->add_control( 'tfm_related_posts_title', array(
			'label'       => esc_html__( 'Title', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'text',
		) );

		// Add Setting
		$wp_customize->add_setting( 'tfm_related_posts_subtitle', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_text',
		) );

		// Control Options
		$wp_customize->add_control( 'tfm_related_posts_subtitle', array(
			'label'       => esc_html__( 'Subtitle', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'text',
		) );

		$wp_customize->add_setting( 'tfm_related_posts_method', array(
			'default'           => 'tags',
			'sanitize_callback' => 'tfm_sanitize_select',
		) );

		$wp_customize->add_control( 'tfm_related_posts_method', array(
			'label'       => esc_html__( 'Relationship Method', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'select',
			'choices'     => array(
				'tags' => esc_html__( 'Tags', 'tfm-theme-boost' ),
				'category' => esc_html__( 'Category', 'tfm-theme-boost' ),
				'author' => esc_html__( 'Author', 'tfm-theme-boost'),
			),
		) );

		$wp_customize->add_setting( 'tfm_related_posts_sort_order', array(
			'default'           => 'rand',
			'sanitize_callback' => 'tfm_sanitize_select',
		) );

		$wp_customize->add_control( 'tfm_related_posts_sort_order', array(
			'label'       => esc_html__( 'Sort Order', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'select',
			'choices'     => array(
				'rand' => esc_html__( 'Random', 'tfm-theme-boost' ),
				'desc' => esc_html__( 'Newest to Oldest', 'tfm-theme-boost' ),
				'asc' => esc_html__( 'Oldest to Newest', 'tfm-theme-boost' ),
			),
		) );

		/**
		 * Number of Posts
		 */
		$wp_customize->add_setting( 'tfm_related_posts_num', array(
			'default'           => 3,
			'sanitize_callback' => 'absint',
		) );

		$wp_customize->add_control( 'tfm_related_posts_num', array(
			'label'       => esc_html__( 'Number of posts', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'number',
			'input_attrs' => array(
		        'min'   => 1,
		        'max'   => apply_filters( 'tfm_related_posts_max_posts', 999 ),
		    ),
		) );

		/**
		 * Number of columns
		 */
		$wp_customize->add_setting( 'tfm_related_posts_cols', array(
			'default'           => apply_filters( 'tfm_related_posts_max_cols', 4 ),
			'sanitize_callback' => 'absint',
		) );

		$wp_customize->add_control( 'tfm_related_posts_cols', array(
			'label'       => esc_html__( 'Number of columns', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'number',
			'input_attrs' => array(
		        'min'   => 1,
		        'max'   => apply_filters( 'tfm_related_posts_max_cols', 4 ),
		    ),
		) );

		/**
		 * Loop style
		 */
		$wp_customize->add_setting( 'tfm_related_posts_layout', array(
			'default'           => 'grid',
			'sanitize_callback' => 'tfm_sanitize_select',
		) );

		$wp_customize->add_control( 'tfm_related_posts_layout', array(
			'label'       => esc_html__( 'Layout', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'select',
			'choices'     => array(
				'grid' => esc_html__( 'Grid', 'tfm-theme-boost' ),
				'list' => esc_html__( 'List', 'tfm-theme-boost' ),
			),
		) );

		/**
		 * Loop style
		 */
		$wp_customize->add_setting( 'tfm_related_posts_style', array(
			'default'           => 'default',
			'sanitize_callback' => 'tfm_sanitize_select',
		) );

		$wp_customize->add_control( 'tfm_related_posts_style', array(
			'label'       => esc_html__( 'Post Style', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'select',
			'choices'     => array(
				'default' => esc_html__( 'Default', 'tfm-theme-boost' ),
				'cover' => esc_html__( 'Cover', 'tfm-related-postsv' ), // Remove this with a filter if not required for a theme
			),
		) );

		$wp_customize->add_setting( 'tfm_related_posts_image_size', array(
			'default'           => 'landscape',
			'sanitize_callback' => 'tfm_sanitize_select',
		) );

		$wp_customize->add_control( 'tfm_related_posts_image_size', array(
			'label'       => esc_html__( 'Thumbnail Size', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'select',
			'choices'     => array(
				'wide' => esc_html__( 'Wide', 'tfm-theme-boost' ),
				'landscape' => esc_html__( 'Landscape', 'tfm-theme-boost' ),
				'portrait' => esc_html__( 'Portrait', 'tfm-theme-boost' ),
				'square' => esc_html__( 'Square', 'tfm-theme-boost' ),
				'uncropped' => esc_html__( 'Uncropped', 'tfm-theme-boost' ),
			),
		) );

		$wp_customize->add_setting( 'tfm_related_posts_thumbnail', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_related_posts_thumbnail', array(
			'label'       => esc_html__( 'Thumbnail', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'checkbox',
		) );

		/**
		 * Entry title/meta
		 */

		$wp_customize->add_setting( 'tfm_related_posts_excerpt', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_related_posts_excerpt', array(
			'label'       => esc_html__( 'Excerpt', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_related_posts_read_more', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_related_posts_read_more', array(
			'label'       => esc_html__( 'Read More', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'checkbox',
		) );

		// Entry Title
		$wp_customize->add_setting( 'tfm_related_posts_entry_title', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_related_posts_entry_title', array(
			'label'       => esc_html__( 'Entry Title', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'checkbox',
		) );

		// Author Meta
		$wp_customize->add_setting( 'tfm_related_posts_entry_meta_by', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_related_posts_entry_meta_by', array(
			'label'       => esc_html__( '"by"', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'checkbox',
		) );

		// Author Meta
		$wp_customize->add_setting( 'tfm_related_posts_entry_meta_in', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_related_posts_entry_meta_in', array(
			'label'       => esc_html__( '"in"', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'checkbox',
		) );

		// Author Meta
		$wp_customize->add_setting( 'tfm_related_posts_entry_meta_author', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_related_posts_entry_meta_author', array(
			'label'       => esc_html__( 'Author', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'checkbox',
		) );

		// Author Avatar
		$wp_customize->add_setting( 'tfm_related_posts_entry_meta_author_avatar', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_related_posts_entry_meta_author_avatar', array(
			'label'       => esc_html__( 'Author Avatar', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'checkbox',
		) );

		// Category Meta
		$wp_customize->add_setting( 'tfm_related_posts_entry_meta_category', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_related_posts_entry_meta_category', array(
			'label'       => esc_html__( 'Category', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'checkbox',
		) );

		// NUmber of category tags
		$wp_customize->add_setting( 'tfm_related_posts_entry_meta_category_slugs', array(
			'default'           => 1,
			'sanitize_callback' => 'absint',
		) );

		$wp_customize->add_control( 'tfm_related_posts_entry_meta_category_slugs', array(
			'label'       => esc_html__( 'Number of category tags', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'number',
			'input_attrs' => array(
		        'min'   => 1,
		    ),
		) );

		// Date Meta
		$wp_customize->add_setting( 'tfm_related_posts_entry_meta_date', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_related_posts_entry_meta_date', array(
			'label'       => esc_html__( 'Date', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'checkbox',
		) );

		// Date Meta
		if ( function_exists( 'tfm_read_time' ) ) :
			$wp_customize->add_setting( 'tfm_related_posts_entry_meta_read_time', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			$wp_customize->add_control( 'tfm_related_posts_entry_meta_read_time', array(
				'label'       => esc_html__( 'Read Time', 'tfm-theme-boost' ),
				'section'     => 'tfm_related_posts_settings',
				'type'        => 'checkbox',
			) );
		endif;

		// Comments Meta
		$wp_customize->add_setting( 'tfm_related_posts_entry_meta_comment_count', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_related_posts_entry_meta_comment_count', array(
			'label'       => esc_html__( 'Comment Count', 'tfm-theme-boost' ),
			'section'     => 'tfm_related_posts_settings',
			'type'        => 'checkbox',
		) );

		// ========================================================
		// Ratings checkboxes (TFM Theme Boost) function
		// ========================================================

		if ( function_exists('tfm_ratings')):

			/**
			Separator
			**/
			$wp_customize->add_setting('tfm_related_posts_ratings_separator', array(
				'default'           => '',
				'sanitize_callback' => 'esc_html',
			));
			$wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, 'tfm_related_posts_ratings_separator', array(
				'settings'		=> 'tfm_related_posts_ratings_separator',
				'section'  		=> 'tfm_related_posts_settings',
			)));

			/**
			Info
			**/
		    $wp_customize->add_setting('tfm_related_posts_ratings_info', array(
		        'default'           => '',
		        'sanitize_callback' => 'tfm_sanitize_text',
		     
		    ));
		    $wp_customize->add_control(new Tfm_Info_Custom_Control($wp_customize, 'tfm_related_posts_ratings_info', array(
		        'label'         => esc_html__('Ratings', 'tfm-theme-boost'),
		        'description' => esc_html__( 'Add a rating to your posts to use this feature', 'tfm-theme-boost' ),
		        'settings'		=> 'tfm_related_posts_ratings_info',
		        'section'  		=> 'tfm_related_posts_settings',
		    )));

			// Add Setting
			$wp_customize->add_setting( 'tfm_related_posts_tfm_star_rating', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			// Control Options
			$wp_customize->add_control('tfm_related_posts_tfm_star_rating', array(
				'label'       => esc_html__( 'Star Rating', 'tfm-theme-boost' ),
				'section'     => 'tfm_related_posts_settings',
				'type'        => 'checkbox',
			) );

			// Add Setting
			$wp_customize->add_setting( 'tfm_related_posts_tfm_scale_rating', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			// Control Options
			$wp_customize->add_control('tfm_related_posts_tfm_scale_rating', array(
				'label'       => esc_html__( 'Scale Rating', 'tfm-theme-boost' ),
				'section'     => 'tfm_related_posts_settings',
				'type'        => 'checkbox',
			) );

			// Add Setting
			$wp_customize->add_setting( 'tfm_related_posts_tfm_points_rating', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			// Control Options
			$wp_customize->add_control('tfm_related_posts_tfm_points_rating', array(
				'label'       => esc_html__( 'Points Rating', 'tfm-theme-boost' ),
				'section'     => 'tfm_related_posts_settings',
				'type'        => 'checkbox',
			) );

			// Add Setting
			$wp_customize->add_setting( 'tfm_related_posts_tfm_percent_rating', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			// Control Options
			$wp_customize->add_control('tfm_related_posts_tfm_percent_rating', array(
				'label'       => esc_html__( 'Percent Rating', 'tfm-theme-boost' ),
				'section'     => 'tfm_related_posts_settings',
				'type'        => 'checkbox',
			) );

			// Colors
			$wp_customize->add_setting( 'tfm_related_posts_tfm_stars_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_tfm_stars_color', array(
		      'section'     => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'Stars Color', 'tfm-theme-boost' ),
		    ) ) );

		endif;

		// Color settings

			/**
			Separator
			**/
			$wp_customize->add_setting('tfm_related_posts_colors_separator', array(
				'default'           => '',
				'sanitize_callback' => 'esc_html',
			));
			$wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, 'tfm_related_posts_colors_separator', array(
				'settings'		=> 'tfm_related_posts_colors_separator',
				'section'  		=> 'tfm_related_posts_settings',
			)));

			$wp_customize->add_setting( 'tfm_related_posts_background', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_background', array(
		      'section' => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'Background Color', 'tfm-theme-boost' ),
		    ) ) );

		    $wp_customize->add_setting( 'tfm_related_posts_border_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_border_color', array(
		      'section' => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'Border Color', 'tfm-theme-boost' ),
		    ) ) );

		    $wp_customize->add_setting( 'tfm_related_posts_title_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_title_color', array(
		      'section' => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'Title Color', 'tfm-theme-boost' ),
		    ) ) );

		    $wp_customize->add_setting( 'tfm_related_posts_subtitle_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_subtitle_color', array(
		      'section' => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'SubTitle Color', 'tfm-theme-boost' ),
		    ) ) );

		    $wp_customize->add_setting( 'tfm_related_posts_post_background', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_post_background', array(
		      'section' => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'Post Background Color', 'tfm-theme-boost' ),
		    ) ) );


		    $wp_customize->add_setting( 'tfm_related_posts_entry_title_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_entry_title_color', array(
		      'section' => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'Entry Title Color', 'tfm-theme-boost' ),
		    ) ) );

		    $wp_customize->add_setting( 'tfm_related_posts_entry_meta_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_entry_meta_color', array(
		      'section' => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'Entry Meta Color', 'tfm-theme-boost' ),
		    ) ) );

		    $wp_customize->add_setting( 'tfm_related_posts_entry_meta_link_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_entry_meta_link_color', array(
		      'section' => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'Entry Meta Link Color', 'tfm-theme-boost' ),
		    ) ) );

		    $wp_customize->add_setting( 'tfm_related_posts_entry_meta_icon_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_entry_meta_icon_color', array(
		      'section' => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'Entry Meta Icon Color', 'tfm-theme-boost' ),
		    ) ) );

		    $wp_customize->add_setting( 'tfm_related_posts_entry_meta_cat_link_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_entry_meta_cat_link_color', array(
		      'section' => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'Category Slug Color', 'tfm-theme-boost' ),
		    ) ) );

		    $wp_customize->add_setting( 'tfm_related_posts_entry_content_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_entry_content_color', array(
		      'section' => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'Excerpt Color', 'tfm-theme-boost' ),
		    ) ) );

		    $wp_customize->add_setting( 'tfm_related_posts_entry_meta_border_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_entry_meta_border_color', array(
		      'section' => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'Entry Meta Border Color', 'tfm-theme-boost' ),
		    ) ) );

		    $wp_customize->add_setting( 'tfm_related_posts_continue_reading_button_background', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_continue_reading_button_background', array(
		      'section' => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'Button Color', 'tfm-theme-boost' ),
		    ) ) );

		     $wp_customize->add_setting( 'tfm_related_posts_continue_reading_button_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_continue_reading_button_color', array(
		      'section' => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'Button Text Color', 'tfm-theme-boost' ),
		    ) ) );

		    $wp_customize->add_setting( 'tfm_related_posts_continue_reading_button_hover_background', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_continue_reading_button_hover_background', array(
		      'section' => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'Button Hover Color', 'tfm-theme-boost' ),
		    ) ) );

		     $wp_customize->add_setting( 'tfm_related_posts_continue_reading_button_hover_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_related_posts_continue_reading_button_hover_color', array(
		      'section' => 'tfm_related_posts_settings',
		      'label'   => esc_html__( 'Button Hover Text Color', 'tfm-theme-boost' ),
		    ) ) );

}

add_action( 'customize_register', 'tfm_related_posts_customize_register', 100 );


?>