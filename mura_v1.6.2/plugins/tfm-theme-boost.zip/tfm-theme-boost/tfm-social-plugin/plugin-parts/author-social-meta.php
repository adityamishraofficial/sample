<?php
/**
 * The template for displaying the author social media meta
 *
 */

$style = get_theme_mod( 'tfm_author_social_icon_style', 'icon-background' );
$color_scheme  = get_theme_mod( 'tfm_author_social_icon_color_scheme', 'theme' );
$show_text = get_theme_mod( 'tfm_author_social_icon_text', false );
$has_text = ( true === $show_text ? ' has-text' : '' );
$round = get_theme_mod( 'tfm_author_social_icon_round', false );
$has_round_icons = ( $round ? ' has-round-icons' : '' );

$html = '';

// ========================================================
// Create an array of active sites if we have any
// ========================================================
$author_social = tfm_social_contact_methods( true );
$active_sites = array();

foreach( $author_social as $social_site => $value ) {

    $active_sites[$social_site] = get_the_author_meta( $social_site, '' );
}

$active_social_sites = array_filter($active_sites);

if ( ! empty( $active_social_sites ) ) :

// ========================================================
// We have active sites run the loop
// ========================================================

$html .= '<div class="tfm-author-social">';
$html .= '<ul class="tfm-social-icons ' . esc_attr( $style . ' ' . $color_scheme . $has_text . $has_round_icons ) . '">';

     foreach ( $active_social_sites as $active_site => $value ) {

        $site_name = str_replace('tfm_author_meta_', '', $active_site );
        $class = ( $site_name === '500px' ? 'px500' : $site_name );

        $html .= '<li class="tfm-social-icon ' . $class . '"><a href="' . esc_url( get_the_author_meta($active_site) ) . '" class="' . esc_attr( $active_site ) . '" target="_blank">';
        $html .= '<span><i class="icon-' . esc_attr( $site_name ) . '"></i></span>';
        if ( $show_text ) {
            $html .= '<span class="tfm-social-name">' . esc_html( $site_name ) . '</span>';
        }
        $html .= '</a></li>';

     }

     if ( get_the_author_meta('url')) {

            $html .= '<li class="tfm-social-icon url"><a href="' . esc_url( get_the_author_meta( 'url') ) . '" class="website" target="_blank"><span><i class="icon-globe"></i></span>';
            if ( $show_text ) {
                $html .= '<span class="tfm-social-name">' . esc_html__( 'website', 'tfm-theme-boost' ) . '</span>';
            }
            $html .= '</a></li>';

    }

    if ( get_the_author_meta('user_email') && get_theme_mod( 'tfm_single_author_social_email', false )) {

            $html .= '<li class="tfm-social-icon url"><a href="mailto:' . get_the_author_meta( 'user_email') . '" class="email" target="_blank"><span><i class="icon-mail-alt"></i></span>';
            if ( $show_text ) {
                $html .= '<span class="tfm-social-name">' . esc_html__( 'email', 'tfm-theme-boost' ) . '</span>';
            }
            $html .= '</a></li>';
    }

    $html .= '</ul>';
    $html .= '</div>';

endif; ?>