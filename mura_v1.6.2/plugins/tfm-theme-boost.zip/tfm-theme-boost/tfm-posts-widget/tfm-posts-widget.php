<?php

/**
Plugin Name: TFM: Posts Widget
Plugin URI:  http://www.3forty.media
Description: Customizable posts display widget
Version:     1.3.2
Author:      3FortyMedia
Author URI:  http://www.3forty.media
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

if ( ! function_exists('register_tfm_posts_widget')) {

define( 'tfm_posts_widget__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Register our widget
function register_tfm_posts_widget() {
	register_widget( 'tfm_posts_widget' );
}
add_action( 'widgets_init', 'register_tfm_posts_widget' );

// ========================================================
// Get theme text domain
// ========================================================

if ( ! function_exists( 'tfm_get_theme_textdomain' ) ) {

	function tfm_get_theme_textdomain() {

		$theme = wp_get_theme();
		$theme_slug =  $theme->get( 'TextDomain' );

		// Themes released after Mura
		if ( $theme_slug !== 'mura' ) {
			$theme_slug = 'tfm';
		}

		return $theme_slug;
	}

}

// ========================================================
// Posts Widget
// Displays posts filtered by category, type, recent etc.
// ========================================================

class tfm_posts_widget extends WP_Widget {

	// Setup our widget

	public function __construct() {

		$widget_ops = array(
			'classname' => 'tfm_posts_widget',
			'description' => esc_html__('Customizable post display widget', 'tfm-theme-boost'),
		);

	parent::__construct( 'tfm_posts_widget', esc_html__('TFM: Posts Widget', 'tfm-theme-boost'), $widget_ops );

	}

	// ========================================================
	// BACKEND FORM
	// ========================================================

	public function form($instance) {

		/* Default variables */

		$title = (!empty($instance['title']) ? $instance['title'] : '');
		$subtitle = (!empty($instance['subtitle']) ? $instance['subtitle'] : '');
		$number = (!empty($instance['number']) ? absint($instance['number'] ) : 4);
		$cols = (!empty($instance['cols']) ? absint($instance['cols'] ) : 1);
		$offset = (!empty($instance['offset']) ? absint($instance['offset'] ) : 0);
		$post_type = (!empty($instance['post_type']) ? $instance['post_type'] : 'recent');
		$post_ids = (!empty($instance['widget_post_ids']) ? $instance['widget_post_ids'] : '');
		$tag_ids = (!empty($instance['widget_tag_ids']) ? $instance['widget_tag_ids'] : '');
		$exclude_post_ids = (!empty($instance['widget_exclude_post_ids']) ? $instance['widget_exclude_post_ids'] : '');
		$post_cat = (!empty($instance['post_cat']) ? $instance['post_cat'] : '');
		$sort_order = (!empty($instance['sort_order']) ? $instance['sort_order'] : 'desc');
		$author = (!empty($instance['author']) ? $instance['author'] : '');
		$layout = (!empty($instance['layout']) ? $instance['layout'] : 'list');
		$post_style = (!empty($instance['post_style']) ? $instance['post_style'] : 'default');
		$thumbnail = (isset($instance['thumbnail']) ? (bool) $instance['thumbnail'] : false);
		$thumbnail_size = (!empty($instance['thumbnail_size']) ? $instance['thumbnail_size'] : 'landscape');
		$round_thumbnails = (isset($instance['round_thumbnails']) ? (bool) $instance['round_thumbnails'] : false);
		$by = (isset($instance['by']) ? (bool) $instance['by'] : false);
		$avatar = (isset($instance['avatar']) ? (bool) $instance['avatar'] : false);
		$author_meta = (isset($instance['author_meta']) ? (bool) $instance['author_meta'] : false);
		$in = (isset($instance['in']) ? (bool) $instance['in'] : false);
		$category_meta = (isset($instance['category_meta']) ? (bool) $instance['category_meta'] : false);
		$date_meta = (isset($instance['date_meta']) ? (bool) $instance['date_meta'] : false);
		$comment_count = (isset($instance['comment_count']) ? (bool) $instance['comment_count'] : false);
		$post_count = (isset($instance['post_count']) ? (bool) $instance['post_count'] : false);

		// Title
		$output = '<p style="font-size:13px">' . esc_html__('Add %author% to title/subtitle to display current post author name in single posts. E.g. Posts by %author%', 'tfm-theme-boost') . '</p>';
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('title') ) . '">' . esc_html__('Title:', 'tfm-theme-boost') . '</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr($this->get_field_id('title')) . '" name="' . esc_attr($this->get_field_name('title')) . '" value="' . esc_attr($title) . '">';
		$output .= '</p>';

		// SubTitle
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('subtitle') ) . '">' . esc_html__('Subtitle:', 'tfm-theme-boost') . '</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr($this->get_field_id('subtitle')) . '" name="' . esc_attr($this->get_field_name('subtitle')) . '" value="' . esc_attr($subtitle) . '">';
		$output .= '</p>';

		// Number of Posts
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('number') ) . '">' . esc_html__('Number of Posts:', 'tfm-theme-boost') . '</label>';
		$output .= '<input type="number" min="1" class="widefat" id="' . esc_attr($this->get_field_id('number')) . '" name="' . esc_attr($this->get_field_name('number')) . '" value="' . esc_attr($number) . '">';
		$output .= '</p>';

		// Columns
		// $output .= '<p>';
		// $output .= '<label for="' . esc_attr($this->get_field_id('cols') ) . '">' . esc_html__('Columns: (*Experimental)', 'tfm-theme-boost') . '</label>';
		// $output .= '<input type="number" min="1" class="widefat" id="' . esc_attr($this->get_field_id('cols')) . '" name="' . esc_attr($this->get_field_name('cols')) . '" value="' . esc_attr($cols) . '">';
		// $output .= '</p>';

		// Post Type
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('post_type') ) . '">' . esc_html__('Post Type:', 'tfm-theme-boost') . '</label>';
		$output .= '<select class="widefat" id="' . esc_attr($this->get_field_id('post_type')) . '" name="' . esc_attr($this->get_field_name('post_type')) . '">';
		$output .= '<option ' . selected( $post_type, 'recent', false ) . ' value="recent">' . esc_html__('Recent', 'tfm-theme-boost') . '</option>';
		$output .= '<option ' . selected( $post_type, 'popular', false ) . ' value="popular">' . esc_html__('Popular (Most Comments)', 'tfm-theme-boost') . '</option>';
		$output .= '<option ' . selected( $post_type, 'random', false ) . ' value="random">' . esc_html__('Random', 'tfm-theme-boost') . '</option>';
		$output .= '<option ' . selected( $post_type, 'post_ids', false ) . ' value="post_ids">' . esc_html__('Specific Posts (Enter post IDs below)', 'tfm-theme-boost') . '</option>';
		$output .= '<option ' . selected( $post_type, 'related_tags', false ) . ' value="related_tags">' . esc_html__('Related Posts (by Tags)', 'tfm-theme-boost') . '</option>';
		$output .= '<option ' . selected( $post_type, 'related_category', false ) . ' value="related_category">' . esc_html__('Related Posts (by Category)', 'tfm-theme-boost') . '</option>';
		$output .= '<option ' . selected( $post_type, 'related_author', false ) . ' value="related_author">' . esc_html__('Related Posts (by Author)', 'tfm-theme-boost') . '</option>';
		$output .= '</select>';
		$output .= '</p>';

		// Specific post IDs
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('widget_post_ids') ) . '">' . esc_html__('Post IDs: (Enter a comma separated List of post IDs)', 'tfm-theme-boost') . '</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr($this->get_field_id('widget_post_ids')) . '" name="' . esc_attr($this->get_field_name('widget_post_ids')) . '" value="' . esc_attr($post_ids) . '">';
		$output .= '</p>';

		// Specific Tag IDs
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('widget_tag_ids') ) . '">' . esc_html__('Tag IDs: (Enter a comma separated List of Tag IDs)', 'tfm-theme-boost') . '</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr($this->get_field_id('widget_tag_ids')) . '" name="' . esc_attr($this->get_field_name('widget_tag_ids')) . '" value="' . esc_attr($tag_ids) . '">';
		$output .= '</p>';

		// Category ID
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('post_cat') ) . '">' . esc_html__('Category: (Can be used with Post Type)', 'tfm-theme-boost') . '</label>';
		$output .= '<select class="widefat" id="' . esc_attr($this->get_field_id('post_cat')) . '" name="' . esc_attr($this->get_field_name('post_cat')) . '">';
		$output .= '<option></option>'; // Set a blank option if selected we'll just display the latest posts

		// Category selection
		$categories = get_categories('type=post');
		foreach($categories as $category) {
			if ($category->term_id == $post_cat) {
			$output .= '<option selected="selected" value="' . $category->term_id . '">' . $category->cat_name . '</option>';
			} else {
				$output .= '<option value="' . $category->term_id . '">' . $category->cat_name . '</option>';
			}
		}
		$output .= '</select>';
		$output .= '</p>';

		// Sort Order
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('sort_order') ) . '">' . esc_html__('Sort Order:', 'tfm-theme-boost') . '</label>';
		$output .= '<select class="widefat" id="' . esc_attr($this->get_field_id('sort_order')) . '" name="' . esc_attr($this->get_field_name('sort_order')) . '">';
		$output .= '<option ' . selected( $sort_order, 'desc', false ) . ' value="desc">' . esc_html__('Newest to Oldest', 'tfm-theme-boost') . '</option>';
		$output .= '<option ' . selected( $sort_order, 'asc', false ) . ' value="asc">' . esc_html__('Oldest to Newest', 'tfm-theme-boost') . '</option>';
		$output .= '</select>';
		$output .= '</p>';

		// Author IDs
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('author') ) . '">' . esc_html__('Author: (Enter a comma seperated list of author IDs)', 'tfm-theme-boost') . '</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr($this->get_field_id('author')) . '" name="' . esc_attr($this->get_field_name('author')) . '" value="' . esc_attr($author) . '">';
		$output .= '</p>';

		// Offset
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('offset') ) . '">' . esc_html__('Offset: (Number of posts to skip)', 'tfm-theme-boost') . '</label>';
		$output .= '<input type="number" min="0" class="widefat" id="' . esc_attr($this->get_field_id('offset')) . '" name="' . esc_attr($this->get_field_name('offset')) . '" value="' . esc_attr($offset) . '">';
		$output .= '</p>';

		// Exclude post IDs
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('widget_exclude_post_ids') ) . '">' . esc_html__('Exclude Post IDs: (Enter a comma separated List of post IDs to Exclude)', 'tfm-theme-boost') . '</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr($this->get_field_id('widget_exclude_post_ids')) . '" name="' . esc_attr($this->get_field_name('widget_exclude_post_ids')) . '" value="' . esc_attr($exclude_post_ids) . '">';
		$output .= '</p>';

		// Layout
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('layout') ) . '">' . esc_html__('Layout:', 'tfm-theme-boost') . '</label>';
		$output .= '<select class="widefat" id="' . esc_attr($this->get_field_id('layout')) . '" name="' . esc_attr($this->get_field_name('layout')) . '">';
		$output .= '<option ' . selected( $layout, 'list', false ) . ' value="list">' . esc_html__('List', 'tfm-theme-boost') . '</option>';
		$output .= '<option ' . selected( $layout, 'list-first-grid', false ) . ' value="list-first-grid">' . esc_html__('List First Grid', 'tfm-theme-boost') . '</option>';
		$output .= '<option ' . selected( $layout, 'grid', false ) . ' value="grid">' . esc_html__('Grid', 'tfm-theme-boost') . '</option>';
		$output .= '</select>';
		$output .= '</p>';

		// Style
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('post_style') ) . '">' . esc_html__('Post Style:', 'tfm-theme-boost') . '</label>';
		$output .= '<select class="widefat" id="' . esc_attr($this->get_field_id('post_style')) . '" name="' . esc_attr($this->get_field_name('post_style')) . '">';
		$output .= '<option ' . selected( $post_style, 'default', false ) . ' value="default">' . esc_html__('Default', 'tfm-theme-boost') . '</option>';
		$output .= '<option ' . selected( $post_style, 'cover', false ) . ' value="cover">' . esc_html__('Cover', 'tfm-theme-boost') . '</option>';
		$output .= '</select>';
		$output .= '</p>';

		// Show thumbnail
		$output .= '<p>';
		$output .= '<input type="checkbox" class="checkbox" ' . checked( $thumbnail, 1, false ) . ' id="' . esc_attr($this->get_field_id('thumbnail')) . '" name="' . esc_attr($this->get_field_name('thumbnail')) . '">';
		$output .= '<label for="' . esc_attr($this->get_field_id('thumbnail') ) . '">' . esc_html__('Thumbnail', 'tfm-theme-boost') . '</label>';
		$output .= '</p>';

		// Thumbnail Size (aspect ratio)
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('thumbnail_size') ) . '">' . esc_html__('Thumbnail Size:', 'tfm-theme-boost') . '</label>';
		$output .= '<select class="widefat" id="' . esc_attr($this->get_field_id('thumbnail_size')) . '" name="' . esc_attr($this->get_field_name('thumbnail_size')) . '">';
		$output .= '<option ' . selected( $thumbnail_size, 'landscape', false ) . ' value="landscape">' . esc_html__('Landscape', 'tfm-theme-boost') . '</option>';
		$output .= '<option ' . selected( $thumbnail_size, 'wide', false ) . ' value="wide">' . esc_html__('Wide', 'tfm-theme-boost') . '</option>';
		$output .= '<option ' . selected( $thumbnail_size, 'square', false ) . ' value="square">' . esc_html__('Square', 'tfm-theme-boost') . '</option>';
		$output .= '<option ' . selected( $thumbnail_size, 'portrait', false ) . ' value="portrait">' . esc_html__('Portrait', 'tfm-theme-boost') . '</option>';
		$output .= '</select>';
		$output .= '</p>';

		// Round thumbs
		$output .= '<p>';
		$output .= '<input type="checkbox" class="checkbox" ' . checked( $round_thumbnails, 1, false ) . ' id="' . esc_attr($this->get_field_id('round_thumbnails')) . '" name="' . esc_attr($this->get_field_name('round_thumbnails')) . '">';
		$output .= '<label for="' . esc_attr($this->get_field_id('round_thumbnails') ) . '">' . esc_html__('Round Thumbnails', 'tfm-theme-boost') . '</label>';
		$output .= '</p>';

		// By
		$output .= '<p>';
		$output .= '<input type="checkbox" class="checkbox" ' . checked( $by, 1, false ) . ' id="' . esc_attr($this->get_field_id('by')) . '" name="' . esc_attr($this->get_field_name('by')) . '">';
		$output .= '<label for="' . esc_attr($this->get_field_id('by') ) . '">' . esc_html__('"by"', 'tfm-theme-boost') . '</label>';
		$output .= '</p>';

		if ( apply_filters( 'tfm_posts_widget_theme_supports_avatar', true )):

			// Avatar
			$output .= '<p>';
			$output .= '<input type="checkbox" class="checkbox" ' . checked( $avatar, 1, false ) . ' id="' . esc_attr($this->get_field_id('avatar')) . '" name="' . esc_attr($this->get_field_name('avatar')) . '">';
			$output .= '<label for="' . esc_attr($this->get_field_id('avatar') ) . '">' . esc_html__('Avatar', 'tfm-theme-boost') . '</label>';
			$output .= '</p>';
			
		endif;

		// Show author meta
		$output .= '<p>';
		$output .= '<input type="checkbox" class="checkbox" ' . checked( $author_meta, 1, false ) . ' id="' . esc_attr($this->get_field_id('author_meta')) . '" name="' . esc_attr($this->get_field_name('author_meta')) . '">';
		$output .= '<label for="' . esc_attr($this->get_field_id('author_meta') ) . '">' . esc_html__('Author', 'tfm-theme-boost') . '</label>';
		$output .= '</p>';

		// In
		$output .= '<p>';
		$output .= '<input type="checkbox" class="checkbox" ' . checked( $in, 1, false ) . ' id="' . esc_attr($this->get_field_id('in')) . '" name="' . esc_attr($this->get_field_name('in')) . '">';
		$output .= '<label for="' . esc_attr($this->get_field_id('in') ) . '">' . esc_html__('"in"', 'tfm-theme-boost') . '</label>';
		$output .= '</p>';

		// Show category meta
		$output .= '<p>';
		$output .= '<input type="checkbox" class="checkbox" ' . checked( $category_meta, 1, false ) . ' id="' . esc_attr($this->get_field_id('category_meta')) . '" name="' . esc_attr($this->get_field_name('category_meta')) . '">';
		$output .= '<label for="' . esc_attr($this->get_field_id('category_meta') ) . '">' . esc_html__('Category', 'tfm-theme-boost') . '</label>';
		$output .= '</p>';

		// Show date meta
		$output .= '<p>';
		$output .= '<input type="checkbox" class="checkbox" ' . checked( $date_meta, 1, false ) . ' id="' . esc_attr($this->get_field_id('date_meta')) . '" name="' . esc_attr($this->get_field_name('date_meta')) . '">';
		$output .= '<label for="' . esc_attr($this->get_field_id('date_meta') ) . '">' . esc_html__('Date', 'tfm-theme-boost') . '</label>';
		$output .= '</p>';

		// Show comment count
		$output .= '<p>';
		$output .= '<input type="checkbox" class="checkbox" ' . checked( $comment_count, 1, false ) . ' id="' . esc_attr($this->get_field_id('comment_count')) . '" name="' . esc_attr($this->get_field_name('comment_count')) . '">';
		$output .= '<label for="' . esc_attr($this->get_field_id('comment_count') ) . '">' . esc_html__('Comment Count', 'tfm-theme-boost') . '</label>';
		$output .= '</p>';

		// Read time requires theme boost plugin
		if ( function_exists( 'tfm_read_time' ) ) :

			$read_time = (isset($instance['read_time']) ? (bool) $instance['read_time'] : false);

			$output .= '<p>';
			$output .= '<input type="checkbox" class="checkbox" ' . checked( $read_time, 1, false ) . ' id="' . esc_attr($this->get_field_id('read_time')) . '" name="' . esc_attr($this->get_field_name('read_time')) . '">';
			$output .= '<label for="' . esc_attr($this->get_field_id('read_time') ) . '">' . esc_html__('Read Time', 'tfm-theme-boost') . '</label>';
			$output .= '</p>';

		endif;

		// Show count
		$output .= '<p>';
		$output .= '<input type="checkbox" class="checkbox" ' . checked( $post_count, 1, false ) . ' id="' . esc_attr($this->get_field_id('post_count')) . '" name="' . esc_attr($this->get_field_name('post_count')) . '">';
		$output .= '<label for="' . esc_attr($this->get_field_id('post_count') ) . '">' . esc_html__('Post Count', 'tfm-theme-boost') . '</label>';
		$output .= '</p>';

		// TFM Ratings
		if ( function_exists('tfm_ratings') ):

			// Stars
			$tfm_star_rating = (isset($instance['tfm_star_rating']) ? (bool) $instance['tfm_star_rating'] : false);

			$output .= '<p style="font-weight:bold">' . esc_html__( 'Ratings', 'tfm-theme-boost' ) . '</p>';

			$output .= '<input type="checkbox" class="checkbox" ' . checked( $tfm_star_rating, 1, false ) . ' id="' . esc_attr($this->get_field_id('tfm_star_rating')) . '" name="' . esc_attr($this->get_field_name('tfm_star_rating')) . '">';
			$output .= '<label for="' . esc_attr($this->get_field_id('tfm_star_rating') ) . '">' . esc_html__('Star Rating', 'tfm-theme-boost') . '</label>';
			$output .= '</p>';

			// Scale
			$tfm_scale_rating = (isset($instance['tfm_scale_rating']) ? (bool) $instance['tfm_scale_rating'] : false);

			$output .= '<p>';
			$output .= '<input type="checkbox" class="checkbox" ' . checked( $tfm_scale_rating, 1, false ) . ' id="' . esc_attr($this->get_field_id('tfm_scale_rating')) . '" name="' . esc_attr($this->get_field_name('tfm_scale_rating')) . '">';
			$output .= '<label for="' . esc_attr($this->get_field_id('tfm_scale_rating') ) . '">' . esc_html__('Scale Rating', 'tfm-theme-boost') . '</label>';
			$output .= '</p>';

			// Points
			$tfm_points_rating = (isset($instance['tfm_points_rating']) ? (bool) $instance['tfm_points_rating'] : false);

			$output .= '<p>';
			$output .= '<input type="checkbox" class="checkbox" ' . checked( $tfm_points_rating, 1, false ) . ' id="' . esc_attr($this->get_field_id('tfm_points_rating')) . '" name="' . esc_attr($this->get_field_name('tfm_points_rating')) . '">';
			$output .= '<label for="' . esc_attr($this->get_field_id('tfm_points_rating') ) . '">' . esc_html__('Points Rating', 'tfm-theme-boost') . '</label>';
			$output .= '</p>';

			// Percent
			$tfm_percent_rating = (isset($instance['tfm_percent_rating']) ? (bool) $instance['tfm_percent_rating'] : false);

			$output .= '<p>';
			$output .= '<input type="checkbox" class="checkbox" ' . checked( $tfm_percent_rating, 1, false ) . ' id="' . esc_attr($this->get_field_id('tfm_percent_rating')) . '" name="' . esc_attr($this->get_field_name('tfm_percent_rating')) . '">';
			$output .= '<label for="' . esc_attr($this->get_field_id('tfm_percent_rating') ) . '">' . esc_html__('Percent Rating', 'tfm-theme-boost') . '</label>';
			$output .= '</p>';

		endif;

		// Escape the output
		$allowed_html = array(
			'p' => array(
				'style' => array(),
			),
			'label' => array(
				'for' => array(),
			),
			'input' => array(
				'type' => array(),
				'class' => array(),
				'id' => array(),
				'name' => array(),
				'value' => array(),
				'min' => array(),
				'checked' => array(),
			),
			'select' => array(
				'class' => array(),
				'id' => array(),
				'name' => array(),
			),
			'option' => array(
				'value' => array(),
				'selected' => array(),
			),
			'button' => array(
				'class' => array(),
				'id' => array(),
				'name' => array(),
			),
		);

		echo wp_kses( $output, $allowed_html );

	}

	// Update Widget

	public function update($new_instance, $old_instance) {

		$instance = array();
		$instance['title'] = (!empty($new_instance['title']) ? strip_tags($new_instance['title']) : '');
		$instance['subtitle'] = (!empty($new_instance['subtitle']) ? strip_tags($new_instance['subtitle']) : '');
		$instance['number'] = (!empty($new_instance['number']) ? absint(strip_tags($new_instance['number'])) : 4);
		$instance['cols'] = (!empty($new_instance['cols']) ? absint(strip_tags($new_instance['cols'])) : 1);
		$instance['offset'] = (!empty($new_instance['offset']) ? absint(strip_tags($new_instance['offset'])) : 0);
		$instance['post_type'] = (!empty($new_instance['post_type']) ? strip_tags($new_instance['post_type']) : 'recent');
		$instance['widget_post_ids'] = (!empty($new_instance['widget_post_ids']) ? strip_tags($new_instance['widget_post_ids']) : '');
		$instance['widget_tag_ids'] = (!empty($new_instance['widget_tag_ids']) ? strip_tags($new_instance['widget_tag_ids']) : '');
		$instance['widget_exclude_post_ids'] = (!empty($new_instance['widget_exclude_post_ids']) ? strip_tags($new_instance['widget_exclude_post_ids']) : '');
		$instance['post_cat'] = (!empty($new_instance['post_cat']) ? strip_tags($new_instance['post_cat']) : '');
		$instance['sort_order'] = (!empty($new_instance['sort_order']) ? strip_tags($new_instance['sort_order']) : 'desc');
		$instance['author'] = (!empty($new_instance['author']) ? strip_tags($new_instance['author']) : '');
		$instance['layout'] = (!empty($new_instance['layout']) ? strip_tags($new_instance['layout']) : '');
		$instance['post_style'] = (!empty($new_instance['post_style']) ? strip_tags($new_instance['post_style']) : '');
		$instance['thumbnail'] = (isset( $new_instance['thumbnail'] ) ? (bool) $new_instance['thumbnail'] : false);
		$instance['thumbnail_size'] = (!empty($new_instance['thumbnail_size']) ? strip_tags($new_instance['thumbnail_size']) : '');
		$instance['round_thumbnails'] = (isset( $new_instance['round_thumbnails'] ) ? (bool) $new_instance['round_thumbnails'] : false);
		$instance['by'] = (isset( $new_instance['by'] ) ? (bool) $new_instance['by'] : false);
		$instance['avatar'] = (isset( $new_instance['avatar'] ) ? (bool) $new_instance['avatar'] : false);
		$instance['author_meta'] = (isset( $new_instance['author_meta'] ) ? (bool) $new_instance['author_meta'] : false);
		$instance['in'] = (isset( $new_instance['in'] ) ? (bool) $new_instance['in'] : false);
		$instance['category_meta'] = (isset( $new_instance['category_meta'] ) ? (bool) $new_instance['category_meta'] : false);
		$instance['date_meta'] = (isset( $new_instance['date_meta'] ) ? (bool) $new_instance['date_meta'] : false);
		$instance['comment_count'] = (isset( $new_instance['comment_count'] ) ? (bool) $new_instance['comment_count'] : false);
		$instance['read_time'] = (isset( $new_instance['read_time'] ) ? (bool) $new_instance['read_time'] : false);
		$instance['post_count'] = (isset( $new_instance['post_count'] ) ? (bool) $new_instance['post_count'] : false);

		$instance['tfm_star_rating'] = (isset( $new_instance['tfm_star_rating'] ) ? (bool) $new_instance['tfm_star_rating'] : false);
		$instance['tfm_scale_rating'] = (isset( $new_instance['tfm_scale_rating'] ) ? (bool) $new_instance['tfm_scale_rating'] : false);
		$instance['tfm_points_rating'] = (isset( $new_instance['tfm_points_rating'] ) ? (bool) $new_instance['tfm_points_rating'] : false);
		$instance['tfm_percent_rating'] = (isset( $new_instance['tfm_percent_rating'] ) ? (bool) $new_instance['tfm_percent_rating'] : false);

		return $instance;

	}

	// ========================================================
	// FRONTEND OUTPUT
	// ========================================================

	public function widget($args, $instance) {

		global $post;

		/* Copy vars from form() function Default variables */

		$title = (!empty($instance['title']) ? $instance['title'] : '');
		$subtitle = (!empty($instance['subtitle']) ? $instance['subtitle'] : '');
		$number = (!empty($instance['number']) ? absint($instance['number'] ) : 4);
		$cols = (!empty($instance['cols']) ? absint($instance['cols'] ) : 1);
		$offset = (!empty($instance['offset']) ? absint($instance['offset'] ) : 0);
		$post_type = (!empty($instance['post_type']) ? $instance['post_type'] : 'recent');
		$post_ids = (!empty($instance['widget_post_ids']) ? $instance['widget_post_ids'] : '');
		$tag_ids = (!empty($instance['widget_tag_ids']) ? $instance['widget_tag_ids'] : '');
		$exclude_post_ids = (!empty($instance['widget_exclude_post_ids']) ? $instance['widget_exclude_post_ids'] : '');
		$post_cat = (!empty($instance['post_cat']) ? $instance['post_cat'] : '');
		$sort_order = (!empty($instance['sort_order']) ? $instance['sort_order'] : 'desc');
		$author = (!empty($instance['author']) ? $instance['author'] : '');
		$layout = (!empty($instance['layout']) ? $instance['layout'] : 'list');
		$post_style = (!empty($instance['post_style']) ? $instance['post_style'] : 'default');
		$thumbnail = (isset($instance['thumbnail']) ? (bool) $instance['thumbnail'] : false);
		$thumbnail_size = (!empty($instance['thumbnail_size']) ? $instance['thumbnail_size'] : 'landscape');
		$round_thumbnails = (isset($instance['round_thumbnails']) ? (bool) $instance['round_thumbnails'] : false);
		$by = (isset($instance['by']) ? (bool) $instance['by'] : false);
		$avatar = (isset($instance['avatar']) ? (bool) $instance['avatar'] : false);
		$author_meta = (isset($instance['author_meta']) ? (bool) $instance['author_meta'] : false);
		$in = (isset($instance['in']) ? (bool) $instance['in'] : false);
		$category_meta = (isset($instance['category_meta']) ? (bool) $instance['category_meta'] : false);
		$date_meta = (isset($instance['date_meta']) ? (bool) $instance['date_meta'] : false);
		$comment_count = (isset($instance['comment_count']) ? (bool) $instance['comment_count'] : false);
		$read_time = (isset( $instance['read_time'] ) ? (bool) $instance['read_time'] : false);
		$post_count = (isset($instance['post_count']) ? (bool) $instance['post_count'] : false);

		$tfm_star_rating = (isset( $instance['tfm_star_rating'] ) ? (bool) $instance['tfm_star_rating'] : false);
		$tfm_scale_rating = (isset( $instance['tfm_scale_rating'] ) ? (bool) $instance['tfm_scale_rating'] : false);
		$tfm_points_rating = (isset( $instance['tfm_points_rating'] ) ? (bool) $instance['tfm_points_rating'] : false);
		$tfm_percent_rating = (isset( $instance['tfm_percent_rating'] ) ? (bool) $instance['tfm_percent_rating'] : false);

		// If related post return if not single
		if (( $post_type === 'related_category' || $post_type === 'related_tags'  || $post_type === 'related_author' ) && ! is_single() ) {
			return;
		}

		// ========================================================
		// DATABASE QUERIES
		// ========================================================

		$post_num = ( !empty($number) ? absint($number) : 4 );
		$post_offset = ( !empty($offset ) ? absint($offset) : 0 );
		$order_by = ( $post_type === 'popular' ? 'comment_count' : '');
		if ( $post_type === 'random' ) {
			$order_by = 'rand';
		}
		$post_cat_in = ( !empty($post_cat) ? $post_cat : '' );
		$post_in = ( $post_type === 'post_ids' && '' !== $post_ids ? $post_ids : '' );
		$tag_in = ( '' !== $tag_ids ? $tag_ids : '' );
		if ( '' !== $tag_in ) {
			$tag_in = explode(',', $tag_in );
		}
		$post_not_in = ( $post_type !== 'post_ids' && '' !== $exclude_post_ids ? $exclude_post_ids : '' );
		if ( '' !== $post_not_in ) {
			$post_not_in = explode(',', $post_not_in );
		}
		$post_sort_order = ( !empty($sort_order) ? $sort_order : 'desc' );

		if ( '' !== $post_in ) {

			// Specific posts create an array
			$post_in = explode(',', $post_in );

			$query_args = array(
			    'posts_per_page' => $post_num,
			    'post__in' => $post_in,
			    'ignore_sticky_posts' => 1,
			    'orderby' => 'post__in',
			    'order' => '' . $post_sort_order . '',
			);

		} elseif ( $post_type === 'related_category' ) {

			$category = get_the_category($post->ID);
			$cat_ids = array();
			foreach($category as $post_cat) {
				$cat_ids[] = $post_cat->cat_ID;
			}

			$query_args = array(
				'post__not_in' => array($post->ID),
			    'post_type'      => 'post',
			    'posts_per_page' => $post_num,
			    'cat' => $cat_ids,
			    'orderby' => 'rand',
				);

		} elseif ( $post_type === 'related_author' ) {

			$query_args = array(
			'post__not_in' => array($post->ID),
		    'post_type'      => 'post',
		    'posts_per_page' => $post_num,
		    'author' => get_the_author_meta( 'ID'),
		    'orderby' => 'rand',
			);

		} elseif ( $post_type === 'related_tags' ) {

			// Tags relationship method
			$tags = wp_get_post_tags($post->ID);
			$post_tag_ids = array();
			foreach( $tags as $post_tag ) { 
				$post_tag_ids[] = $post_tag->term_id;
			}

			$query_args = array(
			'post__not_in' => array($post->ID),
		    'post_type'      => 'post',
		    'posts_per_page' => $post_num,
		    'tag__in' => $post_tag_ids,
		    'orderby' => 'rand',
			);

		} else {

			if ( '' !== $author ) {

				// Array of authors
				$author = explode(',', $author );

			}

			$query_args = array(
			    'posts_per_page' => $post_num,
			    'offset' => $post_offset, // Offset
				'cat' => $post_cat, // If we are diplaying posts from a category
				'tag__in' => $tag_in,
				'author__in' => $author,
			    'ignore_sticky_posts' => 1,
			    'orderby' => $order_by, // If we are displaying popular posts
			    'order' => '' . $post_sort_order . '',
			    'post__not_in' => $post_not_in,
			    'post_status' => array(      
					'publish',          // A published post or page.
					),
			);

		}

		$posts_query = new WP_Query($query_args);

		// ========================================================
		// END 
		// ========================================================

		// ========================================================
		// FRONT-END TEMPLATE
		// ========================================================

		// Loop variables

		$thumbnails = ( $thumbnail ? ' has-post-thumbnails' : '' );
		$round_thumbs = ( $round_thumbnails ? ' round-thumbnails' : '' );
		$thumb_type = ( $layout === 'grid' ? 'medium' : 'thumbnail' );
		$show_post_count = ( $post_count ? ' show-post-count' : '' );
		$ul_ol = ( $post_count ? 'ol' : 'ul' );
		$has_read_time = ( $read_time ? ' has-read-time' : '' );
		$has_comment_count =  ( $comment_count ? ' has-comment-count' : '' );
		$has_meta_before_title = ( $category_meta ? ' has-category-meta' : '' );
		$has_title = ( $title ? ' has-title' : '' );
		$has_subtitle = ( $subtitle ? ' has-subtitle' : '' );
		$has_avatar = ( $avatar ? ' has-avatar' : '' );
		$has_author = ( $author_meta ? ' has-author' : '' );
		$has_date = ( $date_meta ? ' has-date' : '' );
		$cols_class = ( !empty($cols) ? ' cols-' . absint($cols) : '' );

		$has_rating = ( $tfm_star_rating || $tfm_points_rating || $tfm_percent_rating || $tfm_scale_rating  ? ' has-rating' : '' );

		// Count the list items for after title meta
		$after_title_list_items = array( $has_avatar, $has_author, $has_date, $has_comment_count, $has_read_time );
		$after_title_list_item_count = array_filter($after_title_list_items);
		$meta_item_count = count($after_title_list_item_count);
		$meta_item_count_class = $meta_item_count !== 0 ? ' meta-items-' . $meta_item_count : '';

		// Escape the output
		$allowed_html = array(
			'section' => array(
				'class' => array(),
				'id'  => array(),
			),
			'h3' => array(
				'class' => array(),
			),
			'h2' => array(
				'class' => array(),
			),
			'p' => array(),
			'strong' => array(),
			'b' => array(),
			'a' => array(),
			'em' => array(),
		);

		echo wp_kses_post( $args['before_widget'] );

		if ( ! empty( $instance[ 'title' ]) ) :

			// Check for author var and output the author name
			if ( strpos($instance[ 'title' ], '%author%')) {
				$instance[ 'title' ] = str_replace('%author%', '', $instance[ 'title' ]);
				if ( is_single() ) {
					$instance[ 'title' ] = $instance[ 'title' ] . get_the_author();
				}
			}

			echo wp_kses_post( $args['before_title']) . apply_filters( 'widget_title', $instance['title'] ) . wp_kses_post( $args['after_title'] );

		endif;

		if ( !empty( $instance[ 'subtitle' ]) ) :

			// Check for author var and output the author name
			if ( strpos($instance[ 'subtitle' ], '%author%') ) {
				$instance[ 'subtitle' ] = str_replace('%author%', '', $instance[ 'subtitle' ]);
				if ( is_single() ) {
					$instance[ 'subtitle' ] = $instance[ 'subtitle' ] . '<span>' . get_the_author() . '</span>';
				}
			}

			echo '<p class="widget-subtitle">' . wp_kses_post( $instance[ 'subtitle' ] ) . '</p>';

		endif;

		if ( $posts_query->have_posts()):

			$count = 0;

			echo '<' . $ul_ol . ' class="list list-style-' . esc_attr( $layout ) . esc_attr( $thumbnails . $has_read_time . $has_comment_count . $has_meta_before_title . $has_title . $has_subtitle . $has_avatar . $has_author . $has_date . $round_thumbs . $has_rating ) . esc_attr( $show_post_count ) . ' ' . esc_attr( $post_type ) . '-posts">';

			while ($posts_query->have_posts()) : $posts_query->the_post();

				$count++; ?>

				<?php

				$has_thumbnail = ( has_post_thumbnail() && $thumbnail ? ' has-post-media has-post-thumbnail ' : '' );
				$first_grid = ( $layout === 'list-first-grid' && $count === 1 ? ' first-grid' : '' );
				$style = ( $post_style === 'cover' && $has_thumbnail && ( $layout === 'grid' || ( $layout === 'list-first-grid' && $first_grid ) ) ? ' cover' : ' default' );
				$thumb_size = ( $has_thumbnail && ( $layout === 'grid' || ( $layout === 'list-first-grid' && $first_grid ) ) ? 'thumbnail-' . $thumbnail_size : ' thumbnail-uncropped' );
				$has_category_meta = ( $category_meta ? ' has-category-meta' : '' );
				$category_slug = array_slice( get_the_category(), 0, 1 ); // Only display a single category slug
				$i = 0;

				?>

				<li class="widget-entry<?php echo esc_attr( $has_thumbnail . $thumb_size . $first_grid . $has_category_meta . $meta_item_count_class . $style ); ?>">

					<?php if ( $thumbnail && has_post_thumbnail() ) : ?>

						<div class="post-thumbnail">
							<a href="<?php the_permalink(); ?>">
								<?php
								// Check for list first grid
								if ( ( $layout === 'list-first-grid' && $count === 1 ) || ( !empty($cols) && $layout === 'grid' )) {
									the_post_thumbnail( 'medium_large' );
								} else {
									the_post_thumbnail( $thumb_type );
								} ?>
							</a>
						</div>

					<?php endif ?>

						<div class="entry-header">

	    		<?php if ( $category_meta ) : ?>

	    		<div class="entry-meta before-title">
					<ul class="post-categories-meta">

						 <?php 

						 	foreach($category_slug as $the_category) {

							 	$i++;

								echo '<li class="cat-slug-' . esc_attr( $the_category->slug ) . ' cat-id-' . esc_attr( $the_category->cat_ID ) . '">';

								// count fallback in case cat slugs is more than one
								if ( $i === 1 && $in ) {
									echo '<span class="screen-reader-text">' . esc_html__('Posted in', 'tfm-theme-boost' ) . '</span><i dir="ltr">' . esc_html__('in', 'tfm-theme-boost' ) . '</i> ';
								}

								echo '<a href="' . get_category_link( $the_category->cat_ID ) . '" class="cat-link-' . esc_attr( $the_category->cat_ID ) . '">' . esc_html( $the_category->cat_name ) . '</a></li>';

							} ?>
					</ul>

				</div>

			<?php endif; ?>

	    		<?php the_title( '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark" class="entry-title-link">', '</a>' ); ?>

	    		<?php if ( $date_meta || $read_time || $comment_count|| $author_meta || $avatar ) : ?>

	    			<?php // Close entry header if we have more than one entry meta item

	    				if ( $meta_item_count > apply_filters( 'tfm_posts_widget_meta_item_count_max', 1 ) && $has_thumbnail ): ?>

		    			</div>

		    		<?php endif; ?>

	    		<div class="entry-meta after-title<?php echo esc_attr( $meta_item_count_class); ?>">

	    			<ul class="after-title-meta">

	    				<?php if ( $avatar ): ?>

							<li class="entry-meta-avatar"><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) ?>"><?php echo get_avatar( get_the_author_meta('ID'), 30 ); ?></a></li>

						<?php endif; ?>

	    				<?php if ( $author_meta ): ?>

							<li class="entry-meta-author"><span class="screen-reader-text">Posted</span><?php if ( $instance[ 'by' ] ): ?><i dir="ltr"><?php echo esc_html__('by', 'tfm-theme-boost' ); ?></i><?php endif; ?> <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) ?>"><?php echo get_the_author() ?></a></li>

						<?php endif; ?>

	    				<?php if ( $date_meta ): ?>

							<li class="entry-meta-date">
								
								<time datetime="<?php echo get_the_date( 'Y-m-d' ) ?>">

									<?php if ( function_exists( 'ruki_human_entry_date' ) && get_theme_mod( 'ruki_human_entry_date', false ) ) : ?>

										<?php echo ruki_human_entry_date() ?>

									<?php else : ?>

										<?php the_time( get_option( 'date_format' ) ); ?>

									<?php endif; ?>

								</time>
								
							</li>

						<?php endif; ?>

						<?php if ( $comment_count ): ?>

							<li class="entry-meta-comment-count"><?php echo get_comments_number() ?> <span><?php comments_number( __('Comments', 'tfm-theme-boost'), __('Comment', 'tfm-theme-boost'), __('Comments', 'tfm-theme-boost') ) ?></span></li>

						<?php endif;  ?>

						<?php

						// Read time requires theme boost plugin
						if ( function_exists( 'tfm_read_time' ) && $read_time ): ?>

							<?php echo tfm_read_time( true); ?>

						<?php endif;  ?>

					</ul>
					
				</div>

			<?php endif; ?>

				<?php

				// TFM star rating (tfm theme boost)

				if ( function_exists( 'tfm_ratings' ) && ( $tfm_star_rating || $tfm_points_rating || $tfm_percent_rating || $tfm_scale_rating ) ) {

					tfm_ratings( $tfm_star_rating, $tfm_points_rating, $tfm_percent_rating, $tfm_scale_rating, true ); // $star_rating, $points_rating, $percent_rating, $scale_rating, $forced_request

				} ?>

			<?php 

			// Close entry header if we have thumbnail and multiple meta items

			if ( $meta_item_count < ( apply_filters( 'tfm_posts_widget_meta_item_count_max', 1 ) + 1 ) && $has_thumbnail ): ?>

				</div>

			<?php endif; ?>

			<?php // Close entry header if we have no thumbnail

			if ( ! $has_thumbnail ): ?>

				</div>

			<?php endif; ?>

	    	</li>

	        <?php endwhile;

        	echo '</' . $ul_ol . '>';

		endif; // End if posts

		echo wp_kses_post( $args['after_widget'] );

		// ========================================================
		// END
		// ========================================================

		wp_reset_postdata(); // Always reset
	}

} // End Class

// ========================================================
// Append customizer settings to theme colour settings
// ========================================================

function tfm_posts_widget_customizer_settings( $wp_customize ) {

	// Custom controls
	require_once 'inc/custom_controls.php';

	$sections = apply_filters( 'tfm_posts_widget_customizer_sections', array(
     	 'aside-sidebar' => tfm_get_theme_textdomain() . '_sidebar_widget_colors',
     	 'site-footer' => tfm_get_theme_textdomain() . '_footer_widget_colors',
         'toggle-sidebar' => tfm_get_theme_textdomain() . '_toggle_sidebar_widget_colors',
         'loop-sidebar' => tfm_get_theme_textdomain() . '_in_loop_widget_colors',
     ));

	if ( function_exists('tfm_home_blocks') && apply_filters( 'tfm_home_blocks_theme_supports_widgets', true ) ) {

		$blocks = tfm_get_home_blocks();

		$sections = $sections + $blocks;

	}

	foreach ($sections as $section => $value) {

		/**
		Separator
		**/
		$wp_customize->add_setting( $value . '_tfm_separator', array(
			'default'           => '',
			'sanitize_callback' => 'esc_html',
		));
		$wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, $value . '_tfm_separator', array(
			'settings'		=> $value . '_tfm_separator',
			'section'  		=> $value,
			'priority' => 100,
		)));

		$wp_customize->add_setting( $value . '_tfm_count_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $value . '_tfm_count_color', array(
	      'section' => $value,
	      'label'   => esc_html__( 'TFM: Posts Widget Count Color', 'tfm-theme-boost' ),
	      'priority' => 100,
	    ) ) );

	     // Add Setting
		$wp_customize->add_setting( $value . '_tfm_first_count_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $value . '_tfm_first_count_color', array(
	      'section' => $value,
	      'label'   => esc_html__( 'TFM: Posts Widget First Count Color', 'tfm-theme-boost' ),
	      'priority' => 100,
	    ) ) );

	    // Add Setting
		$wp_customize->add_setting( $value . '_tfm_alt_count_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $value . '_tfm_alt_count_color', array(
	      'section' => $value,
	      'label'   => esc_html__( 'TFM: Posts Widget alt. Count Color', 'tfm-theme-boost' ),
	      'priority' => 100,
	    ) ) );

	    // Add Setting
		$wp_customize->add_setting( $value . '_tfm_alt_count_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $value . '_tfm_alt_count_background', array(
	      'section' => $value,
	      'label'   => esc_html__( 'TFM: Posts Widget alt. Count Background', 'tfm-theme-boost' ),
	      'priority' => 100,
	    ) ) );

	    // Removed 1.1.1
		// $wp_customize->add_setting( $value . '_tfm_alt_count_border_color', array(
		// 	'default'           => '',
		// 	'transport' => 'refresh',
		// 	'sanitize_callback' => 'sanitize_hex_color',
		// ) );

		
		// $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $value . '_tfm_alt_count_border_color', array(
	 //      'section' => $value,
	 //      'label'   => esc_html__( 'TFM: Posts Widget alt. Count Border Color', 'tfm-theme-boost' ),
	 //      'priority' => 100,
	 //    ) ) );

	    // Add Setting
		$wp_customize->add_setting( $value . '_tfm_first_alt_count_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $value . '_tfm_first_alt_count_color', array(
	      'section' => $value,
	      'label'   => esc_html__( 'TFM: Posts Widget alt. First Count Color', 'tfm-theme-boost' ),
	      'priority' => 100,
	    ) ) );

	    // Add Setting
		$wp_customize->add_setting( $value . '_tfm_first_alt_count_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $value . '_tfm_first_alt_count_background', array(
	      'section' => $value,
	      'label'   => esc_html__( 'TFM: Posts Widget alt. First Count Background', 'tfm-theme-boost' ),
	      'priority' => 100,
	    ) ) );

	    // Ratings (tfm theme boost)

		if ( function_exists('tfm_ratings') ):

			// Add Setting
			$wp_customize->add_setting( $value . '_tfm_stars_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			// Control Options
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $value . '_tfm_stars_color', array(
		      'section' => $value,
		      'label'   => esc_html__( 'TFM: Posts Widget Stars Rating Color', 'tfm-theme-boost' ),
		      'priority' => 100,
		    ) ) );


		endif;


	}


}

add_action( 'customize_register', 'tfm_posts_widget_customizer_settings' );


// ========================================================
// Custom CSS
// ========================================================

function tfm_posts_widget_custom_css( ) {

	

	$sections = apply_filters( 'tfm_posts_widget_customizer_sections', array(
     	 'aside-sidebar' => tfm_get_theme_textdomain() . '_sidebar_widget_colors',
     	 'site-footer' => tfm_get_theme_textdomain() . '_footer_widget_colors',
         'toggle-sidebar' => tfm_get_theme_textdomain() . '_toggle_sidebar_widget_colors',
         'loop-sidebar' => tfm_get_theme_textdomain() . '_in_loop_widget_colors',
     ));

	if ( function_exists('tfm_home_blocks') && apply_filters( 'tfm_home_blocks_theme_supports_widgets', true ) ) {

		$blocks = tfm_get_home_blocks();

		$sections = $sections + $blocks;

	}

	foreach ($sections as $section => $value) {

		$custom_css[$value . '_tfm_count_color'] = ( '' !== get_theme_mod( $value . '_tfm_count_color', '' ) ? '.' . $section . ' .tfm_posts_widget ol.show-post-count:not(.has-post-thumbnails) > li.widget-entry::before { color:' . get_theme_mod( $value . '_tfm_count_color', '' ) . ';}' : '' );
		$custom_css[$value . '_tfm_first_count_color'] = ( '' !== get_theme_mod( $value . '_tfm_first_count_color', '' ) ? '.' . $section . ' .tfm_posts_widget ol.show-post-count:not(.has-post-thumbnails) > li.widget-entry:first-child::before { color:' . get_theme_mod( $value . '_tfm_first_count_color', '' ) . ';}' : '' );
		$custom_css[$value . '_tfm_alt_count_color'] = ( '' !== get_theme_mod( $value . '_tfm_alt_count_color', '' ) ? '.' . $section . ' .tfm_posts_widget ol.show-post-count.has-post-thumbnails > li.widget-entry:not(:first-child)::before { color:' . get_theme_mod( $value . '_tfm_alt_count_color', '' ) . ';}' : '' );
		$custom_css[$value . '_tfm_alt_count_background'] = ( '' !== get_theme_mod( $value . '_tfm_alt_count_background', '' ) ? '.' . $section . ' .tfm_posts_widget ol.show-post-count.has-post-thumbnails > li.widget-entry:not(:first-child)::before { background:' . get_theme_mod( $value . '_tfm_alt_count_background', '' ) . ';}' : '' );
		$custom_css[$value . '_tfm_alt_count_border_color'] = ( '' !== get_theme_mod( $value . '_tfm_alt_count_border_color', '' ) ? '.' . $section . ' .tfm_posts_widget ol.show-post-count.has-post-thumbnails > li.widget-entry:not(:first-child)::before { border-color:' . get_theme_mod( $value . '_tfm_alt_count_border_color', '' ) . ';}' : '' );
		$custom_css[$value . '_tfm_first_alt_count_color'] = ( '' !== get_theme_mod( $value . '_tfm_first_alt_count_color', '' ) ? '.' . $section . ' .tfm_posts_widget ol.show-post-count.has-post-thumbnails > li.widget-entry:first-child::before { color:' . get_theme_mod( $value . '_tfm_first_alt_count_color', '' ) . ';}' : '' );
		$custom_css[$value . '_tfm_first_alt_count_background'] = ( '' !== get_theme_mod( $value . '_tfm_first_alt_count_background', '' ) ? '.' . $section . ' .tfm_posts_widget ol.show-post-count.has-post-thumbnails > li.widget-entry:first-child::before { background:' . get_theme_mod( $value . '_tfm_first_alt_count_background', '' ) . ';}' : '' );
		$custom_css[$value . '_tfm_first_alt_count_border_color'] = ( '' !== get_theme_mod( $value . '_tfm_first_alt_count_border_color', '' ) ? '.' . $section . ' .tfm_posts_widget ol.show-post-count.has-post-thumbnails > li.widget-entry:first-child::before { border-color:' . get_theme_mod( $value . '_tfm_first_alt_count_border_color', '' ) . ';}' : '' );
		$custom_css[$value . '_tfm_stars_color'] = ( '' !== get_theme_mod( $value . '_tfm_stars_color', '' ) ? '.' . $section . ' .tfm_posts_widget .tfm-rating-stars .star::before, .' . $section . ' .tfm_posts_widget .tfm-rating-stars .star:not(.none)::after  { color:' . get_theme_mod( $value . '_tfm_stars_color', '' ) . ';}' : '' );


	}

	$block_css = array_filter($custom_css);

	if ( count($block_css) !== 0 ) : ?>

<style type="text/css" id="tfm-posts-widget-custom-css">
<?php foreach ($block_css as $css ) {
	echo wp_strip_all_tags( $css ) . "\n";
} ?>
</style>
<?php endif;


}
add_action( 'wp_head', 'tfm_posts_widget_custom_css', 20 ); // Enqueue the CSS Inline Style after the main stylesheet

} // Endif function_exists( 'register_tfm_posts_widget')


?>