<?php
/**
 * Template part for displaying post format icons
 */

?>

<?php
// Formats key
if ( get_theme_mod( $block . '_post_format_icons', true ) || get_theme_mod( $block . '_post_count', false ) ) : ?>

	<div class="formats-key">

			<?php if ( has_post_format( 'gallery' )): ?>

				<span class="format-gallery"<?php echo wp_kses( $custom_color['format_icon_border'], $allowed_html ) ?>><i class="icon-picture-1"></i></span>

			<?php endif; ?>

			<?php if ( has_post_format( 'video' ) && ( ! get_theme_mod( $block . '_media', true ) || ( get_theme_mod( $block . '_media', true ) && ! tfm_home_blocks_featured_video( true ) ) ) ): ?>

				<span class="format-video"<?php echo wp_kses( $custom_color['format_icon_border'], $allowed_html ) ?>><i class="icon-video"></i></span>

			<?php endif; ?>

			<?php if ( has_post_format( 'audio' )): ?>

				<span class="format-audio"<?php echo wp_kses( $custom_color['format_icon_border'], $allowed_html ) ?>><i class="icon-headphones"></i></span>

			<?php endif; ?>

			<?php if ( get_theme_mod( $block . '_post_count', false ) ): ?>

			<span class="format-count post-count"<?php echo wp_kses( $custom_color['format_count_colors'], $allowed_html ) ?>><?php echo esc_html( $count ); ?></span>

		<?php endif; ?>

	</div>

<?php endif; ?>