<?php 

/**
 * Customizer Colour Options
 *
 * @package WordPress
 * @subpackage 3FortyMedia
 * @since 1.0
 * @version 1.2
 */

/**
 * Custom CSS Colors for home block widgets
 */

function tfm_home_blocks_widget_colors() {

	$home_blocks = tfm_home_blocks_active( true );

	if ( count($home_blocks) !== 0 ) {

		foreach ( $home_blocks as $block => $value ) {

			// ========================================================
			// Category Slug
			// ========================================================

			//  Override theme slug colour settings

			$custom_colors[$block . '_entry_meta_cat_link_color'] = ( '' !== get_theme_mod( $block . '_entry_meta_cat_link_color', '' ) ? '.' . $block . ' .entry-meta a[class*="cat-link"] { color: ' . get_theme_mod( $block . '_entry_meta_cat_link_color', '' ) . ';}' : '' );

			// ========================================================
			// Pseudo elements
			// ========================================================

			$custom_colors[$block . '_entry_meta_icon_color'] = ( '' !== get_theme_mod( $block . '_entry_meta_icon_color', '' ) ? '.' . $block . ' .entry-read-more .entry-meta-read-time::after { color: ' . get_theme_mod( $block . '_entry_meta_icon_color', '' ) . ' !important;}' : '' );
			$custom_colors[$block . '_continue_reading_button_color'] = ( '' !== get_theme_mod( $block . '_continue_reading_button_color', '' ) ? '.' . $block . ' .read-more::after { color: ' . get_theme_mod( $block . '_continue_reading_button_color', '' ) . ';}' : '' );

			// Button hover
			$custom_colors[$block . '_continue_reading_button_hover_background'] = ( '' !== get_theme_mod( $block . '_continue_reading_button_hover_background', '' ) ? '.' . $block . ' .read-more:hover { background: ' . get_theme_mod( $block . '_continue_reading_button_hover_background', '' ) . ' !important;}' : '' );

			$custom_colors[$block . '_continue_reading_button_hover_color'] = ( '' !== get_theme_mod( $block . '_continue_reading_button_hover_color', '' ) ? '.' . $block . ' .read-more:hover { color: ' . get_theme_mod( $block . '_continue_reading_button_hover_color', '' ) . ' !important;}' : '' );

			$custom_colors[$block . '_continue_reading_button_hover_color_after'] = ( '' !== get_theme_mod( $block . '_continue_reading_button_hover_color', '' ) ? '.' . $block . ' .read-more:hover::after { color: ' . get_theme_mod( $block . '_continue_reading_button_hover_color', '' ) . ';}' : '' );

			// Entry meta line colour
			$custom_colors[$block . '_entry_meta_border_color'] = ( '' !== get_theme_mod( $block . '_entry_meta_border_color', '' ) ? '.' . $block . ' .article .entry-read-more .entry-meta-read-time { border-color: ' . get_theme_mod( $block . '_entry_meta_border_color', '' ) . ';}' : '' );

			// Count

			$custom_colors[$block . '_count'] = ( ( '' !== get_theme_mod( $block . '_count_background', '' ) || '' !== get_theme_mod( $block . '_count_color', '' ) ) ? '.' . $block . ' .tfm-posts-block.has-post-count article::before { background: ' . get_theme_mod( $block . '_count_background', '' ) . '; color: ' . get_theme_mod( $block . '_count_color', '' ) . ';}' : '' );

			// Ratings
			$custom_colors[$block . '_tfm_ratings'] = ( '' !== get_theme_mod( $block . '_entry_title_color', '' ) ? '.' . $block . ' .tfm-ratings span[class*="tfm-rating"] { color: ' . get_theme_mod( $block . '_entry_title_color', '' ) . ';}' : '' );

			$custom_colors[$block . '_tfm_stars_color'] = ( '' !== get_theme_mod( $block . '_tfm_stars_color', '' ) ? '.' . $block . ' ' . ' .tfm-rating-stars .star::before, .' . $block . ' .tfm-rating-stars .star:not(.none)::after, .' . $block . '.woocommerce .star-rating { color: ' . get_theme_mod( $block . '_tfm_stars_color', '' ) . ';}' : '' );


			// ========================================================
			// Woocommerce Product buttons
			// ========================================================

			if ( 'recent_products' === get_theme_mod( $block . '_post_type', 'recent' ) || 'product_ids' === get_theme_mod( $block . '_post_type', 'recent' ) ) {

				$custom_colors[$block . '_tfm_product_button_background'] = ( '' !== get_theme_mod( $block . '_continue_reading_button_background', '' ) ? '.' . $block . ' ' . ' a.button.wp-element-button { background: ' . get_theme_mod( $block . '_continue_reading_button_background', '' ) . ';}' : '' );
				$custom_colors[$block . '_tfm_product_button_color'] = ( '' !== get_theme_mod( $block . '_continue_reading_button_color', '' ) ? '.' . $block . ' ' . ' a.button.wp-element-button { color: ' . get_theme_mod( $block . '_continue_reading_button_color', '' ) . ';}' : '' );
				$custom_colors[$block . '_tfm_product_button_hover_background'] = ( '' !== get_theme_mod( $block . '_continue_reading_button_hover_background', '' ) ? '.' . $block . ' ' . ' a.button.wp-element-button:hover { background: ' . get_theme_mod( $block . '_continue_reading_button_hover_background', '' ) . ';}' : '' );
				$custom_colors[$block . '_tfm_product_button_hover_color'] = ( '' !== get_theme_mod( $block . '_continue_reading_button_hover_color', '' ) ? '.' . $block . ' ' . ' a.button.wp-element-button:hover { color: ' . get_theme_mod( $block . '_continue_reading_button_hover_color', '' ) . ';}' : '' );

			}

			// ========================================================
			// Sidebar widgets
			// ========================================================

			if ( get_theme_mod( $block . '_sidebar', false ) ) {

				$custom_colors[$block . '_widget_background'] = ( '' !== get_theme_mod( $block . '_widget_background', '' ) ? '.' . $block . ' ' . '.tfm-post-block-sidebar.has-background > .widget, .' . $block . ' .tfm-post-block-sidebar.has-background .wp-block-column { background: ' . get_theme_mod( $block . '_widget_background', '' ) . ';}' : '' );

				$custom_colors[$block . '_widget_color'] = ( '' !== get_theme_mod( $block . '_widget_text_color', '' ) ? '.' . $block . ' ' . '.tfm-post-block-sidebar .widget, .' . $block . ' ' . '.tfm-post-block-sidebar .widget.widget_rss .rssSummary, .' . $block . ' ' . '.tfm-post-block-sidebar .widget .tfm-ratings span[class*="tfm-rating"] { color: ' . get_theme_mod( $block . '_widget_text_color', '' ) . ';}' : '' );

				$custom_colors[$block . '_widget_title_color'] = ( '' !== get_theme_mod( $block . '_widget_title_color', '' ) ? '.' . $block . ' ' . '.tfm-post-block-sidebar .widget .widget-title { color: ' . get_theme_mod( $block . '_widget_title_color', '' ) . ';}' : '' );

				$custom_colors[$block . '_widget_subtitle_color'] = ( '' !== get_theme_mod( $block . '_widget_subtitle_color', '' ) ? '.' . $block . ' ' . '.tfm-post-block-sidebar .widget .widget-subtitle { color: ' . get_theme_mod( $block . '_widget_subtitle_color', '' ) . ';}' : '' );

				$custom_colors[$block . '_widget_link_color'] = ( '' !== get_theme_mod( $block . '_widget_link_color', '' ) ? '.' . $block . ' ' . '.tfm-post-block-sidebar .widget a { color: ' . get_theme_mod( $block . '_widget_link_color', '' ) . ';}' : '' );

				$custom_colors[$block . '_widget_child_link_color'] = ( '' !== get_theme_mod( $block . '_widget_child_link_color', '' ) ? '.' . $block . ' ' . '.tfm-post-block-sidebar .widget ul.children li a { color: ' . get_theme_mod( $block . '_widget_child_link_color', '' ) . ';}' : '' );

				$custom_colors[$block . '_widget_meta_color'] = ( '' !== get_theme_mod( $block . '_widget_meta_color', '' ) ? '.' . $block . ' ' . '.tfm-post-block-sidebar .widget ul li, .' . $block . ' ' . '.tfm-post-block-sidebar .widget_rss cite, .' . $block . ' ' . '.tfm-post-block-sidebar .widget .wp-caption-text { color: ' . get_theme_mod( $block . '_widget_meta_color', '' ) . ';}' : '' );

				$custom_colors[$block . '_widget_meta_link_color'] = ( '' !== get_theme_mod( $block . '_widget_meta_link_color', '' ) ? '.' . $block . ' ' . '.tfm-post-block-sidebar .widget .entry-meta a, .' . $block . ' ' . '.tfm-post-block-sidebar .widget_recent_comments a.url { color: ' . get_theme_mod( $block . '_widget_meta_link_color', '' ) . ';}' : '' );

				$custom_colors[$block . '_widget_button_background'] = ( '' !== get_theme_mod( $block . '_widget_button_background', '' ) ? '.' . $block . ' ' . '.tfm-post-block-sidebar .widget button, .' . $block . ' ' . '.tfm-post-block-sidebar .widget a.button, .' . $block . ' ' . '.tfm-post-block-sidebar .widget input[type="submit"], .' . $block . ' ' . '.tfm-post-block-sidebar .widget input[type="button"] { background: ' . get_theme_mod( $block . '_widget_button_background', '' ) . ';}' : '' );

				$custom_colors[$block . '_widget_button_color'] = ( '' !== get_theme_mod( $block . '_widget_button_color', '' ) ? '.' . $block . ' ' . '.tfm-post-block-sidebar .widget button, .' . $block . ' ' . '.tfm-post-block-sidebar .widget a.button, .' . $block . ' ' . '.tfm-post-block-sidebar .widget input[type="submit"], .' . $block . ' ' . '.tfm-post-block-sidebar .widget input[type="button"] { color: ' . get_theme_mod( $block . '_widget_button_color', '' ) . ';}' : '' );

				$custom_colors[$block . '_widget_line_color'] = ( '' !== get_theme_mod( $block . '_widget_line_color', '' ) ? '.' . $block . ' ' . '.tfm-post-block-sidebar .widget li, .' . $block . ' ' . '.tfm_posts_widget .list-style-list.has-post-thumbnails li > .entry-meta.after-title, .' . $block . ' ' . '.tfm_posts_widget .list-style-list-first-grid.has-post-thumbnails li:not(:first-child) > .entry-meta.after-title { border-color: ' . get_theme_mod( $block . '_widget_line_color', '' ) . ';}' : '' );

			} // Endif has sidear

		} // End foreach block

	} // Endif blocks

	if ( tfm_home_blocks_active( ) ) {

	$block_css = array_filter($custom_colors);

if ( count($block_css) !== 0 ) : ?>
<style type="text/css" id="tfm-home-blocks-custom-css">
<?php foreach ($block_css as $css ) {
	echo wp_strip_all_tags( $css ) . "\n";
} ?>
</style>

<?php endif; ?>

<style type="text/css" id="tfm-home-blocks-css-vars">
	.tfm-posts-block[data-poststyle="cover-default"] .article.cover.has-post-thumbnail:not(.disabled-post-thumbnail) .entry-title a,
	.tfm-posts-block[data-poststyle="cover-default"] .article.cover.has-post-thumbnail:not(.disabled-post-thumbnail) .entry-meta a {
		color:  var(--cover-global-color) !important;
	}
	.tfm-posts-block[data-poststyle="cover-default"] .article.cover.has-post-thumbnail:not(.disabled-post-thumbnail) .entry-meta ul {
		color: var(--cover-meta-color, var(--cover-global-color)) !important;
	}
	.tfm-posts-block[data-poststyle="cover-default"] .article.cover.has-post-thumbnail:not(.disabled-post-thumbnail) .entry-wrapper .excerpt {
		color: var(--cover-excerpt-color, var(--cover-global-color)) !important;
	}
	.tfm-posts-block[data-poststyle="cover-default"] .article.cover.has-post-thumbnail:not(.disabled-post-thumbnail) .read-more {
	  color: var(--cover-button-color, var(--continue-reading-button-color)) !important;
	  background: var(--cover-button-background, var(--continue-reading-button-background)) !important;
	}
	.tfm-posts-block[data-poststyle="cover-default"] .article.cover.has-post-thumbnail:not(.disabled-post-thumbnail) .read-more:hover {
		color: var(--cover-button-hover-color, var(--continue-reading-button-hover-color)) !important;
		background: var(--cover-button-hover-background, var(--continue-reading-button-hover-background)) !important;
	}
	.tfm-posts-block[data-poststyle="cover-default"] .article.cover.has-post-thumbnail:not(.disabled-post-thumbnail) .entry-read-more, .tfm-posts-block[data-poststyle="cover-default"] .article.cover.has-post-thumbnail:not(.disabled-post-thumbnail) .entry-meta-read-time {
	  	border-color: var(--cover-border-color, var(--very-light-grey)) !important;
	}
	.tfm-posts-block[data-poststyle="cover-default"] .article.cover.has-post-thumbnail:not(.disabled-post-thumbnail) .entry-read-more .entry-meta-read-time::after {
	  color: var(--cover-entry-meta-icon-color, var(--light-grey));
	}
</style>

<?php } // Endif tfm_home_blocks_active( )

} // End function

add_action( 'wp_head', 'tfm_home_blocks_widget_colors' ); // Enqueue the CSS Inline Style after the main stylesheet

 ?>