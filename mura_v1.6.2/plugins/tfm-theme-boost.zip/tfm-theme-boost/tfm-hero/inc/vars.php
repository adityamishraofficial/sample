<?php

/**
 * 3FortyMedia Hero Plugin Vars
 *
 * @since 1.0
 * @version 1.1
 */

?>

<?php

$hero_active = ( ( ( is_front_page() && get_theme_mod( 'tfm_hero', true ) ) || ( is_home() && 'page' === get_option( 'show_on_front') && get_theme_mod( 'tfm_hero_blog', true ) ) ) && ! is_paged() ? true : false );

// Post Num
$post_num = get_theme_mod( 'tfm_hero_post_num', 1 );
if ( get_theme_mod( 'tfm_hero_layout', 'grid' ) === 'grid' && $post_num > apply_filters( 'tfm_hero_max_grid_posts', 4 ) ) {
	$post_num = apply_filters( 'tfm_hero_max_grid_posts', 4 );
}
if ( get_theme_mod( 'tfm_hero_layout', 'grid' ) === 'grid-offset' && $post_num > apply_filters( 'tfm_hero_max_grid_offset_posts', 3 ) ) {
	$post_num = apply_filters( 'tfm_hero_max_grid_offset_posts', 3 );
}
if ( get_theme_mod( 'tfm_hero_layout', 'grid' ) === 'grid-offset-half' && $post_num > apply_filters( 'tfm_hero_max_grid_offset_half_posts', 5 ) ) {
	$post_num = apply_filters( 'tfm_hero_max_grid_offset_half_posts', 5 );
}
if ( get_theme_mod( 'tfm_hero_layout', 'grid' ) === 'grid-offset-sides' && $post_num > apply_filters( 'tfm_hero_max_grid_offset_half_posts', 5 ) ) {
	$post_num = apply_filters( 'tfm_hero_max_grid_offset_half_posts', 5 );
}
if ( 'post_ids' === get_theme_mod( 'tfm_hero_post_type', 'recent' ) && '' !== get_theme_mod( 'tfm_hero_post_ids', '' ) ) {
	$explode_post_ids = explode(',', get_theme_mod( 'tfm_hero_post_ids', '' ));
	$post_num = count($explode_post_ids);
}
// Max slides supported
$max_slides_supported = apply_filters( 'tfm_hero_max_slidestoshow', 4 );
// Slides to show
$slides_to_show = get_theme_mod( 'tfm_hero_slidestoshow', 1 );
if ( $slides_to_show  > apply_filters( 'tfm_hero_max_slidestoshow', 4 ) ) {
	$slides_to_show = apply_filters( 'tfm_hero_max_slidestoshow', 4 );
}
if ( $slides_to_show === 0 || '' === $slides_to_show ) {
	$slides_to_show = 1;
}
if ( $slides_to_show > $post_num ) {
	$slides_to_show = $post_num;
}
if ( $post_num === $slides_to_show && get_theme_mod( 'tfm_hero_centermode', false ) ) {
	$slides_to_show = $slides_to_show - 1;
}
$active_status = ( $slides_to_show === $post_num ? 'inactive' : 'active' );
if ( ! get_theme_mod( 'tfm_hero_arrows', true ) ) {
	$active_status = 'inactive';
}

$layout = get_theme_mod( 'tfm_hero_layout', 'grid' );
if ( $layout === 'slider' && $post_num === 1 ) {
	$layout = 'grid';
}
if ( $slides_to_show > 1 && $layout === 'slider' ) {
	$layout = 'carousel';
}
$post_style = get_theme_mod( 'tfm_hero_style', 'default' );
$cols = ' cols-';
$cols .= ( $layout === 'grid' ? $post_num : $slides_to_show );
if ( 'grid-offset' === get_theme_mod( 'tfm_hero_layout', 'grid' ) || 'grid-offset-half' === get_theme_mod( 'tfm_hero_layout', 'grid' ) || 'grid-offset-sides' === get_theme_mod( 'tfm_hero_layout', 'grid' ) ) {
	$cols = ' cols-2';
}
$full_width = ( get_theme_mod( 'tfm_hero_full_width', false ) ? 'true' : 'false' );
$has_post_thumbnails = get_theme_mod( 'tfm_hero_thumbnail', true ) ? ' has-post-thumbnails' : '';
$thumbnail = ( 'true' === $full_width && $post_num === 1 && $post_style === 'cover' ? 'full' : apply_filters( 'tfm_hero_thumbnail', 'large' ) );
$slick = ( ($layout === 'slider' || $layout === 'carousel' ) ? ' slick' : '' );
$arrows = ( get_theme_mod( 'tfm_hero_arrows', false ) ? 'true' : 'false' );
$pagination = ( get_theme_mod( 'tfm_hero_pagination', false ) ? 'true' : 'false' );
$centermode = ( get_theme_mod( 'tfm_hero_centermode', false ) ? 'true' : 'false' );
$margins = ( get_theme_mod( 'tfm_hero_margins', true ) ? 'true' : 'false' );
$hero_background = '' !== get_theme_mod( 'tfm_hero_background', '' ) || '' !== get_theme_mod( 'tfm_hero_background_image', '' ) ? 'true' : 'false';
$has_post_count = get_theme_mod( 'tfm_hero_post_count', false ) ? ' has-post-count' : '';
$autoplay_speed = get_theme_mod( 'tfm_hero_autoplay_speed', 3000 );
$speed = get_theme_mod( 'tfm_hero_slide_speed', 500 );

// Grid offset aside wrapper
$wrapper_open = false;
// ========================================================
// Post Meta Vars
// ========================================================
$meta_var['author'] = ( get_theme_mod( 'tfm_hero_entry_meta_author', true ) ? ' has-author' : '' );
$meta_var['avatar'] = ( get_theme_mod( 'tfm_hero_entry_meta_author_avatar', false ) ? ' has-avatar' : '' );
$meta_var['excerpt'] = ( get_theme_mod( 'tfm_hero_excerpt', false ) ? ' has-excerpt' : '' );
$meta_var['read_time'] = ( get_theme_mod( 'tfm_hero_entry_meta_read_time', false ) ? ' has-tfm-read-time' : '' );
$meta_var['date'] = ( get_theme_mod( 'tfm_hero_entry_meta_date', false ) ? ' has-date' : '' );
$meta_var['comment_count'] = ( get_theme_mod( 'tfm_hero_entry_meta_date', false ) ? ' has-comment-count' : '' );
$meta_var['category'] = ( get_theme_mod( 'tfm_hero_entry_meta_category', true ) ? ' has-category-meta' : '' );

// Post background class

// Get theme settings
$current_theme_settings = function_exists('tfm_general_settings') ? tfm_general_settings() : '';

$default_post_background = $current_theme_settings && array_key_exists('default_archive_post_background', $current_theme_settings ) ? $current_theme_settings['default_archive_post_background'] : '';

$hero_post_background = '' !== get_theme_mod( 'tfm_hero_post_background', '' ) ? get_theme_mod( 'tfm_hero_post_background', '' ) : $default_post_background;

$meta_var['post_background'] = ( '' !== $hero_post_background ? ' has-background' : '' );
$meta_var['read_more'] = ( get_theme_mod( 'tfm_hero_read_more', false ) ? ' has-read-more' : '' );
$meta_var['style'] = $post_style;

$meta_vars = join( ' ', $meta_var );

$has_meta_after_title = ( ( get_theme_mod( 'tfm_hero_entry_meta_date', false ) || get_theme_mod( 'tfm_hero_entry_meta_comment_count', false ) || get_theme_mod( 'tfm_hero_entry_meta_author', false ) || get_theme_mod( 'tfm_hero_entry_meta_author_avatar', false ) || get_theme_mod( 'tfm_hero_entry_meta_read_time', false ) ) && apply_filters( 'tfm_hero_after_title_meta_criteria', true ) ? ' has-meta-after-title' : '' );

// ========================================================
// Custom Colors
// ========================================================
$style = ' style="';

// Background color and image

$hero_custom_background = get_theme_mod( 'tfm_hero_background', '' );
$hero_background_image = get_theme_mod( 'tfm_hero_background_image', '' );

$custom_color['hero_background'] = ( $hero_custom_background || $hero_background_image ) ? $style : '';
$custom_color['hero_background'] .= ( $hero_custom_background ? 'background:' . $hero_custom_background . ';' : '' );
$custom_color['hero_background'] .= ( $hero_background_image ? 'background-image: url(' . $hero_background_image . ');' : '' );
$custom_color['hero_background'] .= ( $hero_custom_background || $hero_background_image ) ? '"' : '';

//$custom_color['hero_background'] = ( '' !== get_theme_mod( 'tfm_hero_background', '' ) ? $style . 'background:' . get_theme_mod( 'tfm_hero_background', '' ) . '"' : '' );
$custom_color['post_background'] = ( '' !== get_theme_mod( 'tfm_hero_post_background', '' ) ? $style . 'background:' . get_theme_mod( 'tfm_hero_post_background', '' ) . '"' : '' );
$custom_color['entry_title'] = ( '' !== get_theme_mod( 'tfm_hero_entry_title_color', '' ) ? $style . 'color:' . get_theme_mod( 'tfm_hero_entry_title_color', '' ) . '"' : '' );
$custom_color['entry_meta'] = ( get_theme_mod( 'tfm_hero_entry_meta_color', '' ) ? $style . 'color:' . get_theme_mod( 'tfm_hero_entry_meta_color', '' ) . '"' : '' );
$custom_color['entry_meta_link'] = ( get_theme_mod( 'tfm_hero_entry_meta_link_color', '' ) ? $style . 'color:' . get_theme_mod( 'tfm_hero_entry_meta_link_color', '' ) . '"' : '' );
$custom_color['entry_content'] = ( get_theme_mod( 'tfm_hero_entry_content_color', '' ) ? $style . 'color:' . get_theme_mod( 'tfm_hero_entry_content_color', '' ) . '"' : '' );
$custom_color['avatar_border_color'] = ( get_theme_mod( 'tfm_hero_avatar_border_color', '' ) ? $style . 'border-color:' . get_theme_mod( 'tfm_hero_avatar_border_color', '' ) . '"' : '' );
$custom_color['button_background'] = ( get_theme_mod( 'tfm_hero_button_background', '' ) ? $style . 'background:' . get_theme_mod( 'tfm_hero_button_background', '' ) . '"' : '' );
$custom_color['button_color'] = ( get_theme_mod( 'tfm_hero_button_color', '' ) ? $style . 'color:' . get_theme_mod( 'tfm_hero_button_color', '' ) . '"' : '' );
$custom_color['border_color'] = ( get_theme_mod( 'tfm_hero_border_color', '' ) ? $style . 'border-color:' . get_theme_mod( 'tfm_hero_border_color', '' ) . '"' : '' );

// Count

$count_background = get_theme_mod( 'tfm_hero_count_background', '' );
$count_color = get_theme_mod( 'tfm_hero_count_color', '' );

$custom_color['count_color'] = ( $count_background || $count_color ) ? $style : '';
$custom_color['count_color'] .= ( $count_background ? 'background:' . $count_background . ';' : '' );
$custom_color['count_color'] .= ( $count_color ? 'color:' . $count_color . '' : '' );
$custom_color['count_color'] .= ( $count_background || $count_color ) ? '"' : '';

$allowed_html = array(
    'style' => array()
    );

// ========================================================
// Query Vars
// ========================================================
$post_offset = get_theme_mod( 'tfm_hero_post_offset', 0 );
$post_type = get_theme_mod( 'tfm_hero_post_type', 'recent' );
$post_cat = get_theme_mod( 'tfm_hero_post_cat', '' );
// Specific posts
$post_in = ( $post_type === 'post_ids' && '' !== get_theme_mod( 'tfm_hero_post_ids', '' ) ? explode(',', get_theme_mod( 'tfm_hero_post_ids', '' ) ) : '' );
$tag_in = ( '' !== get_theme_mod( 'tfm_hero_tag_ids', '' ) ? explode(',', get_theme_mod( 'tfm_hero_tag_ids', '' ) ) : '' );
// Popular posts
$order_by = ( $post_type === 'popular' ? 'comment_count' : '' );
if ( $post_type === 'random' ) {
	$order_by = 'rand';
}
// Exclude Post ID's
$post_not_in = ( $post_type !== 'post_ids' && '' !== get_theme_mod( 'tfm_hero_exclude_post_ids', '' ) ? explode(',', get_theme_mod( 'tfm_hero_exclude_post_ids', '' ) ) : '' );
$sort_order = get_theme_mod( 'tfm_hero_sort_order', 'desc' );

?>