<?php

/**
 * 3FortyMedia Post Blocks Plugin Vars
 *
 * @since 1.0
 * @version 1.2
 */

?>

<?php

global $post;

$has_theme_sidebar = in_array('has-sidebar', get_body_class()) ? true : false;

$post_num = get_theme_mod( $block . '_post_num', 3 );
// If post IDs count is equal to the number of post IDs
if ( 'post_ids' === get_theme_mod( '' . $block . '_post_type', 'recent' ) && '' !== get_theme_mod( '' . $block . '_post_ids' ) ) {
	$explode_post_ids = explode(',', get_theme_mod( '' . $block . '_post_ids' ));
	$post_num = count($explode_post_ids);
}
$post_type = get_theme_mod( $block . '_post_type', 'recent' );
$has_block_sidebar = ( get_theme_mod( $block . '_sidebar', false ) && is_active_sidebar( 'sidebar-' . $block ) ? ' has-block-sidebar' : false );
$block_sidebar_position = get_theme_mod( $block . '_sidebar_position', 'right' );
$widget_background = ( '' !== get_theme_mod( $block . '_widget_background', '') ? ' has-background' : '' );
$post_cols = get_theme_mod( $block . '_cols', 3 );
if ( $has_theme_sidebar && $post_cols > apply_filters( 'tfm_home_blocks_max_post_cols_with_theme_sidebar', 2 ) )  {
	$post_cols = apply_filters( 'tfm_home_blocks_max_post_cols_with_theme_sidebar', 2 );
}
if ( $has_block_sidebar && ( 'right' === $block_sidebar_position || 'left' === $block_sidebar_position ) && $post_cols > apply_filters( 'tfm_home_blocks_max_post_cols_with_block_sidebar', 2 ) )  {
	$post_cols = apply_filters( 'tfm_home_blocks_max_post_cols_with_block_sidebar', 2 );
}
if ( $has_theme_sidebar && $has_block_sidebar && $post_cols > apply_filters( 'tfm_home_blocks_max_post_cols_with_block_and_theme_sidebar', 1 ) )  {
	$post_cols = apply_filters( 'tfm_home_blocks_max_post_cols_with_block_and_theme_sidebar', 1 );
}
if ( get_theme_mod( $block . '_layout', 'grid' ) === 'grid-offset' || get_theme_mod( $block . '_layout', 'grid' ) === 'grid-offset-half' || get_theme_mod( $block . '_layout', 'grid' ) === 'grid-offset-sides' || get_theme_mod( $block . '_layout', 'grid' ) === 'grid-list-half' ) {
    $post_cols = 'none';
}
$is_offset_layout = $post_cols === 'none' ? true : false;
$cols_class = ' cols-' . $post_cols;
$thumbnail_aspect_ratio = ' thumbnail-' . get_theme_mod( $block . '_image_size', 'landscape' );
$thumbnail_size = $post_cols === 1 && get_theme_mod( $block . '_layout', 'grid' ) === 'grid' ? 'large' : 'medium_large';
$layout = ' ' . get_theme_mod( $block . '_layout', 'grid' );
$offset_list = 'grid-list-half' === get_theme_mod( $block . '_layout', 'grid' ) ? ' list' : '';
$post_style = get_theme_mod( $block . '_post_style', 'default' );
$has_title = ( get_theme_mod( $block . '_title', '' ) ? ' has-title' : '' );
$has_subtitle = ( get_theme_mod( $block . '_subtitle', '' ) ? ' has-subtitle' : '' );
$block_sidebar_position = ( $has_block_sidebar ? ' sidebar-' . get_theme_mod( $block . '_sidebar_position', 'right' ) : '' );
$show_thumbnail = get_theme_mod( $block . '_thumbnail', true );
$show_media = get_theme_mod( $block . '_media', true );
$link_more = ( get_theme_mod( '' . $block . '_link_more_destination', '' ) ? true : false );
$link_more_text = get_theme_mod( $block . '_link_more_text', '' );
$has_link_more = $link_more && $link_more_text ? ' has-link-more' : '';
// The destination link
$url_id = get_theme_mod( '' . $block . '_link_more_destination', '' );
$url_is_page = strpos($url_id , 'page');
$the_link = $url_is_page === false ? get_category_link( $url_id ) : get_page_link( substr($url_id, 5) );
// End link
$has_post_count = get_theme_mod( $block . '_post_count', false ) ? ' has-post-count' : '';
$excerpt_length = get_theme_mod( $block . '_excerpt_length', '' );

// These vars are supported on a per theme basis
$full_width = get_theme_mod( $block . '_full_width', false ) && ! $has_theme_sidebar ? 'true' : 'false';
$alignfull = get_theme_mod( $block . '_full_width', false ) & ! $has_theme_sidebar ? ' alignfull' : '';
$margins = ( get_theme_mod( $block . '_margins', true ) ? 'true' : 'false' );
// End theme specific vars

$woocommerce = $post_type === 'recent_products' || $post_type === 'product_ids' ? ' woocommerce' : '';

// Grid offset aside wrapper
$wrapper_open = false;

// ========================================================
// Post Meta Vars
// ========================================================
$meta_var['author'] = ( get_theme_mod( $block . '_entry_meta_author', true ) ? 'has-author' : '' );
$meta_var['avatar'] = ( get_theme_mod( $block . '_entry_meta_author_avatar', false ) ? 'has-avatar' : '' );
$meta_var['excerpt'] = ( get_theme_mod( $block . '_excerpt', false ) ? 'has-excerpt' : '' );
$meta_var['read_time'] = ( get_theme_mod( $block . '_entry_meta_read_time', false ) ? 'has-tfm-read-time' : '' );
$meta_var['date'] = ( get_theme_mod( $block . '_entry_meta_date', true ) ? 'has-date' : '' );
$meta_var['comment_count'] = ( get_theme_mod( $block . '_entry_meta_date', true ) ? 'has-comment-count' : '' );
$meta_var['category'] = ( get_theme_mod( $block . '_entry_meta_category', true ) ? 'has-category-meta' : '' );
$meta_var['style'] = $post_style;
$meta_var['read_more'] = ( get_theme_mod( $block . '_read_more', false ) ? 'has-read-more' : '' );
$meta_var['post_background'] = ( '' !== get_theme_mod( $block . '_post_background', '' ) ? 'has-background' : '' );
$meta_var['post_format'] = ( has_post_format( 'gallery' ) || has_post_format( 'audio' ) || has_post_format( 'video' ) ? 'format-' : '' );

// Border Class
$site_background = '#' . get_background_color();
$pseudo_background = '' === get_theme_mod( $block . '_background', '' ) ? $site_background : get_theme_mod( $block . '_background', '' );
$meta_var['post_border'] = '' !== get_theme_mod( $block . '_border_color', '' ) && get_theme_mod( $block . '_border_color', '' ) === $pseudo_background ? 'no-border' : '';

$meta_vars = join( ' ', $meta_var );

// Check for after title meta
$has_after_title_meta = ( $meta_var['author'] || $meta_var['avatar'] || $meta_var['read_time'] || $meta_var['date'] || $meta_var['comment_count'] ? true : false );

// ========================================================
// Custom Colors
// ========================================================
$style = ' style="';
$custom_color['background'] = ( '' !== get_theme_mod( $block . '_background', '' ) ? $style . 'background:' . get_theme_mod( $block . '_background', '' ) . '"' : '' );
$custom_color['title'] = ( '' !== get_theme_mod( $block . '_title_color', '' ) ? $style . 'color:' . get_theme_mod( $block . '_title_color', '' ) . '"' : '' );
$custom_color['subtitle'] = ( '' !== get_theme_mod( $block . '_subtitle_color', '' ) ? $style . 'color:' . get_theme_mod( $block . '_subtitle_color', '' ) . '"' : '' );
$custom_color['link_more'] = ( '' !== get_theme_mod( $block . '_link_more_color', '' ) ? $style . 'color:' . get_theme_mod( $block . '_link_more_color', '' ) . '"' : '' );
$custom_color['post_background'] = ( '' !== get_theme_mod( $block . '_post_background', '' ) ? $style . 'background-color:' . get_theme_mod( $block . '_post_background', '' ) . '"' : '' );
$custom_color['entry_title'] = ( '' !== get_theme_mod( $block . '_entry_title_color', '' ) ? $style . 'color:' . get_theme_mod( $block . '_entry_title_color', '' ) . '"' : '' );
$custom_color['entry_meta'] = ( get_theme_mod( $block . '_entry_meta_color', '' ) ? $style . 'color:' . get_theme_mod( $block . '_entry_meta_color', '' ) . '"' : '' );
$custom_color['entry_meta_link'] = ( get_theme_mod( $block . '_entry_meta_link_color', '' ) ? $style . 'color:' . get_theme_mod( $block . '_entry_meta_link_color', '' ) . '"' : '' );
$custom_color['entry_content'] = ( get_theme_mod( $block . '_entry_content_color', '' ) ? $style . 'color:' . get_theme_mod( $block . '_entry_content_color', '' ) . '"' : '' );
$custom_color['post_border'] = ( get_theme_mod( $block . '_border_color', '' ) ? $style . 'border-color:' . get_theme_mod( $block . '_border_color', '' ) . '"' : '' );

// Post Inner Background/Border

$post_background = get_theme_mod( $block . '_post_background', '' );
$post_border_color = get_theme_mod( $block . '_border_color', '' );

$custom_color['post_background_border'] = ( $post_background || $post_border_color ) ? $style : '';
$custom_color['post_background_border'] .= ( $post_background ? 'background-color:' . $post_background . ';' : '' );
$custom_color['post_background_border'] .= ( $post_border_color ? 'border-color:' . $post_border_color . '' : '' );
$custom_color['post_background_border'] .= ( $post_background || $post_border_color ) ? '"' : '';

// Button

$button_background = get_theme_mod( $block . '_continue_reading_button_background', '' );
$button_color = get_theme_mod( $block . '_continue_reading_button_color', '' );

$custom_color['button'] = ( $button_background || $button_color ) ? $style : '';
$custom_color['button'] .= ( $button_background ? 'background:' . get_theme_mod( $block . '_continue_reading_button_background', '' ) . ';' : '' );
$custom_color['button'] .= ( $button_color ? 'color:' . get_theme_mod( $block . '_continue_reading_button_color', '' ) . '' : '' );
$custom_color['button'] .= ( $button_background || $button_color ) ? '"' : '';

// End Button

$custom_color['entry_meta_border_color'] = ( get_theme_mod( $block . '_entry_meta_border_color', '' ) ? $style . 'border-color:' . get_theme_mod( $block . '_entry_meta_border_color', '' ) . '"' : '' );
$custom_color['format_icon_border'] = ( '' !== get_theme_mod( $block . '_post_background', '' ) ? $style . 'border-color:' . get_theme_mod( $block . '_post_background', '' ) . '"' : '' );

// Count

$count_background = get_theme_mod( $block . '_count_background', '' );
$count_color = get_theme_mod( $block . '_count_color', '' );

$custom_color['format_count_colors'] = ( $count_background || $count_color ) ? $style : '';
$custom_color['format_count_colors'] .= ( $count_background ? 'background:' . $count_background . ';' : '' );
$custom_color['format_count_colors'] .= ( $count_color ? 'color:' . $count_color . '' : '' );
$custom_color['format_count_colors'] .= ( $count_background || $count_color ) ? '"' : '';


$allowed_html = array(
    'style' => array()
    );

// ========================================================
// Query args
// ========================================================

$query_args = tfm_home_blocks_post_query($block);