<?php

/**
 * TFM Related Posts Hooks
 *
 *
 * @package WordPress
 * @subpackage Mura
 * @since 1.0
 * @version 1.1
 */

// ========================================================
// Custom Hooks
// ========================================================
function tfm_related_posts_prepend_after_title_meta() {
    do_action('tfm_related_posts_prepend_after_title_meta');
}
function tfm_related_posts_append_after_title_meta() {
    do_action('tfm_related_posts_append_after_title_meta');
}
function tfm_related_posts_after_continue_reading_button() {
    do_action('tfm_related_posts_after_continue_reading_button');
}

function tfm_related_posts_after_after_title_meta() {
    do_action('tfm_related_posts_after_after_title_meta');
}

function tfm_related_posts_entry_header_open() {
    do_action('tfm_related_posts_entry_header_open');
}

function tfm_related_posts_entry_header_close() {
    do_action('tfm_related_posts_entry_header_close');
}

function tfm_related_posts_after_entry_title() {
    do_action('tfm_related_posts_after_entry_title');
}

?>