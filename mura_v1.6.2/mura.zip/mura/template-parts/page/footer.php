<?php
/**
 * The template for displaying page footer
 *
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Mura
 * @since 1.0
 * @version 1.0
 */

?>

<footer class="hentry-footer page-hentry-footer">
	<?php tfm_page_footer(); ?>

</footer>