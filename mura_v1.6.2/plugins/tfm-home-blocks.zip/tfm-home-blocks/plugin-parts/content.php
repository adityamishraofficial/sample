<?php
/**
 * 3FortyMedia Home Blocks Block Content
 *
 * @since 1.0
 * @version 1.2
 */

?>

<?php $has_post_format = ( has_post_format( 'gallery' ) || has_post_format( 'audio' ) || has_post_format( 'video' ) ? ' format-' . get_post_format() : '' ); ?>
<?php $has_format_icons = $has_post_format && get_theme_mod( $block . '_post_format_icons', true ) ? ' has-format-icons' : ''; ?>
<?php $featured_media = get_theme_mod( $block . '_media', true ) ? true : false; ?>
<?php $has_video = $featured_media && tfm_home_blocks_featured_video(true) ? ' has-featured-video' : false; ?>
<?php $entry_header = get_theme_mod( $block . '_entry_meta_category', true ) || get_theme_mod( $block . '_entry_title', true ) || $has_after_title_meta || ( function_exists( 'tfm_ratings' ) && ( get_theme_mod( $block . '_tfm_star_rating', false ) || get_theme_mod( $block . '_tfm_points_rating', false ) || get_theme_mod( $block . '_tfm_percent_rating', false ) || get_theme_mod( $block . '_tfm_scale_rating', false ) ) ) ? true : false;  ?>

<?php

if ( $is_offset_layout ) {

	// Offset layout thumbnail size

	if ( get_theme_mod( $block . '_layout', 'grid' ) === 'grid-offset-sides' ) {
		$thumbnail_size = $faux_count === 3 ? 'large' : 'medium_large';
	} else {
		$thumbnail_size = $faux_count === 1 ? 'large' : 'medium_large';
	}

}
?>


<article class="post article <?php echo esc_attr( $meta_vars . $thumbnail_class . $has_post_format . $has_format_icons . $has_video . $grid_style . ' faux-count-' . $faux_count ); ?>">

	<?php include( TFM_POST_BLOCKS__PLUGIN_DIR . 'plugin-parts/format-icons.php' ); ?>

    		<div class="post-inner"<?php echo wp_kses( $custom_color['post_border'], $allowed_html ) ?>>

    			<?php if ( $has_video) { echo tfm_home_blocks_featured_video(); } ?>

    		<?php if ( '' !== get_the_post_thumbnail() && $show_thumbnail && ! $has_video ) : ?>
    			<div class="thumbnail-wrapper">
				<figure class="post-thumbnail">

						<a href="<?php the_permalink(); ?>">
							<?php the_post_thumbnail( esc_attr( $thumbnail_size) ); ?>
						</a>

				</figure>
			</div>

			<?php endif; ?>

			<div class="entry-wrapper"<?php echo wp_kses( $custom_color['post_background'], $allowed_html ) ?>>

				<?php if ( $entry_header): ?>

	    	<div class="entry-header">

	    		<?php include( TFM_POST_BLOCKS__PLUGIN_DIR . 'plugin-parts/format-icons.php' ); ?>

				<?php if ( get_theme_mod( $block . '_entry_meta_category', true ) ) : ?>

				<div class="entry-meta before-title"<?php echo wp_kses( $custom_color['entry_meta'], $allowed_html ) ?>>

						<?php if ( function_exists( 'tfm_get_category' ) ) {

							tfm_get_category( '', get_theme_mod( $block . '_entry_meta_in', true ) ); 

						} else {

							the_category(', ');

						} ?>

				</div><!-- .entry-meta -->

		<?php endif; ?>

		<?php if ( get_theme_mod( $block . '_entry_title', true ) ) : ?>

			<?php the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark"' . wp_kses( $custom_color['entry_title'], $allowed_html ) . '>', '</a></h3>' ); ?>

		<?php endif; ?>

		<?php if ( $has_after_title_meta ) : ?>

			<div class="entry-meta after-title">

				<ul class="after-title-meta"<?php echo wp_kses( $custom_color['entry_meta'], $allowed_html ) ?>>

					<?php tfm_home_blocks_prepend_after_title_meta(); ?>

					<?php if ( get_theme_mod( $block . '_entry_meta_author_avatar', false ) ) : ?>

						<li class="entry-meta-avatar">

								<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) ?>"><?php echo get_avatar( get_the_author_meta('ID'), 40 ); ?></a>

						</li>

						<?php endif; ?>

						<?php if ( get_theme_mod( $block . '_entry_meta_author', true ) ) : ?>

						<li class="entry-meta-author">

							<span class="screen-reader-text"><?php echo esc_html__( 'Posted by', 'tfm-home-blocks' ); ?></span><?php if ( get_theme_mod( $block . '_entry_meta_by', true ) ): ?><i dir="ltr"><?php echo esc_html__( 'by', 'tfm-home-blocks' ) ?></i><?php endif; ?> <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) ?>"<?php echo wp_kses( $custom_color['entry_meta_link'], $allowed_html ) ?>><?php echo get_the_author() ?></a>

						</li>

					<?php endif; ?>

					<?php if ( get_theme_mod( $block . '_entry_meta_date', true ) ): ?>
				
					<li class="entry-meta-date">

						<time datetime="<?php echo get_the_date( 'Y-m-d' ) ?>"><?php the_time( get_option( 'date_format' ) ); ?></time>

					</li>

					<?php endif; ?>

					<?php if ( get_theme_mod( $block . '_entry_meta_comment_count', true ) ): ?>

						<li class="entry-meta-comment-count">

							<?php echo get_comments_number() ?> <span><?php comments_number( __('Comments', 'tfm-home-blocks'), __('Comment', 'tfm-home-blocks'), __('Comments', 'tfm-home-blocks') ) ?></span>

						</li>

						<?php endif; ?>

						<?php

						if ( function_exists( 'tfm_read_time' ) && get_theme_mod( $block . '_entry_meta_read_time', false ) ) {

							tfm_read_time( true );

						} ?>

						<?php tfm_home_blocks_append_after_title_meta(); ?>

				</ul>

			</div>

		<?php endif; ?>

		<?php

			if ( function_exists( 'tfm_ratings' ) && ( get_theme_mod( $block . '_tfm_star_rating', false ) || get_theme_mod( $block . '_tfm_points_rating', false ) || get_theme_mod( $block . '_tfm_percent_rating', false ) || get_theme_mod( $block . '_tfm_scale_rating', false ) ) ) {

				tfm_ratings( get_theme_mod( $block . '_tfm_star_rating', false ), get_theme_mod( $block . '_tfm_points_rating', false ), get_theme_mod( $block . '_tfm_percent_rating', false ), get_theme_mod( $block . '_tfm_scale_rating', false ), true ); // $star_rating, $points_rating, $percent_rating, $scale_rating, $forced_request

			} ?>

			<?php tfm_home_blocks_after_after_title_meta(); ?>

			</div><!-- .entry-header -->

		<?php endif; ?>

			<?php if ( get_theme_mod( $block . '_excerpt', false ) ): ?>

				<div class="entry-content excerpt"<?php echo wp_kses( $custom_color['entry_content'], $allowed_html ) ?>>

					<?php echo esc_html( tfm_home_blocks_excerpt( $excerpt_length ) ); ?>

				</div>

			<?php endif; ?>

			<?php

			// Read more

			if ( get_theme_mod( $block . '_read_more', false ) )  : ?>

				<ul class="entry-read-more"<?php echo wp_kses( $custom_color['entry_meta_border_color'], $allowed_html ) ?>>

					<li class="read-more-button"<?php echo wp_kses( $custom_color['entry_meta_border_color'], $allowed_html ) ?>><a href="<?php echo esc_url( get_permalink() ); ?>" class="button read-more"<?php echo wp_kses( $custom_color['button'], $allowed_html ) ?>><span><?php echo esc_html__( 'Continue Reading', 'tfm-home-blocks'); ?></span></a></li>

					<?php

					if ( function_exists( 'tfm_read_time' ) && get_theme_mod( $block . '_entry_meta_read_time', false ) ) {

						tfm_read_time( true );

					} ?>

					<?php tfm_home_blocks_after_continue_reading_button(); ?>

				</ul>

			<?php endif; ?>

		</div>

	</div>

	    </article>