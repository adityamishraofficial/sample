=== TFM Social Plugin ===

Plugin Name: TFM Social Plugin

Author: 3FortyMedia

Author URI: https://www.3forty.media/

Requires at least: 5.8

Tested up to: 6.0

Requires PHP: 7.0

License: GPLv2

License URI: https://www.gnu.org/licenses/gpl-2.0.html

=== Description ===
Display links and icons to your social media channels in widgets and theme files and share content to social media channels.

=== Changelog ===

= 1.2.5 =
Added plugin CSS

= 1.2.4 =
Added Gettr

= 1.2.3 =
Added Telegram

= 1.2.2 =
Minor Code updates

= 1.2.1 =
Minor Code updates

= 1.2 = 
* Added Steam

= 1.1 =
* Added Discord

= 1.0 - Initial release =



