<?php

/**
Plugin Name: TFM: Homepage Post Blocks
Plugin URI:  http://www.3forty.media
Description: Display configurable post blocks and sidebars on your homepage.
Version:     1.2.5
Author:      3FortyMedia
Author URI:  http://www.3forty.media
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

function tfm_home_blocks_init() {
	// load language files.
	load_plugin_textdomain( 'tfm-home-blocks', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'init', 'tfm_home_blocks_init' );

define( 'TFM_POST_BLOCKS__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// ========================================================
// Display Blocks function
// ========================================================
function tfm_home_blocks( ) {

	if ( is_front_page() && tfm_home_blocks_active( ) ) {

		include( TFM_POST_BLOCKS__PLUGIN_DIR . 'plugin-parts/home-blocks.php' );
	}

}
add_action( 'tfm_before_loop', 'tfm_home_blocks' );

// ========================================================
// Get theme text domain
// ========================================================

if ( ! function_exists( 'tfm_get_theme_textdomain' ) ) {

	function tfm_get_theme_textdomain() {

		$theme = wp_get_theme();
		$theme_slug =  $theme->get( 'TextDomain' );

		// Themes released after Mura
		if ( $theme_slug !== 'mura' ) {
			$theme_slug = 'tfm';
		}

		return $theme_slug;
	}

}

// ========================================================
// Dequeue masonry if home blocks is active
// ========================================================
function tfm_home_blocks_dequeue_masonry() {

	if ( is_home() && tfm_home_blocks_active( )) {
		wp_dequeue_script( 'masonry' );
		wp_dequeue_script( '' . tfm_get_theme_textdomain() . '-masonry-init' );
	}
}
add_action( 'wp_print_scripts', 'tfm_home_blocks_dequeue_masonry', 100 );


// ========================================================
// Remove home blog header
// ========================================================
function tfm_home_blocks_remove_home_blog_header() {

	if ( is_home() && tfm_home_blocks_active( )) {
		remove_action( 'tfm_before_loop', tfm_get_theme_textdomain() . '_blog_header', 10 );
	}
}
add_action( 'tfm_before_loop', 'tfm_home_blocks_remove_home_blog_header', 9 );

// ========================================================
// Excerpt length
// ========================================================
function tfm_home_blocks_excerpt( $length = '' ) {

	if ( '' === $length || $length === 0 ) {

		return get_the_excerpt();
	}

	// Override global exceprt length

	$excerpt = explode(' ', get_the_excerpt()); 
	$excerpt_length = array_slice($excerpt, 0, $length);

	$result = implode(' ', $excerpt_length);

	return $result;
}

// ========================================================
// Add class to body tag
// ========================================================

function tfm_home_blocks_class( $classes ) {

	if ( is_front_page() && tfm_home_blocks_active() ) {
		$classes[] = 'has-tfm-post-blocks';
	}
	return $classes;
}
add_filter( 'body_class', 'tfm_home_blocks_class' );


// ========================================================
// Check for any active post blocks
// ========================================================

function tfm_home_blocks_active( $return_active_blocks = false ) {

	$home_blocks = tfm_get_home_blocks( );
	$block_status = array();

	foreach ($home_blocks as $block => $value) {
		$block_status[$block] = get_theme_mod( $block, false );
	}

	$active_blocks = array_filter($block_status);
	$active_status = ( count($active_blocks) !== 0 && is_front_page() && ! is_paged() ? true : false );

	if ( $return_active_blocks ) {

		return $active_blocks;

	} else {

		return $active_status;

	}

}

// ========================================================
// Register block sidebars
// ========================================================

function tfm_register_block_sidebars() {
	$home_blocks = tfm_get_home_blocks( );

	foreach ($home_blocks as $block => $value) {
		$block_num = substr($block, 15); // Extract the number from the array string
		register_sidebar( array(
		'name'          => esc_html__( 'TFM: Homepage Post Block', 'tfm-home-blocks' ) . ' ' . esc_attr( $block_num),
		'id'            => 'sidebar-' . $block,
		'description'   => esc_html__( 'Add widgets here to appear in your posts block sidebar', 'tfm-home-blocks' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	}
}
add_action( 'widgets_init', 'tfm_register_block_sidebars' );

// ========================================================
// Video post format
// ========================================================

/*
 * Get the first video embed in the post
 * Display it in place of the featured image if selected
 */

if ( ! function_exists( 'tfm_home_blocks_featured_video' ) ) {

	function tfm_home_blocks_featured_video( $has_video_query = false, $return = true ) {

		if ( ! has_post_format( 'video') ) {
			return;
		}

		$html = '';

		if ( has_post_format( 'video') ) {

			$content = apply_filters( 'the_content', get_the_content() );
			$video = false;

			// Only get video from the content if a playlist isn't present.
			if ( false === strpos( $content, 'wp-playlist-script' ) ) {
				$video = get_media_embedded_in_content( $content, array( 'video', 'object', 'embed', 'iframe' ) );

				if ( ! $video ) {
					return false;
				}

				// We have a video and a query request
				if ( $video && $has_video_query ) {
					return true;
				}
			}

			foreach ( $video as $video_html ) {
				
				// Figure out the block type by looking at the content string

				$type = 'tfm-video'; // Default is video block

				if ( strpos($video_html, 'oembed') !== false || strpos($video_html, 'vimeo') !== false ) {
					$type = 'tfm-video-oembed'; // block oembed (Youtube block, Vimeo block etc.)
				}
				if ( strpos($video_html, 'shortcode') !== false ) {
					$type = 'tfm-video-shortcode'; // shortcode
				}

				$html .= '<figure class="wp-block-embed is-type-video ' . $type . ' wp-embed-aspect-16-9 wp-has-aspect-ratio tfm-featured-media"><div class="wp-block-embed__wrapper">';
				$html .= $video_html;
				$html .= '</div></figure>';

				return $html;

				break; // In case we have more than one embed lets break after the first iteration
			}

		} else {

			// Nothing here return false
			return false;
		}

	}

}

// ========================================================
// Posts query
// ========================================================

function tfm_home_blocks_post_query( $block = '' ) {

	if ( '' === $block ) {
		return false;
	}

	// ========================================================
	// Query args
	// ========================================================

	$post_num = get_theme_mod( $block . '_post_num', 3 );
	// Count post IDs to get the $post_num if specific posts
	if ( 'post_ids' === get_theme_mod( '' . $block . '_post_type', 'recent' ) && '' !== get_theme_mod( '' . $block . '_post_ids' ) ) {
		$explode_post_ids = explode(',', get_theme_mod( '' . $block . '_post_ids' ));
		$post_num = count($explode_post_ids);
	}
	$post_offset = get_theme_mod( $block . '_post_offset', 0 );
	$post_type = get_theme_mod( $block . '_post_type', 'recent' );
	$post_cat = get_theme_mod( $block . '_post_cat', '' );
	if ( $post_cat === 0 ) {
		$post_cat = '';
	}
	$post_format = get_theme_mod( '' . $block . '_post_format', '' );
	$post_in = ( ( $post_type === 'post_ids' || $post_type === 'product_ids' ) && '' !== get_theme_mod( $block . '_post_ids', '' ) ? explode(',', get_theme_mod( $block . '_post_ids', '' ) ) : '' );
	$post_not_in = ( ( $post_type !== 'post_ids' || $post_type !== 'product_ids' ) && '' !== get_theme_mod( $block . '_exclude_post_ids', '' ) ? explode(',', get_theme_mod( '' . $block . '_exclude_post_ids', '' ) ) : array() );
	$tag_in = ( '' !== get_theme_mod( $block . '_tag_ids', '' ) ? explode(',',  get_theme_mod( $block . '_tag_ids', '' ) ) : '' );
	$order_by = ( $post_type === 'popular' ? 'comment_count' : '' ); // Popular posts
	if ( $post_type === 'random' ) {
		$order_by = 'rand';
	}
	$sort_order = get_theme_mod( '' . $block . '_sort_order', 'desc' );
	$article_type = $post_type === 'product_ids' || $post_type === 'recent_products' ? 'product' : 'post';

	// ========================================================
	// Exclude duplicate posts
	// ========================================================

	/**
	 * Fetch transient for previous blocks and exclude cumulative
	 * post IDs from query if option is set for this query
	 * */

	$exclude_ids = array();

	$block_1_transient = get_theme_mod( 'tfm_home_block_1', false ) && get_transient( 'tfm_home_block_1') ? get_transient( 'tfm_home_block_1') : array();
	$block_2_transient = get_theme_mod( 'tfm_home_block_2', false ) && get_transient( 'tfm_home_block_2') ? get_transient( 'tfm_home_block_2') : array();
	$block_3_transient = get_theme_mod( 'tfm_home_block_3', false ) && get_transient( 'tfm_home_block_3') ? get_transient( 'tfm_home_block_3') : array();
	$block_4_transient = get_theme_mod( 'tfm_home_block_4', false ) && get_transient( 'tfm_home_block_4') ? get_transient( 'tfm_home_block_4') : array();
	$block_5_transient = get_theme_mod( 'tfm_home_block_5', false ) && get_transient( 'tfm_home_block_5') ? get_transient( 'tfm_home_block_5') : array();
	$block_6_transient = get_theme_mod( 'tfm_home_block_6', false ) && get_transient( 'tfm_home_block_6') ? get_transient( 'tfm_home_block_6') : array();
	$block_7_transient = get_theme_mod( 'tfm_home_block_7', false ) && get_transient( 'tfm_home_block_7') ? get_transient( 'tfm_home_block_7') : array();

	// Block 2
	if ( $block === 'tfm_home_block_2' ) {
		$exclude_ids = $block_1_transient;
	}
	// Block 3
	if ( $block === 'tfm_home_block_3') {
		$exclude_ids = array_merge( $block_1_transient, $block_2_transient );
	}
	// Block 4
	if ( $block === 'tfm_home_block_4' ) {
		$exclude_ids = array_merge( $block_1_transient, $block_2_transient, $block_3_transient );
	}
	// Block 5
	if ( $block === 'tfm_home_block_5' ) {
		$exclude_ids = array_merge( $block_1_transient, $block_2_transient, $block_3_transient, $block_4_transient  );
	}
	// Block 6
	if ( $block === 'tfm_home_block_6' ) {
		$exclude_ids = array_merge( $block_1_transient, $block_2_transient, $block_3_transient, $block_4_transient, $block_5_transient  );
	}
	// Block 7
	if ( $block === 'tfm_home_block_7' ) {
		$exclude_ids = array_merge( $block_1_transient, $block_2_transient, $block_3_transient, $block_4_transient, $block_5_transient, $block_6_transient );
	}

	// Update $post_not_in arg
	if ( get_theme_mod( $block . '_exclude_duplicate', false ) ) {
		$post_not_in = array_merge($post_not_in, $exclude_ids);
	}

	// ========================================================
	// Run the query and retun the args
	// ========================================================

	if ( 0 === $post_num ) {
		return false;
	}

	if ( '' !== $post_in ) {

		// Specific posts 

		$query_args = array(
			'post_type' => $article_type,
		    'posts_per_page' => $post_num,
		    'post__in' => $post_in,
		    'ignore_sticky_posts' => 1,
		    'orderby' => 'post__in',
		    'order' => '' . $sort_order . '',
		);

	} else {

		// Exclude standard post format

		if ( '' !== $post_format && $post_format !== 'post-format-standard' ) {

			$query_args = array(
		    'posts_per_page' => $post_num,
		    'offset' => $post_offset,
			'cat' => $post_cat,
			'tag_slug__in' => $tag_in,
		    'ignore_sticky_posts' => 1,
		    'orderby' => $order_by,
		    'order' => '' . $sort_order . '',
		    'post__not_in' => $post_not_in,
			'tax_query' => array( array(
	            'taxonomy' => 'post_format',
	            'field' => 'slug',
	            'terms' => array($post_format),
	            'operator' => 'IN',
	           ) ),
			'post_status' => array(      
				'publish',
				),
		);

		// Only standard post format

		} elseif ( '' !== $post_format && $post_format === 'post-format-standard' ) {
			// Post format query

			$query_args = array(
		    'posts_per_page' => $post_num,
		    'offset' => $post_offset,
			'cat' => $post_cat,
			'tag_slug__in' => $tag_in,
		    'ignore_sticky_posts' => 1,
		    'orderby' => $order_by,
		    'order' => '' . $sort_order . '',
		    'post__not_in' => $post_not_in,
			'tax_query' => array( array(
		        'taxonomy' => 'post_format',
		        'field' => 'slug',
		        'terms' => array('post-format-image', 'post-format-gallery', 'post-format-video', 'post-format-audio'),
		        'operator' => 'NOT IN',
		       ) ),
			'post_status' => array(      
				'publish',
				),
		);

		} else {

			// All formats general query

			if ( 'product' === $article_type ) {

				// Product with category filter

				if ( '' !== $post_cat && 0 !== $post_cat ) {

				$query_args = array(
				'post_type' => 'product',
				'posts_per_page' => $post_num,
				'offset' => $post_offset,
				'tag_slug__in' => $tag_in,
				'ignore_sticky_posts' => 1,
				'orderby' => $order_by,
				'order' => '' . $sort_order . '',
				'post__not_in' => $post_not_in,
				'post_status' => array(      
					'publish',
					),
				'tax_query' => array(
			        array(
			            'taxonomy'  => 'product_cat',
			            'field'     => 'term_id',
			            'terms'     => $post_cat,
			            'operator'  => 'IN',
			        )
		   		),
				);

			} else {

				// Product NO category filter

				$query_args = array(
				'post_type' => 'product',
				'posts_per_page' => $post_num,
				'offset' => $post_offset,
				'tag_slug__in' => $tag_in,
				'ignore_sticky_posts' => 1,
				'orderby' => $order_by,
				'order' => '' . $sort_order . '',
				'post__not_in' => $post_not_in,
				'post_status' => array(      
					'publish',
					),
				);

			}


			} else {

				// Posts

				$query_args = array(
				'post_type' => 'post',
				'posts_per_page' => $post_num,
				'offset' => $post_offset,
				'cat' => $post_cat,
				'tag_slug__in' => $tag_in,
				'ignore_sticky_posts' => 1,
				'orderby' => $order_by,
				'order' => '' . $sort_order . '',
				'post__not_in' => $post_not_in,
				'post_status' => array(      
					'publish',
					),
				);

			}

		} // End General query

	}

	return $query_args;

}

// ========================================================
// Set transient
// ========================================================

/**
 * Transients are used to exclude duplicate posts
 * Set transient every post and customizer publish
 */

function tfm_home_blocks_set_transient() {

	$home_blocks = tfm_home_blocks_active( true );

	foreach ($home_blocks as $block => $value) {

		$query_args = tfm_home_blocks_post_query( $block );

		$posts_query = new WP_Query( $query_args );

		if ( $posts_query->have_posts( ) )  {

			$transient_post_ids = wp_list_pluck( $posts_query->posts, 'ID' );

			set_transient( $block, $transient_post_ids, 24 * HOUR_IN_SECONDS );

		} 
		
	}

}
add_action( 'save_post', 'tfm_home_blocks_set_transient', 20 );
add_action( 'customize_save_after', 'tfm_home_blocks_set_transient', 20 );

// ========================================================
// Include files
// ========================================================
include( TFM_POST_BLOCKS__PLUGIN_DIR . 'inc/customizer.php' );
include( TFM_POST_BLOCKS__PLUGIN_DIR . 'inc/sanitization.php' );
include( TFM_POST_BLOCKS__PLUGIN_DIR . 'inc/hooks.php' );
include( TFM_POST_BLOCKS__PLUGIN_DIR . 'inc/custom_colors.php' );

?>