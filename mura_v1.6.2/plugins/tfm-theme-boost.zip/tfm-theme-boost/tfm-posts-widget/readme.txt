=== TFM Posts Widget ===

Plugin Name: TFM Posts Widget

Author: 3FortyMedia

Author URI: https://www.3forty.media/

Requires at least: 5.8

Tested up to: 6.0

Requires PHP: 7.0

License: GPLv2

License URI: https://www.gnu.org/licenses/gpl-2.0.html

=== Description ===
Customizable posts display widget

=== Changelog ===

= 1.3.1 =
* Added ratings scale
* Removed jetpack ratings support

= 1.3 =
* Added post style option

= 1.2 =
* Added jetpack ratings support

= 1.1 =
* Fixed translation string

= 1.0 - Initial release =



