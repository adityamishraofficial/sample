<?php

/**
 * TFM Home Blocks Hooks
 *
 *
 * @package WordPress
 * @subpackage Mura
 * @since 1.0
 * @version 1.0
 */

// ========================================================
// Custom Hooks
// ========================================================
function tfm_home_blocks_prepend_after_title_meta() {
    do_action('tfm_home_blocks_prepend_after_title_meta');
}
function tfm_home_blocks_append_after_title_meta() {
    do_action('tfm_home_blocks_append_after_title_meta');
}
function tfm_home_blocks_after_continue_reading_button() {
    do_action('tfm_home_blocks_after_continue_reading_button');
}

function tfm_home_blocks_after_after_title_meta() {
    do_action('tfm_home_blocks_after_after_title_meta');
}

?>