<?php

/**
Plugin Name: TFM: Theme Boost
Plugin URI:  http://www.3forty.media
Description: Optional add-ons, widgets and tools to give your theme a boost.
Version:     2.1
Author:      3FortyMedia
Author URI:  http://www.3forty.media
Text Domain: tfm-theme-boost
Domain Path: /languages/
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! function_exists('tfm_theme_boost_init') ) {

	// ========================================================
	// Add link to settings
	// ========================================================

	add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'tfm_plugin_settings_link' );

	function tfm_plugin_settings_link( $settings ) {
	   $settings[] = '<a href="'. get_admin_url(null, 'admin.php?page=tfm-theme-boost') .'">Settings</a>';
	   return $settings;
	}

	// ========================================================
	// Load language file
	// ========================================================

	function tfm_theme_boost_init() {
		load_plugin_textdomain( 'tfm-theme-boost', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}
	add_action( 'init', 'tfm_theme_boost_init' );

	define( 'TFM_THEME_BOOST_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

	// ========================================================
	// Include theme boost functions
	// ========================================================
	include( TFM_THEME_BOOST_PLUGIN_DIR . 'inc/plugin-options.php' ); // since verson 2
	include( TFM_THEME_BOOST_PLUGIN_DIR . 'inc/customizer/customizer.php' );
	include( TFM_THEME_BOOST_PLUGIN_DIR . 'inc/functions.php' );
	include( TFM_THEME_BOOST_PLUGIN_DIR . 'inc/meta-boxes.php' );
	include( TFM_THEME_BOOST_PLUGIN_DIR . 'inc/sanitization.php' );
	include( TFM_THEME_BOOST_PLUGIN_DIR . 'inc/custom_css.php' );

	// ========================================================
	// Include plugin parts
	// ========================================================

	/**
	 * Since version 2
	 */

	include( TFM_THEME_BOOST_PLUGIN_DIR . 'tfm-hero/tfm-hero.php' );
	include( TFM_THEME_BOOST_PLUGIN_DIR . 'tfm-related-posts/tfm-related-posts.php' );
	include( TFM_THEME_BOOST_PLUGIN_DIR . 'tfm-social-plugin/tfm-social-plugin.php' );
	include( TFM_THEME_BOOST_PLUGIN_DIR . 'tfm-posts-widget/tfm-posts-widget.php' );

} // Endif functon_exists( 'tfm_theme_boost_init')


?>