/*---------------------------------------*/
/* Slick tfm-hero Inline JS (Fallback)       */
/*---------------------------------------*/

jQuery(document).ready(function($) {

	"use strict";

	var slidestoshow = $(".tfm-hero.carousel").attr("data-slidestoshow");
	var maxslides = $(".tfm-hero.carousel").attr("data-maxslides");
	var slidenum = $(".tfm-hero.carousel").attr("data-slides");
	var slickdots = $(".tfm-hero.carousel").attr("data-initial-status");
	var centermode = $(".tfm-hero.slick").attr("data-centermode");
	var autospeed = $(".tfm-hero.slick").attr("data-autoplay-speed");
	var speed = $(".tfm-hero.slick").attr("data-speed");
	var fullwidth = $(".tfm-hero").attr("data-fullwidth");
	var aspectratio = $(".tfm-hero.slick").attr("data-aspectratio");
	var margins = $(".tfm-hero").attr("data-margins");

	// Calculate slidestoshow breakpoints

	var slidestoshow_seven = 7;
	if ( slidestoshow_seven > slidestoshow ) {
		slidestoshow_seven = slidestoshow;
	}
	var slidestoshow_six = 6;
	if ( slidestoshow_six > slidestoshow ) {
		slidestoshow_six = slidestoshow;
	}
	var slidestoshow_five = 5;
	if ( slidestoshow_five > slidestoshow ) {
		slidestoshow_five = slidestoshow;
	}
	var slidestoshow_four = 4;
	if ( slidestoshow_four > slidestoshow ) {
		slidestoshow_four = slidestoshow;
	}
	var slidestoshow_three = 3;
	if ( slidestoshow_three > slidestoshow ) {
		slidestoshow_three = slidestoshow;
	}
	var slidestoshow_two = 2;
	if ( slidestoshow_two > slidestoshow ) {
		slidestoshow_two = slidestoshow;
	}
	
	//////////////////////////////
	// Center Padding
	//////////////////////////////
	
	var centerpadding = "17.2%";
	if ( slidestoshow >= 3 ) {
		centerpadding = "7%";
	}


	if ($("body").hasClass("rtl")) {

	//////////////////////////////
	// RTL
	//////////////////////////////
	
	/**
		 * Center Mode Active
		 */

		if ( centermode == "true" ) {

		$(".tfm-hero.slider")

		.slick({
			dots: false,
			infinite: true,
			autoplay: true,
			autoplaySpeed: + autospeed,
			speed: + speed,
			rtl: true,
			slidesToShow: 1,
			centerMode: true,
			centerPadding: "" + centerpadding + "",
		}); 

		if ( fullwidth == "true" ) {

		$(".tfm-hero.carousel")

		.slick({
			dots: false,
			infinite: true,
			autoplay: true,
			autoplaySpeed: + autospeed,
			speed: + speed,
			rtl: true,
			slidesToShow: + slidestoshow,
			centerMode: true,
			centerPadding: "" + centerpadding + "",
			responsive: [
				{
					breakpoint: 1601,
					settings: {
						slidesToShow: + slidestoshow_three,
						centerPadding: "7%",
					}
				},
				{
					breakpoint: 1381,
					settings: {
						slidesToShow: + slidestoshow_two,
						centerPadding: "12%",
					}
				},
				{
					breakpoint: 1061,
					settings: {
						slidesToShow: 1,
						centerPadding: "17%",
					}
				},
				{
					breakpoint: 769,
					settings: {
						slidesToShow: 1,
						centerPadding: "8%",
					}
				},
				{
					breakpoint: 569,
					settings: {
						slidesToShow: 1,
						centerPadding: "0",
					}
				},
			]
		}); 

	} else {

		// Not full width

		$(".tfm-hero.carousel")

		.slick({
			dots: false,
			infinite: true,
			autoplay: true,
			autoplaySpeed: + autospeed,
			speed: + speed,
			rtl: true,
			slidesToShow: + slidestoshow,
			centerMode: true,
			centerPadding: "" + centerpadding + "",
			responsive: [
			{
					breakpoint: 1201,
					settings: {
						slidesToShow: + slidestoshow_two,
						centerPadding: "12%",
					}
				},
				{
					breakpoint: 1061,
					settings: {
						slidesToShow: 1,
						centerPadding: "17%",
					}
				},
				{
					breakpoint: 769,
					settings: {
						slidesToShow: 1,
						centerPadding: "8%",
					}
				},
				{
					breakpoint: 569,
					settings: {
						slidesToShow: 1,
						centerPadding: "0",
					}
				},
			]
		}); 

	}



		} else { // Not centermode

			$(".tfm-hero.slider")

			.slick({
				dots: false,
				infinite: true,
				autoplay: true,
				autoplaySpeed: + autospeed,
				speed: + speed,
				rtl: true,
				slidesToShow: 1,
			}); 

			if ( fullwidth == "true" ) {

			$(".tfm-hero.carousel")

			.slick({
				dots: false,
				infinite: true,
				autoplay: true,
				autoplaySpeed: + autospeed,
				speed: + speed,
				rtl: true,
				slidesToShow: + slidestoshow,
				responsive: [
					{
						breakpoint: 1601,
						settings: {
							slidesToShow: + slidestoshow_three,
						}
					},
					{
						breakpoint: 1381,
						settings: {
							slidesToShow: + slidestoshow_two,
						}
					},
					{
						breakpoint: 1061,
						settings: {
							slidesToShow: 1,
						}
					},
				]
			}); 

		} else {

			// not full width

			$(".tfm-hero.carousel")

			.slick({
				dots: false,
				infinite: true,
				autoplay: true,
				autoplaySpeed: + autospeed,
				speed: + speed,
				rtl: true,
				slidesToShow: + slidestoshow,
				responsive: [
					{
						breakpoint: 1201,
						settings: {
							slidesToShow: + slidestoshow_two,
						}
					},
					{
						breakpoint: 1061,
						settings: {
							slidesToShow: 1,
						}
					},
				]
			}); 
		}

		} // End not centermode

	} else {

		//////////////////////////////
		// LTR
		//////////////////////////////

		/**
		 * Center Mode Active
		 */

		if ( centermode == "true" ) {

		if ( fullwidth == "true" ) {

			if ( margins == "false" ) {

			$(".tfm-hero.slider")

			.slick({
				dots: false,
				infinite: true,
				autoplay: true,
				autoplaySpeed: + autospeed,
				speed: + speed,
				slidesToShow: 1,
				centerMode: true,
				centerPadding: "18.5%",
				responsive: [
				{
					breakpoint: 569,
					settings: {
						centerPadding: "0",
					}
				},
			]
			}); 

		} else {

			$(".tfm-hero.slider")

			.slick({
				dots: false,
				infinite: true,
				autoplay: true,
				autoplaySpeed: + autospeed,
				speed: + speed,
				slidesToShow: 1,
				centerMode: true,
				centerPadding: "" + centerpadding + "",
				responsive: [
				{
					breakpoint: 569,
					settings: {
						centerPadding: "0",
					}
				},
			]
			});

		}

		$(".tfm-hero.carousel")

		.slick({
			dots: false,
			infinite: true,
			autoplay: true,
			autoplaySpeed: + autospeed,
			speed: + speed,
			slidesToShow: + slidestoshow,
			centerMode: true,
			centerPadding: "" + centerpadding + "",
			responsive: [
				{
					breakpoint: 1601,
					settings: {
						slidesToShow: + slidestoshow_three,
						centerPadding: "7%",
					}
				},
				{
					breakpoint: 1381,
					settings: {
						slidesToShow: + slidestoshow_two,
						centerPadding: "12%",
					}
				},
				{
					breakpoint: 1061,
					settings: {
						slidesToShow: 1,
						centerPadding: "17%",
					}
				},
				{
					breakpoint: 769,
					settings: {
						slidesToShow: 1,
						centerPadding: "8%",
					}
				},
				{
					breakpoint: 569,
					settings: {
						slidesToShow: 1,
						centerPadding: "0",
					}
				},
			]
		}); 

	} else {

		// Not full width

		$(".tfm-hero.slider")

			.slick({
				dots: false,
				infinite: true,
				autoplay: true,
				autoplaySpeed: + autospeed,
				speed: + speed,
				slidesToShow: 1,
				centerMode: true,
				centerPadding: "" + centerpadding + "",
			}); 

		$(".tfm-hero.carousel")

		.slick({
			dots: false,
			infinite: true,
			autoplay: true,
			autoplaySpeed: + autospeed,
			speed: + speed,
			slidesToShow: + slidestoshow,
			centerMode: true,
			centerPadding: "" + centerpadding + "",
			responsive: [
			{
					breakpoint: 1201,
					settings: {
						slidesToShow: + slidestoshow_two,
						centerPadding: "12%",
					}
				},
				{
					breakpoint: 1061,
					settings: {
						slidesToShow: 1,
						centerPadding: "17%",
					}
				},
				{
					breakpoint: 769,
					settings: {
						slidesToShow: 1,
						centerPadding: "8%",
					}
				},
				{
					breakpoint: 569,
					settings: {
						slidesToShow: 1,
						centerPadding: "0",
					}
				},
			]
		}); 

	}



		} else { // Not centermode

			$(".tfm-hero.slider")

			.slick({
				dots: false,
				infinite: true,
				autoplay: true,
				autoplaySpeed: + autospeed,
				speed: + speed,
				slidesToShow: 1,
			}); 

			if ( fullwidth == "true" ) {

			$(".tfm-hero.carousel")

			.slick({
				dots: false,
				infinite: true,
				autoplay: true,
				autoplaySpeed: + autospeed,
				speed: + speed,
				slidesToShow: + slidestoshow,
				responsive: [
					{
						breakpoint: 1601,
						settings: {
							slidesToShow: + slidestoshow_three,
						}
					},
					{
						breakpoint: 1381,
						settings: {
							slidesToShow: + slidestoshow_two,
						}
					},
					{
						breakpoint: 1061,
						settings: {
							slidesToShow: 1,
						}
					},
				]
			}); 

		} else {

			// not full width

			$(".tfm-hero.carousel")

			.slick({
				dots: false,
				infinite: true,
				autoplay: true,
				autoplaySpeed: + autospeed,
				speed: + speed,
				slidesToShow: + slidestoshow,
				responsive: [
					{
						breakpoint: 1201,
						settings: {
							slidesToShow: + slidestoshow_two,
						}
					},
					{
						breakpoint: 1061,
						settings: {
							slidesToShow: 1,
						}
					},
				]
			}); 
		}

		} // End not centermode

	}
});
