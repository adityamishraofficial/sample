=== TFM Homepage Post Blocks ===

Plugin Name: TFM Hompepage post Blocks

Author: 3FortyMedia

Author URI: https://www.3forty.media/

Requires at least: 5.9

Tested up to: 6.0

Requires PHP: 7.0

License: GPLv2

License URI: https://www.gnu.org/licenses/gpl-2.0.html

=== Description ===
Display configurable post blocks and sidebars on your homepage.

=== Changelog ===

= 1.2.5 =
* Added support for videos

= 1.2.4 =
* Fixed Woocommerce errors
* Added support for all layout types when displaying products

= 1.2.3 =
* Fixed text domain

= 1.2.2 =
* Minor updates

= 1.2.1 =
* Added width and margins theme support options
* Updated TFM ratings support

= 1.2 =
* Added Jetpack ratings support

- 1.1.1 = 
* Added variable thumbnail size

= 1.1 =
* Added option to exclude duplicate posts
* Added top/bottom sidebar option
* Added ability to show just a sidebar
* Added additional layout options

= 1.0 - Initial release =



