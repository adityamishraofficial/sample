<?php
/**
 * Template part for displaying post share icons
 * @since 1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>
<?php
	// Replace spaces in the title with + symbol so we can pass it in the share link
	$strip_title = strip_tags( get_the_title() );
	$text = str_replace(' ', '%20', $strip_title );
	$text_plus = str_replace(' ', '+', $strip_title );
	// If isset add via handle to twitter
	$twitter_handle = str_replace('https://twitter.com/', '', get_theme_mod( 'tfm_social_site_twitter') );
	// In case user enters a trailing slash
	$twitter_handle = str_replace('/', '', $twitter_handle );
	$via = ( '' !== get_theme_mod( 'tfm_social_site_twitter') ? '&amp;via=' . $twitter_handle . '' : '' );
	$show_text = $forced_request ? $show_text : get_theme_mod( 'tfm_share_post_icon_text', false );
	// Set text to false for archive
	if ( ! is_single() && ! is_page() && $show_text ) {
		$show_text = false;
	}
	$has_text = ( true === $show_text ? ' has-text' : '' );
	$round = $forced_request ? $round : get_theme_mod( 'tfm_share_post_icon_round', false );
	$is_product = false;
	if ( class_exists('WooCommerce') ) {
		$is_product = is_product() ? true : false;
	}
	$icon_style = '' !== $icon_style ? $icon_style : get_theme_mod( 'tfm_share_post_icon_style', 'icon-background' );
	$color_scheme = '' !== $color_scheme ? $color_scheme : get_theme_mod( 'tfm_share_post_icon_color_scheme', 'theme' );

	// If theme supports blog list sharing
	if ( apply_filters( 'tfm_social_plugin_theme_supports_share_blog_list_posts', false ) && ! is_single() && ! is_page() ) {

		$icon_style = get_theme_mod( 'tfm_share_archive_post_icon_style', 'icon-background' );
		$color_scheme = get_theme_mod( 'tfm_share_archive_post_icon_color_scheme', 'theme' );
		$round = get_theme_mod( 'tfm_share_archive_post_icon_round', false );

	}
	// End

	$has_round_icons = ( $round ? ' has-round-icons' : '' );
	$share_blog_lists = apply_filters( 'tfm_social_plugin_theme_supports_share_blog_list_posts', false );

	// Active share sites

	$share_twitter = $share_blog_lists && ! is_single() && ! is_page() ? get_theme_mod( 'tfm_share_archive_post_twitter', false ) : get_theme_mod( 'tfm_share_post_twitter', true );
	$share_facebook = $share_blog_lists && ! is_single() && ! is_page() ? get_theme_mod( 'tfm_share_archive_post_facebook', false ) : get_theme_mod( 'tfm_share_post_facebook', true );
	$share_pinterest = $share_blog_lists && ! is_single() && ! is_page() ? get_theme_mod( 'tfm_share_archive_post_pinterest', false ) : get_theme_mod( 'tfm_share_post_pinterest', true );
	$share_linkedin = $share_blog_lists && ! is_single() && ! is_page() ? get_theme_mod( 'tfm_share_archive_post_linkedin', false ) : get_theme_mod( 'tfm_share_post_linkedin', true );
	$share_tumblr = $share_blog_lists && ! is_single() && ! is_page() ? get_theme_mod( 'tfm_share_archive_post_tumblr', false ) : get_theme_mod( 'tfm_share_post_tumblr', true );
	$share_reddit = $share_blog_lists && ! is_single() && ! is_page() ? get_theme_mod( 'tfm_share_archive_post_reddit', false ) : get_theme_mod( 'tfm_share_post_reddit', true );
	$share_pocket = $share_blog_lists && ! is_single() && ! is_page() ? get_theme_mod( 'tfm_share_archive_post_pocket', false ) : get_theme_mod( 'tfm_share_post_pocket', true );
	$share_vk = $share_blog_lists && ! is_single() && ! is_page() ? get_theme_mod( 'tfm_share_archive_post_vk', false ) : get_theme_mod( 'tfm_share_post_vk', true );
	$share_ok = $share_blog_lists && ! is_single() && ! is_page() ? get_theme_mod( 'tfm_share_archive_post_odnoklassniki', false ) : get_theme_mod( 'tfm_share_post_odnoklassniki', true );
	$share_whatsapp = $share_blog_lists && ! is_single() && ! is_page() ? get_theme_mod( 'tfm_share_archive_post_whatsapp', false ) : get_theme_mod( 'tfm_share_post_whatsapp', true );
	$share_telegram = $share_blog_lists && ! is_single() && ! is_page() ? get_theme_mod( 'tfm_share_archive_post_telegram', false ) : get_theme_mod( 'tfm_share_post_telegram', true );
	$share_gettr = $share_blog_lists && ! is_single() && ! is_page() ? get_theme_mod( 'tfm_share_archive_post_gettr', false ) : get_theme_mod( 'tfm_share_post_gettr', true );
	?>
<!-- share -->
<div class="tfm-share-wrapper <?php echo get_theme_mod( 'tfm_single_share_post_position', 'bottom' ); ?>">
<div class="tfm-share">
	<ul class="tfm-social-icons <?php echo esc_attr( $icon_style); ?> <?php echo esc_attr( $color_scheme); ?> <?php echo esc_attr( $has_text . $has_round_icons ); ?>">
		<li class="share-text"><span><?php echo esc_html__( 'Share', 'tfm-theme-boost' ) ?></span> <span class="share-this-text"><?php if ( is_single() && ! $is_product ) { echo esc_html__( 'this article', 'tfm-theme-boost' ); } ?><?php if ( is_page() ) { echo esc_html__( 'this page', 'tfm-theme-boost' ); } ?></span></li>

		<?php if ( $share_twitter ): ?>
		<li class="tfm-social-icon twitter"><a class="tfm-social-link" rel="nofollow" href="https://twitter.com/share?url=<?php the_permalink(); ?>&amp;text=<?php echo esc_attr( $text ); ?><?php echo esc_attr( $via ); ?>" target="_blank"><span><i class="icon-twitter"></i></span><?php if ( $show_text ) : ?><span class="tfm-social-name"><?php echo esc_html__( 'twitter', 'tfm-theme-boost' ); ?></span><?php endif; ?></a></li>
		<?php endif; ?>

		<?php if ( $share_facebook ): ?>
		<li class="tfm-social-icon facebook"><a class="tfm-social-link" rel="nofollow" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" target="_blank"><span><i class="icon-facebook"></i></span><?php if ( $show_text ) : ?><span class="tfm-social-name"><?php echo esc_html__( 'facebook', 'tfm-theme-boost' ); ?></span><?php endif; ?></a></li>
		<?php endif; ?>

		<?php if ( $share_pinterest ): ?>
		<li class="tfm-social-icon pinterest"><a class="tfm-social-link" rel="nofollow" href="https://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&amp;media=<?php echo get_the_post_thumbnail_url(); ?>&amp;description=<?php echo esc_attr( $text_plus ); ?>" target="_blank"><span><i class="icon-pinterest"></i></span><?php if ( $show_text ) : ?><span class="tfm-social-name"><?php echo esc_html__( 'pinterest', 'tfm-theme-boost' ); ?></span><?php endif; ?></a></li>
		<?php endif; ?>

		<?php if ( $share_linkedin ): ?>
		<li class="tfm-social-icon linkedin"><a class="tfm-social-link" rel="nofollow" href="https://www.linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>&amp;title=<?php echo esc_attr( $text_plus ); ?>" target="_blank"><span><i class="icon-linkedin"></i></span><?php if ( $show_text ) : ?><span class="tfm-social-name"><?php echo esc_html__( 'linkedin', 'tfm-theme-boost' ); ?></span><?php endif; ?></a></li>
		<?php endif; ?>

		<?php if ( $share_tumblr ): ?>
		<li class="tfm-social-icon tumblr"><a class="tfm-social-link" rel="nofollow" href="https://www.tumblr.com/share/link?url=<?php the_permalink(); ?>" target="_blank"><span><i class="icon-tumblr"></i></span><?php if ( $show_text ) : ?><span class="tfm-social-name"><?php echo esc_html__( 'tumblr', 'tfm-theme-boost' ); ?></span><?php endif; ?></a></li>
		<?php endif; ?>

		<?php if ( $share_reddit ): ?>
		<li class="tfm-social-icon reddit"><a class="tfm-social-link" rel="nofollow" href="https://reddit.com/submit?url=<?php the_permalink(); ?>" target="_blank"><span><i class="icon-reddit-alien"></i></span><?php if ( $show_text ) : ?><span class="tfm-social-name"><?php echo esc_html__( 'reddit', 'tfm-theme-boost' ); ?></span><?php endif; ?></a></li>
		<?php endif; ?>

		<?php if ( $share_pocket ): ?>
		<li class="tfm-social-icon pocket"><a class="tfm-social-link" rel="nofollow" href="https://getpocket.com/save?url=<?php the_permalink(); ?>&amp;title=<?php echo esc_attr( $text ); ?>" target="_blank"><span><i class="icon-get-pocket"></i></span><?php if ( $show_text ) : ?><span class="tfm-social-name"><?php echo esc_html__( 'pocket', 'tfm-theme-boost' ); ?></span><?php endif; ?></a></li>
		<?php endif; ?>

		<?php if ( $share_vk ): ?>
		<li class="tfm-social-icon vkontakte"><a class="tfm-social-link" rel="nofollow" href="https://vk.com/share.php?url=<?php the_permalink(); ?>&amp;title=<?php echo esc_attr( $text ); ?>" target="_blank"><span><i class="icon-vkontakte"></i></span><?php if ( $show_text ) : ?><span class="tfm-social-name"><?php echo esc_html__( 'vkontakte', 'tfm-theme-boost' ); ?></span><?php endif; ?></a></li>
		<?php endif; ?>

		<?php if ( $share_ok ): ?>
		<li class="tfm-social-icon odnoklassniki"><a class="tfm-social-link" rel="nofollow" href="https://connect.ok.ru/dk?cmd=WidgetSharePreview&amp;st.cmd=WidgetSharePreview&amp;st.shareUrl=<?php the_permalink(); ?>" target="_blank"><span><i class="icon-odnoklassniki"></i></span><?php if ( $show_text ) : ?><span class="tfm-social-name"><?php echo esc_html__( 'odnoklassniki', 'tfm-theme-boost' ); ?></span><?php endif; ?></a></li>
		<?php endif; ?>

		<!-- mobile only apps -->
		<?php if ( $share_whatsapp ): ?>
		<li class="tfm-social-icon whatsapp mobile-only"><a class="tfm-social-link" rel="nofollow" href="whatsapp://send?text=<?php the_permalink(); ?>" data-action="share/whatsapp/share" target="_blank"><span><i class="icon-whatsapp"></i></span><?php if ( $show_text ) : ?><span class="tfm-social-name"><?php echo esc_html__( 'whatsapp', 'tfm-theme-boost' ); ?></span><?php endif; ?></a></li>
		<?php endif; ?>

		<?php if ( $share_telegram ): ?>
		<li class="tfm-social-icon telegram"><a class="tfm-social-link" rel="nofollow" href="https://t.me/share/url?url=<?php the_permalink(); ?>&amp;text=<?php echo esc_attr( $text ); ?>" target="_blank"><span><i class="icon-telegram"></i></span><?php if ( $show_text ) : ?><span class="tfm-social-name"><?php echo esc_html__( 'telegram', 'tfm-theme-boost' ); ?></span><?php endif; ?></a></li>
		<?php endif; ?>

		<?php if ( $share_gettr): ?>
		<li class="tfm-social-icon gettr"><a class="tfm-social-link" rel="nofollow" href="https://gettr.com/share?text=<?php echo esc_attr( $text ); ?>&amp;url=<?php the_permalink(); ?>" target="_blank"><span><i class="icon-gettr"></i></span><?php if ( $show_text ) : ?><span class="tfm-social-name"><?php echo esc_html__( 'gettr', 'tfm-theme-boost' ); ?></span><?php endif; ?></a></li>
		<?php endif; ?>
		
	</ul>
</div>
</div>