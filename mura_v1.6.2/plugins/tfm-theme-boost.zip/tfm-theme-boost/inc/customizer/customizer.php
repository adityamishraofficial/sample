<?php

/**
 * 3Forty Media: Theme Boost Customizer Settings
 *
 * @package WordPress
 * @subpackage 3FortyMedia
 * @since 1.0
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

require( TFM_THEME_BOOST_PLUGIN_DIR . 'inc/customizer/custom_controls.php' );


// Load the sections
//require( TFM_THEME_BOOST_PLUGIN_DIR . 'inc/customizer/sections/customizer-theme-boost.php' ); // Removed Since version 2
require( TFM_THEME_BOOST_PLUGIN_DIR . 'inc/customizer/sections/customizer-adverts.php' );
require( TFM_THEME_BOOST_PLUGIN_DIR . 'inc/customizer/sections/customizer-mc4wp.php' );
require( TFM_THEME_BOOST_PLUGIN_DIR . 'inc/customizer/sections/customizer-featured-post.php' ); // featured post colour settings
require( TFM_THEME_BOOST_PLUGIN_DIR . 'inc/customizer/sections/customizer-ratings.php' );
require( TFM_THEME_BOOST_PLUGIN_DIR . 'inc/customizer/sections/customizer-breadcrumbs.php' );
require( TFM_THEME_BOOST_PLUGIN_DIR . 'inc/customizer/sections/customizer-featured-posts.php' ); // featured posts

?>