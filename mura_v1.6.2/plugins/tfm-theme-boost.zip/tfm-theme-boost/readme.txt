=== TFM Theme Boost ===

Plugin Name: TFM Theme Boost

Author: 3FortyMedia

Author URI: https://www.3forty.media/

Requires at least: 5.8

Tested up to: 6.0

Requires PHP: 7.0

License: GPLv2

License URI: https://www.gnu.org/licenses/gpl-2.0.html

=== Description ===
A collection of non-essential plugins, widgets and options for your theme

=== Changelog ===

= 2.0 =
* Merged all TFM plugins into TFM The Boost plugin
* New plugin options panel

= 1.3.5 =
* Added autoads support
* New translation file

= 1.3.4 =
* Minor updates

= 1.3.3 =
* Fixed CSS output bug

= 1.3.2 =
* Added simple ratings / removed JetPack Ratings support
* Code updates & improvements

= 1.3.1 = 
* Added breadcrumbs colour setting

= 1.3 =
* Added support for JetPack ratings

= 1.2 =
* Fixed theme textDomain error

= 1.1 =
* Fixed include directory error

= 1.0 - Initial release =



