<?php
/**
 * 3FortyMedia Home Blocks Block Content
 *
 * @since 1.0
 * @version 1.2
 */

?>

<?php $has_post_format = ( has_post_format( 'gallery' ) || has_post_format( 'audio' ) || has_post_format( 'video' ) ? ' format-' . get_post_format() : '' ); ?>
<?php $has_format_icons = $has_post_format && get_theme_mod( $block . '_post_format_icons', true ) ? ' has-format-icons' : ''; ?>
<?php

if ( $is_offset_layout ) {

	// Offset layout thumbnail size

	if ( get_theme_mod( $block . '_layout', 'grid' ) === 'grid-offset-sides' ) {
		$thumbnail_size = $faux_count === 3 ? 'large' : 'medium_large';
	} else {
		$thumbnail_size = $faux_count === 1 ? 'large' : 'medium_large';
	}

}

global $product;

?>


<article class="post article <?php echo esc_attr( $meta_vars . $thumbnail_class . $has_post_format . $has_format_icons . $grid_style . ' faux-count-' . $faux_count ); ?>">

	<?php include( TFM_POST_BLOCKS__PLUGIN_DIR . 'plugin-parts/format-icons.php' ); ?>

    		<div class="post-inner"<?php echo wp_kses( $custom_color['post_border'], $allowed_html ) ?>>

    		<?php if ( '' !== get_the_post_thumbnail() && $show_thumbnail ) : ?>
    			<div class="thumbnail-wrapper">
				<figure class="post-thumbnail">

						<a href="<?php the_permalink(); ?>">
							<?php the_post_thumbnail( esc_attr( $thumbnail_size) ); ?>
						</a>

				</figure>
			</div>

			<?php endif; ?>

			<div class="entry-wrapper"<?php echo wp_kses( $custom_color['post_background'], $allowed_html ) ?>>
	    	<div class="entry-header">

	    		<?php include( TFM_POST_BLOCKS__PLUGIN_DIR . 'plugin-parts/format-icons.php' ); ?>

				<?php if ( get_theme_mod( $block . '_entry_meta_category', true ) ) : ?>

				<div class="entry-meta before-title"<?php echo wp_kses( $custom_color['entry_meta'], $allowed_html ) ?>>

						<?php mura_add_category_product_loop( true ); ?>

				</div><!-- .entry-meta -->

		<?php endif; ?>

		<?php if ( get_theme_mod( $block . '_entry_title', true ) ) : ?>

			<?php the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark"' . wp_kses( $custom_color['entry_title'], $allowed_html ) . '>', '</a></h3>' ); ?>

		<?php endif; ?>

			<?php tfm_home_blocks_after_after_title_meta(); ?>

			</div><!-- .entry-header -->

			<?php do_action( 'woocommerce_after_shop_loop_item_title' ); ?>

			<?php if ( get_theme_mod( $block . '_excerpt', false ) ): ?>

				<div class="entry-content excerpt"<?php echo wp_kses( $custom_color['entry_content'], $allowed_html ) ?>>

					<?php echo esc_html( tfm_home_blocks_excerpt( $excerpt_length ) ); ?>

				</div>

			<?php endif; ?>

			<?php

			// Read more

			if ( get_theme_mod( $block . '_read_more', false ) )  :

			// Add to cart

			do_action( 'woocommerce_after_shop_loop_item' ); ?>

			<?php tfm_home_blocks_after_continue_reading_button(); ?>

			<?php endif; ?>

		</div>

	</div>

	    </article>